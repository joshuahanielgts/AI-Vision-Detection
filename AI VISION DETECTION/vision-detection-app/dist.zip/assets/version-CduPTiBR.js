import{a as _p,g as Ip}from"./index-BNQqN1yK.js";function xp(t,e){for(var n=0;n<e.length;n++){const s=e[n];if(typeof s!="string"&&!Array.isArray(s)){for(const r in s)if(r!=="default"&&!(r in t)){const a=Object.getOwnPropertyDescriptor(s,r);a&&Object.defineProperty(t,r,a.get?a:{enumerable:!0,get:()=>s[r]})}}}return Object.freeze(Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}))}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const Ap=1e-7,Op=1e-4;class Dp{constructor(e,n){this.backend=e,this.dataMover=n,this.data=new WeakMap,this.dataIdsCount=0}get(e){return this.data.has(e)||this.dataMover.moveData(this.backend,e),this.data.get(e)}set(e,n){this.dataIdsCount++,this.data.set(e,n)}has(e){return this.data.has(e)}delete(e){return this.dataIdsCount--,this.data.delete(e)}numDataIds(){return this.dataIdsCount}}class Qa{refCount(e){return be("refCount")}incRef(e){return be("incRef")}timerAvailable(){return!0}time(e){return be("time")}read(e){return be("read")}readSync(e){return be("readSync")}readToGPU(e,n){return be("readToGPU")}numDataIds(){return be("numDataIds")}disposeData(e,n){return be("disposeData")}write(e,n,s){return be("write")}move(e,n,s,r,a){return be("move")}createTensorFromGPUData(e,n,s){return be("createTensorFromGPUData")}memory(){return be("memory")}floatPrecision(){return be("floatPrecision")}epsilon(){return this.floatPrecision()===32?Ap:Op}dispose(){return be("dispose")}}function be(t){throw new Error(`'${t}' not yet implemented or not found in the registry. This kernel may not be supported by the tfjs backend you have chosen`)}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function eo(t){let e=t.length,n=0;for(;e>0;)n=Math.random()*e|0,e--,Mn(t,e,n)}function Fp(t,e){if(t.length!==e.length)throw new Error(`Array sizes must match to be shuffled together First array length was ${t.length}Second array length was ${e.length}`);let n=t.length,s=0;for(;n>0;)s=Math.random()*n|0,n--,Mn(t,n,s),Mn(e,n,s)}function Qt(t,e,n){return Math.max(t,Math.min(e,n))}function Cp(t){return t%2===0?t:t+1}function Mn(t,e,n){const s=t[e];t[e]=t[n],t[n]=s}function Rp(t){let e=0;for(let n=0;n<t.length;n++)e+=t[n];return e}function Lp(t,e){const n=Math.random();return e*n+(1-n)*t}function Bp(t,e){let n=0;for(let s=0;s<t.length;s++){const r=Number(t[s])-Number(e[s]);n+=r*r}return n}function g(t,e){if(!t)throw new Error(typeof e=="string"?e:e())}function ge(t,e,n=""){g(Ce(t,e),()=>n+` Shapes ${t} and ${e} must match`)}function It(t){g(t!=null,()=>"The input to the tensor constructor must be a non-null value.")}function G(t){if(t.length===0)return 1;let e=t[0];for(let n=1;n<t.length;n++)e*=t[n];return e}function Pp(t){return t.length===0}function to(t,e){if(t===e)return!0;if(t==null||e==null||t.length!==e.length)return!1;for(let n=0;n<t.length;n++)if(t[n]!==null&&e[n]!==null&&t[n]!==e[n])return!1;return!0}function Ce(t,e){if(t===e)return!0;if(t==null||e==null||t.length!==e.length)return!1;for(let n=0;n<t.length;n++)if(t[n]!==e[n])return!1;return!0}function Rt(t){return t%1===0}function zp(t){if(Math.tanh!=null)return Math.tanh(t);if(t===1/0)return 1;if(t===-1/0)return-1;{const e=Math.exp(2*t);return(e-1)/(e+1)}}function Vp(t){const e=Math.ceil(Math.sqrt(t));return[e,Math.ceil(t/e)]}function Wp(t){const e=new Uint32Array(t);for(let n=0;n<t;++n)e[n]=n;return eo(e),e}function Jt(t,e){return e<=t.length?t:t+" ".repeat(e-t.length)}function Mp(t,e=r=>0,n,s){return new Promise((r,a)=>{let o=0;const i=()=>{if(t()){r();return}o++;const u=e(o);if(n!=null&&o>=n){a();return}s!=null?s(i,u):setTimeout(i,u)};i()})}function Up(t,e){let n=1,s=-1;for(let a=0;a<t.length;++a)if(t[a]>=0)n*=t[a];else if(t[a]===-1){if(s!==-1)throw Error(`Shapes can only have 1 implicit size. Found -1 at dim ${s} and dim ${a}`);s=a}else if(t[a]<0)throw Error(`Shapes can not be < 0. Found ${t[a]} at dim ${a}`);if(s===-1){if(e>0&&e!==n)throw Error(`Size(${e}) must match the product of shape ${t}`);return t}if(n===0)throw Error(`Cannot infer the missing size in [${t}] when there are 0 elements`);if(e%n!==0)throw Error(`The implicit shape can't be a fractional number. Got ${e} / ${n}`);const r=t.slice();return r[s]=e/n,r}function dn(t,e){const n=e.length;return t=t==null?e.map((s,r)=>r):[].concat(t),g(t.every(s=>s>=-n&&s<n),()=>`All values in axis param must be in range [-${n}, ${n}) but got axis ${t}`),g(t.every(s=>Rt(s)),()=>`All values in axis param must be integers but got axis ${t}`),t.map(s=>s<0?n+s:s)}function no(t,e){const n=[],s=[],r=e!=null&&Array.isArray(e)&&e.length===0,a=e==null||r?null:dn(e,t).sort();let o=0;for(let i=0;i<t.length;++i){if(a!=null){if(a[o]===i&&t[i]!==1)throw new Error(`Can't squeeze axis ${i} since its dim '${t[i]}' is not 1`);(a[o]==null||a[o]>i)&&t[i]===1&&(n.push(t[i]),s.push(i)),a[o]<=i&&o++}t[i]!==1&&(n.push(t[i]),s.push(i))}return{newShape:n,keptDims:s}}function so(t,e){return or(t,e)}function or(t,e){let n=null;if(t==null||t==="float32")n=new Float32Array(e);else if(t==="int32")n=new Int32Array(e);else if(t==="bool")n=new Uint8Array(e);else if(t==="string")n=new Array(e);else throw new Error(`Unknown data type ${t}`);return n}function ro(t,e){for(let n=0;n<t.length;n++){const s=t[n];if(isNaN(s)||!isFinite(s))throw Error(`A tensor of type ${e} being uploaded contains ${s}.`)}}function ao(t){return t==="bool"||t==="complex64"||t==="float32"||t==="int32"||t==="string"}function jp(t,e){return!(e==="complex64"||e==="float32"&&t!=="complex64"||e==="int32"&&t!=="float32"&&t!=="complex64"||e==="bool"&&t==="bool")}function Un(t){if(t==="float32"||t==="int32")return 4;if(t==="complex64")return 8;if(t==="bool")return 1;throw new Error(`Unknown dtype ${t}`)}function oo(t){if(t==null)return 0;let e=0;return t.forEach(n=>e+=n.length),e}function Qe(t){return typeof t=="string"||t instanceof String}function io(t){return typeof t=="boolean"}function uo(t){return typeof t=="number"}function mn(t){return Array.isArray(t)?mn(t[0]):t instanceof Float32Array?"float32":t instanceof Int32Array||t instanceof Uint8Array||t instanceof Uint8ClampedArray?"int32":uo(t)?"float32":Qe(t)?"string":io(t)?"bool":"float32"}function st(t){return!!(t&&t.constructor&&t.call&&t.apply)}function jn(t,e){for(let n=e;n<t;++n)if(t%n===0)return n;return t}function Ut(t){const e=t.length;if(e<2)return[];const n=new Array(e-1);n[e-2]=t[e-1];for(let s=e-3;s>=0;--s)n[s]=n[s+1]*t[s+1];return n}function co(t,e,n,s=!1){const r=new Array;if(e.length===1){const a=e[0]*(s?2:1);for(let o=0;o<a;o++)r[o]=n[t+o]}else{const a=e[0],o=e.slice(1),i=o.reduce((u,c)=>u*c)*(s?2:1);for(let u=0;u<a;u++)r[u]=co(t+u*i,o,n,s)}return r}function bt(t,e,n=!1){if(t.length===0)return e[0];const s=t.reduce((r,a)=>r*a)*(n?2:1);if(s===0)return[];if(s!==e.length)throw new Error(`[${t}] does not match the input size ${e.length}${n?" for a complex tensor":""}.`);return co(0,t,e,n)}function qp(t,e){if(Array.isArray(t))return t;if(e==="float32")return t instanceof Float32Array?t:new Float32Array(t);if(e==="int32")return t instanceof Int32Array?t:new Int32Array(t);if(e==="bool"||e==="string")return Uint8Array.from(new Int32Array(t));throw new Error(`Unknown dtype ${e}`)}function ir(t,e){const n=ns(t,e);for(let s=0;s<n.length;s++)n[s]=1;return n}function ns(t,e){if(e==null||e==="float32"||e==="complex64")return new Float32Array(t);if(e==="int32")return new Int32Array(t);if(e==="bool")return new Uint8Array(t);throw new Error(`Unknown data type ${e}`)}function Gp(t,e){const n=t.reduce((s,r)=>s*r,1);if(e==null||e==="float32")return bt(t,new Float32Array(n));if(e==="int32")return bt(t,new Int32Array(n));if(e==="bool")return bt(t,new Uint8Array(n));throw new Error(`Unknown data type ${e}`)}function $e(t){t.forEach(e=>{g(Number.isInteger(e)&&e>=0,()=>`Tensor must have a shape comprised of positive integers but got shape [${t}].`)})}function Hp(t,e,n){if(e===0)return 0;if(e===1)return t[0];let s=t[t.length-1];for(let r=0;r<t.length-1;++r)s+=n[r]*t[r];return s}function Kp(t,e,n){if(e===0)return[];if(e===1)return[t];const s=new Array(e);for(let r=0;r<s.length-1;++r)s[r]=Math.floor(t/n[r]),t-=s[r]*n[r];return s[s.length-1]=t,s}function rt(t){return t&&t.then&&typeof t.then=="function"}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const wa="tfjsflags";class lo{constructor(e){this.global=e,this.flags={},this.flagRegistry={},this.urlFlags={},this.getQueryParams=Xp,this.populateURLFlags()}setPlatform(e,n){this.platform!=null&&(P().getBool("IS_TEST")||P().getBool("PROD")||console.warn(`Platform ${this.platformName} has already been set. Overwriting the platform with ${e}.`)),this.platformName=e,this.platform=n}registerFlag(e,n,s){if(this.flagRegistry[e]={evaluationFn:n,setHook:s},this.urlFlags[e]!=null){const r=this.urlFlags[e];P().getBool("IS_TEST")||P().getBool("PROD")||console.warn(`Setting feature override from URL ${e}: ${r}.`),this.set(e,r)}}async getAsync(e){return e in this.flags?this.flags[e]:(this.flags[e]=await this.evaluateFlag(e),this.flags[e])}get(e){if(e in this.flags)return this.flags[e];const n=this.evaluateFlag(e);if(rt(n))throw new Error(`Flag ${e} cannot be synchronously evaluated. Please use getAsync() instead.`);return this.flags[e]=n,this.flags[e]}getNumber(e){return this.get(e)}getBool(e){return this.get(e)}getString(e){return this.get(e)}getFlags(){return this.flags}get features(){return this.flags}set(e,n){if(this.flagRegistry[e]==null)throw new Error(`Cannot set flag ${e} as it has not been registered.`);this.flags[e]=n,this.flagRegistry[e].setHook!=null&&this.flagRegistry[e].setHook(n)}evaluateFlag(e){if(this.flagRegistry[e]==null)throw new Error(`Cannot evaluate flag '${e}': no evaluation function found.`);return this.flagRegistry[e].evaluationFn()}setFlags(e){this.flags=Object.assign({},e)}reset(){this.flags={},this.urlFlags={},this.populateURLFlags()}populateURLFlags(){if(typeof this.global>"u"||typeof this.global.location>"u"||typeof this.global.location.search>"u")return;const e=this.getQueryParams(this.global.location.search);wa in e&&e[wa].split(",").forEach(s=>{const[r,a]=s.split(":");this.urlFlags[r]=Jp(r,a)})}}function Xp(t){const e={};return t.replace(/[?&]([^=?&]+)(?:=([^&]*))?/g,(n,...s)=>(Zp(e,s[0],s[1]),s.join("="))),e}function Zp(t,e,n){t[decodeURIComponent(e)]=decodeURIComponent(n||"")}function Jp(t,e){const n=e.toLowerCase();return n==="true"||n==="false"?n==="true":`${+n}`===n?+n:e}function P(){return ur}let ur=null;function Yp(t){ur=t}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */let Ns;function ho(){if(Ns==null){let t;if(typeof window<"u")t=window;else if(typeof global<"u")t=global;else if(typeof process<"u")t=process;else if(typeof self<"u")t=self;else throw new Error("Could not find a global object");Ns=t}return Ns}function Qp(){const t=ho();return t._tfGlobals==null&&(t._tfGlobals=new Map),t._tfGlobals}function cr(t,e){const n=Qp();if(n.has(t))return n.get(t);{const s=e();return n.set(t,s),n.get(t)}}const po="Abs",fo="Acos",mo="Acosh",lr="Add",go="AddN",yo="All",bo="Any",wo="ArgMax",No="ArgMin",So="Asin",To="Asinh",$o="Atan",Eo="Atanh",ko="Atan2",vo="AvgPool",ef="AvgPoolGrad",_o="AvgPool3D",tf="AvgPool3DGrad",Io="BatchMatMul",xo="BatchToSpaceND",Ao="Bincount",Oo="BitwiseAnd",nf="BroadcastTo",Do="BroadcastArgs",hr="Cast",Fo="Ceil",Co="ClipByValue",Ro="Complex",Lo="ComplexAbs",Bo="Concat",Po="Conv2D",zo="Conv2DBackpropFilter",Vo="Conv2DBackpropInput",Wo="Conv3D",sf="Conv3DBackpropFilterV2",Mo="Conv3DBackpropInputV2",Uo="Cos",jo="Cosh",qo="Cumprod",Go="Cumsum",Ho="CropAndResize",Ko="DenseBincount",Xo="DepthToSpace",Zo="DepthwiseConv2dNative",Jo="DepthwiseConv2dNativeBackpropFilter",Yo="DepthwiseConv2dNativeBackpropInput",Qo="Diag",ei="Dilation2D",rf="Dilation2DBackpropInput",af="Dilation2DBackpropFilter",pr="Draw",ti="RealDiv",ni="Einsum",si="Elu",of="EluGrad",ri="Erf",ai="Equal",oi="Exp",ii="ExpandDims",ui="Expm1",ci="FFT",li="Fill",hi="FlipLeftRight",pi="Floor",fi="FloorDiv",di="FusedBatchNorm",mi="GatherV2",gi="GatherNd",yi="Greater",bi="GreaterEqual",fr="Identity",wi="IFFT",Ni="Imag",Si="IsFinite",Ti="IsInf",$i="IsNan",Ei="LeakyRelu",ki="Less",vi="LessEqual",_i="LinSpace",Ii="Log",xi="Log1p",Ai="LogicalAnd",Oi="LogicalNot",Di="LogicalOr",uf="LogicalXor",cf="LogSoftmax",lf="LowerBound",Fi="LRN",hf="LRNGrad",pf="MatrixBandPart",Ci="Max",Ri="Maximum",Li="MaxPool",ff="MaxPoolGrad",Bi="MaxPool3D",df="MaxPool3DGrad",Pi="MaxPoolWithArgmax",zi="Mean",Vi="Min",Wi="Minimum",Mi="MirrorPad",Ui="Mod",ji="Multinomial",qi="Multiply",Gi="Neg",Hi="NotEqual",Ki="NonMaxSuppressionV3",Xi="NonMaxSuppressionV4",Zi="NonMaxSuppressionV5",Ji="OnesLike",Yi="OneHot",Qi="Pack",eu="PadV2",mf="Pool",tu="Pow",nu="Prelu",su="Prod",ru="RaggedGather",au="RaggedRange",ou="RaggedTensorToTensor",iu="Range",uu="Real",cu="Reciprocal",lu="Relu",hu="Reshape",pu="ResizeNearestNeighbor",gf="ResizeNearestNeighborGrad",fu="ResizeBilinear",yf="ResizeBilinearGrad",du="Relu6",mu="Reverse",gu="Round",yu="Rsqrt",bu="ScatterNd",wu="TensorScatterUpdate",Nu="SearchSorted",Su="Select",Tu="Selu",$u="Slice",Eu="Sin",ku="Sinh",vu="Sign",_u="Sigmoid",Iu="Softplus",xu="Sqrt",Au="Sum",Ou="SpaceToBatchND",Du="SplitV",Fu="Softmax",Cu="SparseFillEmptyRows",Ru="SparseReshape",Lu="SparseSegmentMean",Bu="SparseSegmentSum",Pu="SparseToDense",zu="SquaredDifference",bf="Square",Vu="StaticRegexReplace",Wu="StridedSlice",Mu="StringNGrams",Uu="StringSplit",ju="StringToHashBucketFast",qu="Sub",Gu="Tan",Hu="Tanh",dr="Tile",Ku="TopK",Xu="Transform",On="Transpose",Zu="Unique",Ju="Unpack",Yu="UnsortedSegmentSum",wf="UpperBound",Qu="ZerosLike",ec="Step",xs="FromPixels",tc="RotateWithOffset",As="_FusedMatMul",Os="FusedConv2D",Ds="FusedDepthwiseConv2D";/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Je(...t){P().getBool("IS_TEST")||P().getBool("PROD")||console.warn(...t)}function Nf(...t){P().getBool("IS_TEST")||P().getBool("PROD")||console.log(...t)}/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const Lt=cr("kernelRegistry",()=>new Map),en=cr("gradRegistry",()=>new Map);function tn(t,e){const n=mr(t,e);return Lt.get(n)}function Fs(t){return en.get(t)}function qn(t){const e=Lt.entries(),n=[];for(;;){const{done:s,value:r}=e.next();if(s)break;const[a,o]=r,[i]=a.split("_");i===t&&n.push(o)}return n}function nc(t){const{kernelName:e,backendName:n}=t,s=mr(e,n);Lt.has(s)&&Je(`The kernel '${e}' for backend '${n}' is already registered`),Lt.set(s,t)}function Sf(t){const{kernelName:e}=t;en.has(e)&&P().getBool("DEBUG")&&Je(`Overriding the gradient for '${e}'`),en.set(e,t)}function Tf(t,e){const n=mr(t,e);if(!Lt.has(n))throw new Error(`The kernel '${t}' for backend '${e}' is not registered`);Lt.delete(n)}function $f(t){if(!en.has(t))throw new Error(`The gradient '${t}' for backend is not registered`);en.delete(t)}function Ef(t,e){qn(t).forEach(s=>{const r=Object.assign({},s,{backendName:e});nc(r)})}function mr(t,e){return`${e}_${t}`}/**
 * @license
 * Copyright 2023 Google LLC.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function sc(t){return t instanceof Float32Array||t instanceof Int32Array||t instanceof Uint8Array||t instanceof Uint8ClampedArray}var Ss,Na;function kf(){if(Na)return Ss;Na=1,Ss=e;var t=null;try{t=new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([0,97,115,109,1,0,0,0,1,13,2,96,0,1,127,96,4,127,127,127,127,1,127,3,7,6,0,1,1,1,1,1,6,6,1,127,1,65,0,11,7,50,6,3,109,117,108,0,1,5,100,105,118,95,115,0,2,5,100,105,118,95,117,0,3,5,114,101,109,95,115,0,4,5,114,101,109,95,117,0,5,8,103,101,116,95,104,105,103,104,0,0,10,191,1,6,4,0,35,0,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,126,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,127,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,128,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,129,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,130,34,4,66,32,135,167,36,0,32,4,167,11])),{}).exports}catch{}function e(E,y,x){this.low=E|0,this.high=y|0,this.unsigned=!!x}e.prototype.__isLong__,Object.defineProperty(e.prototype,"__isLong__",{value:!0});function n(E){return(E&&E.__isLong__)===!0}e.isLong=n;var s={},r={};function a(E,y){var x,R,z;return y?(E>>>=0,(z=0<=E&&E<256)&&(R=r[E],R)?R:(x=i(E,(E|0)<0?-1:0,!0),z&&(r[E]=x),x)):(E|=0,(z=-128<=E&&E<128)&&(R=s[E],R)?R:(x=i(E,E<0?-1:0,!1),z&&(s[E]=x),x))}e.fromInt=a;function o(E,y){if(isNaN(E))return y?O:$;if(y){if(E<0)return O;if(E>=b)return L}else{if(E<=-9223372036854776e3)return C;if(E+1>=T)return F}return E<0?o(-E,y).neg():i(E%m|0,E/m|0,y)}e.fromNumber=o;function i(E,y,x){return new e(E,y,x)}e.fromBits=i;var u=Math.pow;function c(E,y,x){if(E.length===0)throw Error("empty string");if(E==="NaN"||E==="Infinity"||E==="+Infinity"||E==="-Infinity")return $;if(typeof y=="number"?(x=y,y=!1):y=!!y,x=x||10,x<2||36<x)throw RangeError("radix");var R;if((R=E.indexOf("-"))>0)throw Error("interior hyphen");if(R===0)return c(E.substring(1),y,x).neg();for(var z=o(u(x,8)),V=$,U=0;U<E.length;U+=8){var Y=Math.min(8,E.length-U),ae=parseInt(E.substring(U,U+Y),x);if(Y<8){var te=o(u(x,Y));V=V.mul(te).add(o(ae))}else V=V.mul(z),V=V.add(o(ae))}return V.unsigned=y,V}e.fromString=c;function h(E,y){return typeof E=="number"?o(E,y):typeof E=="string"?c(E,y):i(E.low,E.high,typeof y=="boolean"?y:E.unsigned)}e.fromValue=h;var l=65536,f=1<<24,m=l*l,b=m*m,T=b/2,S=a(f),$=a(0);e.ZERO=$;var O=a(0,!0);e.UZERO=O;var v=a(1);e.ONE=v;var _=a(1,!0);e.UONE=_;var A=a(-1);e.NEG_ONE=A;var F=i(-1,2147483647,!1);e.MAX_VALUE=F;var L=i(-1,-1,!0);e.MAX_UNSIGNED_VALUE=L;var C=i(0,-2147483648,!1);e.MIN_VALUE=C;var k=e.prototype;return k.toInt=function(){return this.unsigned?this.low>>>0:this.low},k.toNumber=function(){return this.unsigned?(this.high>>>0)*m+(this.low>>>0):this.high*m+(this.low>>>0)},k.toString=function(y){if(y=y||10,y<2||36<y)throw RangeError("radix");if(this.isZero())return"0";if(this.isNegative())if(this.eq(C)){var x=o(y),R=this.div(x),z=R.mul(x).sub(this);return R.toString(y)+z.toInt().toString(y)}else return"-"+this.neg().toString(y);for(var V=o(u(y,6),this.unsigned),U=this,Y="";;){var ae=U.div(V),te=U.sub(ae.mul(V)).toInt()>>>0,se=te.toString(y);if(U=ae,U.isZero())return se+Y;for(;se.length<6;)se="0"+se;Y=""+se+Y}},k.getHighBits=function(){return this.high},k.getHighBitsUnsigned=function(){return this.high>>>0},k.getLowBits=function(){return this.low},k.getLowBitsUnsigned=function(){return this.low>>>0},k.getNumBitsAbs=function(){if(this.isNegative())return this.eq(C)?64:this.neg().getNumBitsAbs();for(var y=this.high!=0?this.high:this.low,x=31;x>0&&(y&1<<x)==0;x--);return this.high!=0?x+33:x+1},k.isZero=function(){return this.high===0&&this.low===0},k.eqz=k.isZero,k.isNegative=function(){return!this.unsigned&&this.high<0},k.isPositive=function(){return this.unsigned||this.high>=0},k.isOdd=function(){return(this.low&1)===1},k.isEven=function(){return(this.low&1)===0},k.equals=function(y){return n(y)||(y=h(y)),this.unsigned!==y.unsigned&&this.high>>>31===1&&y.high>>>31===1?!1:this.high===y.high&&this.low===y.low},k.eq=k.equals,k.notEquals=function(y){return!this.eq(y)},k.neq=k.notEquals,k.ne=k.notEquals,k.lessThan=function(y){return this.comp(y)<0},k.lt=k.lessThan,k.lessThanOrEqual=function(y){return this.comp(y)<=0},k.lte=k.lessThanOrEqual,k.le=k.lessThanOrEqual,k.greaterThan=function(y){return this.comp(y)>0},k.gt=k.greaterThan,k.greaterThanOrEqual=function(y){return this.comp(y)>=0},k.gte=k.greaterThanOrEqual,k.ge=k.greaterThanOrEqual,k.compare=function(y){if(n(y)||(y=h(y)),this.eq(y))return 0;var x=this.isNegative(),R=y.isNegative();return x&&!R?-1:!x&&R?1:this.unsigned?y.high>>>0>this.high>>>0||y.high===this.high&&y.low>>>0>this.low>>>0?-1:1:this.sub(y).isNegative()?-1:1},k.comp=k.compare,k.negate=function(){return!this.unsigned&&this.eq(C)?C:this.not().add(v)},k.neg=k.negate,k.add=function(y){n(y)||(y=h(y));var x=this.high>>>16,R=this.high&65535,z=this.low>>>16,V=this.low&65535,U=y.high>>>16,Y=y.high&65535,ae=y.low>>>16,te=y.low&65535,se=0,ve=0,ue=0,Ee=0;return Ee+=V+te,ue+=Ee>>>16,Ee&=65535,ue+=z+ae,ve+=ue>>>16,ue&=65535,ve+=R+Y,se+=ve>>>16,ve&=65535,se+=x+U,se&=65535,i(ue<<16|Ee,se<<16|ve,this.unsigned)},k.subtract=function(y){return n(y)||(y=h(y)),this.add(y.neg())},k.sub=k.subtract,k.multiply=function(y){if(this.isZero())return $;if(n(y)||(y=h(y)),t){var x=t.mul(this.low,this.high,y.low,y.high);return i(x,t.get_high(),this.unsigned)}if(y.isZero())return $;if(this.eq(C))return y.isOdd()?C:$;if(y.eq(C))return this.isOdd()?C:$;if(this.isNegative())return y.isNegative()?this.neg().mul(y.neg()):this.neg().mul(y).neg();if(y.isNegative())return this.mul(y.neg()).neg();if(this.lt(S)&&y.lt(S))return o(this.toNumber()*y.toNumber(),this.unsigned);var R=this.high>>>16,z=this.high&65535,V=this.low>>>16,U=this.low&65535,Y=y.high>>>16,ae=y.high&65535,te=y.low>>>16,se=y.low&65535,ve=0,ue=0,Ee=0,_n=0;return _n+=U*se,Ee+=_n>>>16,_n&=65535,Ee+=V*se,ue+=Ee>>>16,Ee&=65535,Ee+=U*te,ue+=Ee>>>16,Ee&=65535,ue+=z*se,ve+=ue>>>16,ue&=65535,ue+=V*te,ve+=ue>>>16,ue&=65535,ue+=U*ae,ve+=ue>>>16,ue&=65535,ve+=R*se+z*te+V*ae+U*Y,ve&=65535,i(Ee<<16|_n,ve<<16|ue,this.unsigned)},k.mul=k.multiply,k.divide=function(y){if(n(y)||(y=h(y)),y.isZero())throw Error("division by zero");if(t){if(!this.unsigned&&this.high===-2147483648&&y.low===-1&&y.high===-1)return this;var x=(this.unsigned?t.div_u:t.div_s)(this.low,this.high,y.low,y.high);return i(x,t.get_high(),this.unsigned)}if(this.isZero())return this.unsigned?O:$;var R,z,V;if(this.unsigned){if(y.unsigned||(y=y.toUnsigned()),y.gt(this))return O;if(y.gt(this.shru(1)))return _;V=O}else{if(this.eq(C)){if(y.eq(v)||y.eq(A))return C;if(y.eq(C))return v;var U=this.shr(1);return R=U.div(y).shl(1),R.eq($)?y.isNegative()?v:A:(z=this.sub(y.mul(R)),V=R.add(z.div(y)),V)}else if(y.eq(C))return this.unsigned?O:$;if(this.isNegative())return y.isNegative()?this.neg().div(y.neg()):this.neg().div(y).neg();if(y.isNegative())return this.div(y.neg()).neg();V=$}for(z=this;z.gte(y);){R=Math.max(1,Math.floor(z.toNumber()/y.toNumber()));for(var Y=Math.ceil(Math.log(R)/Math.LN2),ae=Y<=48?1:u(2,Y-48),te=o(R),se=te.mul(y);se.isNegative()||se.gt(z);)R-=ae,te=o(R,this.unsigned),se=te.mul(y);te.isZero()&&(te=v),V=V.add(te),z=z.sub(se)}return V},k.div=k.divide,k.modulo=function(y){if(n(y)||(y=h(y)),t){var x=(this.unsigned?t.rem_u:t.rem_s)(this.low,this.high,y.low,y.high);return i(x,t.get_high(),this.unsigned)}return this.sub(this.div(y).mul(y))},k.mod=k.modulo,k.rem=k.modulo,k.not=function(){return i(~this.low,~this.high,this.unsigned)},k.and=function(y){return n(y)||(y=h(y)),i(this.low&y.low,this.high&y.high,this.unsigned)},k.or=function(y){return n(y)||(y=h(y)),i(this.low|y.low,this.high|y.high,this.unsigned)},k.xor=function(y){return n(y)||(y=h(y)),i(this.low^y.low,this.high^y.high,this.unsigned)},k.shiftLeft=function(y){return n(y)&&(y=y.toInt()),(y&=63)===0?this:y<32?i(this.low<<y,this.high<<y|this.low>>>32-y,this.unsigned):i(0,this.low<<y-32,this.unsigned)},k.shl=k.shiftLeft,k.shiftRight=function(y){return n(y)&&(y=y.toInt()),(y&=63)===0?this:y<32?i(this.low>>>y|this.high<<32-y,this.high>>y,this.unsigned):i(this.high>>y-32,this.high>=0?0:-1,this.unsigned)},k.shr=k.shiftRight,k.shiftRightUnsigned=function(y){if(n(y)&&(y=y.toInt()),y&=63,y===0)return this;var x=this.high;if(y<32){var R=this.low;return i(R>>>y|x<<32-y,x>>>y,this.unsigned)}else return y===32?i(x,0,this.unsigned):i(x>>>y-32,0,this.unsigned)},k.shru=k.shiftRightUnsigned,k.shr_u=k.shiftRightUnsigned,k.toSigned=function(){return this.unsigned?i(this.low,this.high,!1):this},k.toUnsigned=function(){return this.unsigned?this:i(this.low,this.high,!0)},k.toBytes=function(y){return y?this.toBytesLE():this.toBytesBE()},k.toBytesLE=function(){var y=this.high,x=this.low;return[x&255,x>>>8&255,x>>>16&255,x>>>24,y&255,y>>>8&255,y>>>16&255,y>>>24]},k.toBytesBE=function(){var y=this.high,x=this.low;return[y>>>24,y>>>16&255,y>>>8&255,y&255,x>>>24,x>>>16&255,x>>>8&255,x&255]},e.fromBytes=function(y,x,R){return R?e.fromBytesLE(y,x):e.fromBytesBE(y,x)},e.fromBytesLE=function(y,x){return new e(y[0]|y[1]<<8|y[2]<<16|y[3]<<24,y[4]|y[5]<<8|y[6]<<16|y[7]<<24,x)},e.fromBytesBE=function(y,x){return new e(y[4]<<24|y[5]<<16|y[6]<<8|y[7],y[0]<<24|y[1]<<16|y[2]<<8|y[3],x)},Ss}var rc=kf();const ac=_p(rc),vf=xp({__proto__:null,default:ac},[rc]);/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const dt=ac||vf;function gn(t){return dt.fromString(t,!0,16)}const oc=gn("c3a5c85c97cb3127"),ft=gn("b492b66fbe98f273"),fe=gn("9ae16a3b2f90404f");function Cs(t){return t.xor(t.shru(47))}function ic(t,e,n){const s=t.slice(e,e+n);return dt.fromBytes(Array.from(s),!0,!0)}function K(t,e){return ic(t,e,8)}function Sa(t,e){return ic(t,e,4)}function oe(t,e){return e===0?t:t.shru(e).or(t.shl(64-e))}function nt(t,e,n=gn("9ddfea08eb382d69")){let s=t.xor(e).mul(n);s=s.xor(s.shru(47));let r=e.xor(s).mul(n);return r=r.xor(r.shru(47)),r=r.mul(n),r}function _f(t,e,n,s,r,a){r=r.add(t),a=oe(a.add(r).add(s),21);const o=r;return r=r.add(e),r=r.add(n),a=a.add(oe(r,44)),[r.add(s),a.add(o)]}function In(t,e,n,s){return _f(K(t,e),K(t,e+8),K(t,e+16),K(t,e+24),n,s)}function If(t,e=t.length){if(e>=8){const n=fe.add(e*2),s=K(t,0).add(fe),r=K(t,e-8),a=oe(r,37).mul(n).add(s),o=oe(s,25).add(r).mul(n);return nt(a,o,n)}if(e>=4){const n=fe.add(e*2),s=Sa(t,0);return nt(s.shl(3).add(e),Sa(t,e-4),n)}if(e>0){const n=t[0],s=t[e>>1],r=t[e-1],a=n+(s<<8),o=e+(r<<2);return Cs(fe.mul(a).xor(oc.mul(o))).mul(fe)}return fe}function xf(t,e=t.length){const n=fe.add(e*2),s=K(t,0).mul(ft),r=K(t,8),a=K(t,e-8).mul(n),o=K(t,e-16).mul(fe);return nt(oe(s.add(r),43).add(oe(a,30)).add(o),s.add(oe(r.add(fe),18)).add(a),n)}function Af(t,e=t.length){const n=fe.add(e*2),s=K(t,0).mul(fe),r=K(t,8),a=K(t,e-8).mul(n),o=K(t,e-16).mul(fe),i=oe(s.add(r),43).add(oe(a,30)).add(o),u=nt(i,s.add(oe(r.add(fe),18)).add(a),n),c=K(t,16).mul(n),h=K(t,24),l=i.add(K(t,e-32)).mul(n),f=u.add(K(t,e-24)).mul(n);return nt(oe(c.add(h),43).add(oe(l,30)).add(f),c.add(oe(h.add(s),18)).add(l),n)}function Of(t,e=t.length){const n=dt.fromNumber(81,!0);if(e<=32)return e<=16?If(t,e):xf(t,e);if(e<=64)return Af(t,e);let s=n,r=n.mul(ft).add(113),a=Cs(r.mul(fe).add(113)).mul(fe),o=[dt.UZERO,dt.UZERO],i=[dt.UZERO,dt.UZERO];s=s.mul(fe).add(K(t,0));let u=0;const c=(e-1>>6)*64,h=c+(e-1&63)-63;do s=oe(s.add(r).add(o[0]).add(K(t,u+8)),37).mul(ft),r=oe(r.add(o[1]).add(K(t,u+48)),42).mul(ft),s=s.xor(i[1]),r=r.add(o[0]).add(K(t,u+40)),a=oe(a.add(i[0]),33).mul(ft),o=In(t,u,o[1].mul(ft),s.add(i[0])),i=In(t,u+32,a.add(i[1]),r.add(K(t,u+16))),[a,s]=[s,a],u+=64;while(u!==c);const l=ft.add(a.and(255).shl(1));return u=h,i[0]=i[0].add(e-1&63),o[0]=o[0].add(i[0]),i[0]=i[0].add(o[0]),s=oe(s.add(r).add(o[0]).add(K(t,u+8)),37).mul(l),r=oe(r.add(o[1]).add(K(t,u+48)),42).mul(l),s=s.xor(i[1].mul(9)),r=r.add(o[0].mul(9).add(K(t,u+40))),a=oe(a.add(i[0]),33).mul(l),o=In(t,u,o[1].mul(l),s.add(i[0])),i=In(t,u+32,a.add(i[1]),r.add(K(t,u+16))),[a,s]=[s,a],nt(nt(o[0],i[0],l).add(Cs(r).mul(oc)).add(a),nt(o[1],i[1],l).add(s),l)}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Df(t,e){return e==="string"?yn(t):ss([t],e)}function Ff(t,e){return t instanceof Float32Array&&e==="float32"||t instanceof Int32Array&&e==="int32"||t instanceof Uint8Array&&e==="bool"}function ss(t,e){if(e==="string")throw new Error("Cannot convert a string[] to a TypedArray");if(Array.isArray(t)&&(t=at(t)),P().getBool("DEBUG")&&ro(t,e),Ff(t,e))return t;if(e==null||e==="float32"||e==="complex64")return new Float32Array(t);if(e==="int32")return new Int32Array(t);if(e==="bool"){const n=new Uint8Array(t.length);for(let s=0;s<n.length;++s)Math.round(t[s])!==0&&(n[s]=1);return n}else throw new Error(`Unknown data type ${e}`)}function nn(){return P().platform.now()}function Cf(t,e){return P().platform.fetch(t,e)}function yn(t,e="utf-8"){return e=e||"utf-8",P().platform.encode(t,e)}function Gn(t,e="utf-8"){return e=e||"utf-8",P().platform.decode(t,e)}function ie(t){return P().platform.isTypedArray!=null?P().platform.isTypedArray(t):sc(t)}function at(t,e=[],n=!1){if(e==null&&(e=[]),typeof t=="boolean"||typeof t=="number"||typeof t=="string"||rt(t)||t==null||ie(t)&&n)e.push(t);else if(Array.isArray(t)||ie(t))for(let s=0;s<t.length;++s)at(t[s],e,n);else{let s=-1;for(const r of Object.keys(t))/^([1-9]+[0-9]*|0)$/.test(r)&&(s=Math.max(s,Number(r)));for(let r=0;r<=s;r++)at(t[r],e,n)}return e}const Rf=Object.freeze(Object.defineProperty({__proto__:null,arraysEqual:Ce,arraysEqualWithNull:to,assert:g,assertNonNegativeIntegerDimensions:$e,assertNonNull:It,assertShapesMatch:ge,bytesFromStringArray:oo,bytesPerElement:Un,checkConversionForErrors:ro,clamp:Qt,computeStrides:Ut,convertBackendValuesAndArrayBuffer:qp,createScalarValue:Df,createShuffledIndices:Wp,decodeString:Gn,distSquared:Bp,encodeString:yn,fetch:Cf,fingerPrint64:Of,flatten:at,getArrayFromDType:or,getTypedArrayFromDType:so,hasEncodingLoss:jp,hexToLong:gn,indexToLoc:Kp,inferDtype:mn,inferFromImplicitShape:Up,isBoolean:io,isFunction:st,isInt:Rt,isNumber:uo,isPromise:rt,isScalarShape:Pp,isString:Qe,isTypedArray:ie,isValidDtype:ao,locToIndex:Hp,makeOnesTypedArray:ir,makeZerosNestedTypedArray:Gp,makeZerosTypedArray:ns,nearestDivisor:jn,nearestLargerEven:Cp,now:nn,parseAxisParam:dn,randUniform:Lp,repeatedTry:Mp,rightPad:Jt,shuffle:eo,shuffleCombo:Fp,sizeFromShape:G,sizeToSquarishShape:Vp,squeezeShape:no,sum:Rp,swap:Mn,tanh:zp,toNestedArray:bt,toTypedArray:ss},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class Lf{constructor(e,n){this.backendTimer=e,this.logger=n,n==null&&(this.logger=new Pf)}profileKernel(e,n,s){let r;const a=()=>{r=s()};let o;const i=nn();if(this.backendTimer.timerAvailable())o=this.backendTimer.time(a);else{a();for(const c of r)c.dataSync();o=Promise.resolve({kernelMs:nn()-i})}if(P().getBool("CHECK_COMPUTATION_FOR_ERRORS"))for(let c=0;c<r.length;c++){const h=r[c];h.data().then(l=>{Bf(l,h.dtype,e)})}return{kernelName:e,outputs:r,inputs:n,timeMs:o.then(c=>c.kernelMs),extraInfo:o.then(c=>c.getExtraProfileInfo!=null?c.getExtraProfileInfo():"")}}logKernelProfile(e){const{kernelName:n,outputs:s,timeMs:r,inputs:a,extraInfo:o}=e;s.forEach(i=>{Promise.all([i.data(),r,o]).then(u=>{this.logger.logKernelProfile(n,i,u[0],u[1],a,u[2])})})}}function Bf(t,e,n){if(e!=="float32")return!1;for(let s=0;s<t.length;s++){const r=t[s];if(isNaN(r)||!isFinite(r))return console.warn(`Found ${r} in the result of '${n}'`),!0}return!1}class Pf{logKernelProfile(e,n,s,r,a,o){const i=typeof r=="number"?Jt(`${r}ms`,9):r.error,u=Jt(e,25),c=n.rank,h=n.size,l=Jt(n.shape.toString(),14);let f="";for(const m in a){const b=a[m];if(b!=null){const T=b.shape||n.shape,S=T.length;f+=`${m}: ${S}D ${S>0?T:""} `}}console.log(`%c${u}	%c${i}	%c${c}D ${l}	%c${h}	%c${f}	%c${o}`,"font-weight:bold","color:red","color:blue","color: orange","color: green","color: steelblue")}}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function zf(t,e,n){const s={},r={};for(let u=0;u<e.length;u++)s[e[u].id]=!0;for(let u=0;u<t.length;u++){const c=t[u],h=c.inputs;for(const l in h){const f=h[l];let m=!1;for(let b=0;b<e.length;b++)if(s[f.id]){c.outputs.forEach(T=>s[T.id]=!0),m=!0,r[c.id]=!0;break}if(m)break}}const a={};a[n.id]=!0;const o={};for(let u=t.length-1;u>=0;u--){const c=t[u],h=c.inputs;for(let l=0;l<c.outputs.length;l++)if(a[c.outputs[l].id]){for(const f in h)a[h[f].id]=!0,o[c.id]=!0;break}}const i=[];for(let u=0;u<t.length;u++){const c=t[u];if(r[c.id]&&o[c.id]){const h={};for(const f in c.inputs){const m=c.inputs[f];s[m.id]&&(h[f]=m)}const l=Object.assign({},c);l.inputs=h,l.outputs=c.outputs,i.push(l)}}return i}function Vf(t,e,n,s){for(let r=e.length-1;r>=0;r--){const a=e[r],o=[];if(a.outputs.forEach(u=>{const c=t[u.id];c!=null?o.push(c):o.push(null)}),a.gradient==null)throw new Error(`Cannot compute gradient: gradient function not found for ${a.kernelName}.`);const i=a.gradient(o);for(const u in a.inputs){if(!(u in i))throw new Error(`Cannot backprop through input ${u}. Available gradients found: ${Object.keys(i)}.`);const c=n(()=>i[u]());if(c.dtype!=="float32")throw new Error(`Error in gradient for op ${a.kernelName}. The gradient of input ${u} must have 'float32' dtype, but has '${c.dtype}'`);const h=a.inputs[u];if(!Ce(c.shape,h.shape))throw new Error(`Error in gradient for op ${a.kernelName}. The gradient of input '${u}' has shape '${c.shape}', which does not match the shape of the input '${h.shape}'`);if(t[h.id]==null)t[h.id]=c;else{const l=t[h.id];t[h.id]=s(l,c),l.dispose()}}}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const Ta=20,Ht=3,Ts=7;function Wf(t,e,n,s){const r=Ut(e),a=Mf(t,e,n,r),o=e.length,i=Dn(t,e,n,r,a),u=["Tensor"];return s&&(u.push(`  dtype: ${n}`),u.push(`  rank: ${o}`),u.push(`  shape: [${e}]`),u.push("  values:")),u.push(i.map(c=>"    "+c).join(`
`)),u.join(`
`)}function Mf(t,e,n,s){const r=G(e),a=s[s.length-1],o=new Array(a).fill(0),i=e.length,u=n==="complex64"?Zt(t):t;if(i>1)for(let c=0;c<r/a;c++){const h=c*a;for(let l=0;l<a;l++)o[l]=Math.max(o[l],Xt(u[h+l],0,n).length)}return o}function Xt(t,e,n){let s;return Array.isArray(t)?s=`${parseFloat(t[0].toFixed(Ts))} + ${parseFloat(t[1].toFixed(Ts))}j`:Qe(t)?s=`'${t}'`:n==="bool"?s=uc(t):s=parseFloat(t.toFixed(Ts)).toString(),Jt(s,e)}function uc(t){return t===0?"false":"true"}function Dn(t,e,n,s,r,a=!0){const o=n==="complex64"?2:1,i=e[0],u=e.length;if(u===0){if(n==="complex64"){const T=Zt(t);return[Xt(T[0],0,n)]}return n==="bool"?[uc(t[0])]:[t[0].toString()]}if(u===1){if(i>Ta){const S=Ht*o;let $=Array.from(t.slice(0,S)),O=Array.from(t.slice((i-Ht)*o,i*o));return n==="complex64"&&($=Zt($),O=Zt(O)),["["+$.map((v,_)=>Xt(v,r[_],n)).join(", ")+", ..., "+O.map((v,_)=>Xt(v,r[i-Ht+_],n)).join(", ")+"]"]}return["["+(n==="complex64"?Zt(t):Array.from(t)).map((S,$)=>Xt(S,r[$],n)).join(", ")+"]"]}const c=e.slice(1),h=s.slice(1),l=s[0]*o,f=[];if(i>Ta){for(let T=0;T<Ht;T++){const S=T*l,$=S+l;f.push(...Dn(t.slice(S,$),c,n,h,r,!1))}f.push("...");for(let T=i-Ht;T<i;T++){const S=T*l,$=S+l;f.push(...Dn(t.slice(S,$),c,n,h,r,T===i-1))}}else for(let T=0;T<i;T++){const S=T*l,$=S+l;f.push(...Dn(t.slice(S,$),c,n,h,r,T===i-1))}const m=u===2?",":"";f[0]="["+(i>0?f[0]+m:"");for(let T=1;T<f.length-1;T++)f[T]=" "+f[T]+m;let b=`,
`;for(let T=2;T<u;T++)b+=`
`;return f[f.length-1]=" "+f[f.length-1]+"]"+(a?"":b),f}function Zt(t){const e=[];for(let n=0;n<t.length;n+=2)e.push([t[n],t[n+1]]);return e}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class Hn{constructor(e,n,s){if(this.dtype=n,this.shape=e.slice(),this.size=G(e),s!=null){const r=s.length;g(r===this.size,()=>`Length of values '${r}' does not match the size inferred by the shape '${this.size}'.`)}if(n==="complex64")throw new Error("complex64 dtype TensorBuffers are not supported. Please create a TensorBuffer for the real and imaginary parts separately and call tf.complex(real, imag).");this.values=s||or(n,this.size),this.strides=Ut(e)}set(e,...n){n.length===0&&(n=[0]),g(n.length===this.rank,()=>`The number of provided coordinates (${n.length}) must match the rank (${this.rank})`);const s=this.locToIndex(n);this.values[s]=e}get(...e){e.length===0&&(e=[0]);let n=0;for(const r of e){if(r<0||r>=this.shape[n]){const a=`Requested out of range element at ${e}.   Buffer shape=${this.shape}`;throw new Error(a)}n++}let s=e[e.length-1];for(let r=0;r<e.length-1;++r)s+=this.strides[r]*e[r];return this.values[s]}locToIndex(e){if(this.rank===0)return 0;if(this.rank===1)return e[0];let n=e[e.length-1];for(let s=0;s<e.length-1;++s)n+=this.strides[s]*e[s];return n}indexToLoc(e){if(this.rank===0)return[];if(this.rank===1)return[e];const n=new Array(this.shape.length);for(let s=0;s<n.length-1;++s)n[s]=Math.floor(e/this.strides[s]),e-=n[s]*this.strides[s];return n[n.length-1]=e,n}get rank(){return this.shape.length}toTensor(){return Ae().makeTensor(this.values,this.shape,this.dtype)}}let Ae=null,xt=null;function Uf(t){Ae=t}function jf(t){xt=t}class ne{constructor(e,n,s,r){this.kept=!1,this.isDisposedInternal=!1,this.shape=e.slice(),this.dtype=n||"float32",this.size=G(e),this.strides=Ut(e),this.dataId=s,this.id=r,this.rankType=this.rank<5?this.rank.toString():"higher"}get rank(){return this.shape.length}async buffer(){const e=await this.data();return xt.buffer(this.shape,this.dtype,e)}bufferSync(){return xt.buffer(this.shape,this.dtype,this.dataSync())}async array(){const e=await this.data();return bt(this.shape,e,this.dtype==="complex64")}arraySync(){return bt(this.shape,this.dataSync(),this.dtype==="complex64")}async data(){this.throwIfDisposed();const e=Ae().read(this.dataId);if(this.dtype==="string"){const n=await e;try{return n.map(s=>Gn(s))}catch{throw new Error("Failed to decode the string bytes into utf-8. To get the original bytes, call tensor.bytes().")}}return e}dataToGPU(e){return this.throwIfDisposed(),Ae().readToGPU(this.dataId,e)}dataSync(){this.throwIfDisposed();const e=Ae().readSync(this.dataId);if(this.dtype==="string")try{return e.map(n=>Gn(n))}catch{throw new Error("Failed to decode the string bytes into utf-8. To get the original bytes, call tensor.bytes().")}return e}async bytes(){this.throwIfDisposed();const e=await Ae().read(this.dataId);return this.dtype==="string"?e:new Uint8Array(e.buffer)}dispose(){this.isDisposed||(this.kerasMask&&this.kerasMask.dispose(),Ae().disposeTensor(this),this.isDisposedInternal=!0)}get isDisposed(){return this.isDisposedInternal}throwIfDisposed(){if(this.isDisposed)throw new Error("Tensor is disposed.")}print(e=!1){return xt.print(this,e)}clone(){return this.throwIfDisposed(),xt.clone(this)}toString(e=!1){const n=this.dataSync();return Wf(n,this.shape,this.dtype,e)}cast(e){return this.throwIfDisposed(),xt.cast(this,e)}variable(e=!0,n,s){return this.throwIfDisposed(),Ae().makeVariable(this,e,n,s)}}Object.defineProperty(ne,Symbol.hasInstance,{value:t=>!!t&&t.data!=null&&t.dataSync!=null&&t.throwIfDisposed!=null});function cc(){return cr("Tensor",()=>ne)}cc();class sn extends ne{constructor(e,n,s,r){super(e.shape,e.dtype,e.dataId,r),this.trainable=n,this.name=s}assign(e){if(e.dtype!==this.dtype)throw new Error(`dtype of the new value (${e.dtype}) and previous value (${this.dtype}) must match`);if(!Ce(e.shape,this.shape))throw new Error(`shape of the new value (${e.shape}) and previous value (${this.shape}) must match`);Ae().disposeTensor(this),this.dataId=e.dataId,Ae().incRef(this,null)}dispose(){Ae().disposeVariable(this),this.isDisposedInternal=!0}}Object.defineProperty(sn,Symbol.hasInstance,{value:t=>t instanceof ne&&t.assign!=null&&t.assign instanceof Function});/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */var Rs;(function(t){t.R0="R0",t.R1="R1",t.R2="R2",t.R3="R3",t.R4="R4",t.R5="R5",t.R6="R6"})(Rs||(Rs={}));var Ls;(function(t){t.float32="float32",t.int32="int32",t.bool="int32",t.complex64="complex64"})(Ls||(Ls={}));var Bs;(function(t){t.float32="float32",t.int32="int32",t.bool="bool",t.complex64="complex64"})(Bs||(Bs={}));var Ps;(function(t){t.float32="float32",t.int32="float32",t.bool="float32",t.complex64="complex64"})(Ps||(Ps={}));var zs;(function(t){t.float32="complex64",t.int32="complex64",t.bool="complex64",t.complex64="complex64"})(zs||(zs={}));const qf={float32:Ps,int32:Ls,bool:Bs,complex64:zs};function rs(t,e){if(t==="string"||e==="string"){if(t==="string"&&e==="string")return"string";throw new Error(`Can not upcast ${t} with ${e}`)}return qf[t][e]}function Gf(t){return rs(t,"int32")}function lc(t){return t!=null&&typeof t=="object"&&"texture"in t&&t.texture instanceof WebGLTexture}function hc(t){return typeof GPUBuffer<"u"&&t!=null&&typeof t=="object"&&"buffer"in t&&t.buffer instanceof GPUBuffer}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ee(t,e){if(t.dtype===e.dtype)return[t,e];const n=rs(t.dtype,e.dtype);return[t.cast(n),e.cast(n)]}function pc(t,e){g(t.dtype===e.dtype,()=>`The dtypes of the first(${t.dtype}) and second(${e.dtype}) input must match`)}function Hf(t,e){return e.some(n=>n.id===t.id)}function gr(t){const e=[];return fc(t,e,new Set),e}function fc(t,e,n){if(t==null)return;if(t instanceof ne){e.push(t);return}if(!Kf(t))return;const s=t;for(const r in s){const a=s[r];n.has(a)||(n.add(a),fc(a,e,n))}}function Kf(t){return Array.isArray(t)||typeof t=="object"}const Xf=Object.freeze(Object.defineProperty({__proto__:null,assertTypesMatch:pc,getTensorsInContainer:gr,isTensorInList:Hf,makeTypesMatch:ee},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function $s(t){return t.kernelName!=null}class $a{constructor(){this.registeredVariables={},this.nextTapeNodeId=0,this.numBytes=0,this.numTensors=0,this.numStringTensors=0,this.numDataBuffers=0,this.gradientDepth=0,this.kernelDepth=0,this.scopeStack=[],this.numDataMovesStack=[],this.nextScopeId=0,this.tensorInfo=new WeakMap,this.profiling=!1,this.activeProfile={newBytes:0,newTensors:0,peakBytes:0,kernels:[],result:null,get kernelNames(){return Array.from(new Set(this.kernels.map(e=>e.name)))}}}dispose(){for(const e in this.registeredVariables)this.registeredVariables[e].dispose()}}class Bt{constructor(e){this.ENV=e,this.registry={},this.registryFactory={},this.pendingBackendInitId=0,this.state=new $a}async ready(){if(this.pendingBackendInit!=null)return this.pendingBackendInit.then(()=>{});if(this.backendInstance!=null)return;const e=this.getSortedBackends();for(let n=0;n<e.length;n++){const s=e[n];if(await this.initializeBackend(s).success){await this.setBackend(s);return}}throw new Error("Could not initialize any backends, all backend initializations failed.")}get backend(){if(this.pendingBackendInit!=null)throw new Error(`Backend '${this.backendName}' has not yet been initialized. Make sure to await tf.ready() or await tf.setBackend() before calling other methods`);if(this.backendInstance==null){const{name:e,asyncInit:n}=this.initializeBackendsAndReturnBest();if(n)throw new Error(`The highest priority backend '${e}' has not yet been initialized. Make sure to await tf.ready() or await tf.setBackend() before calling other methods`);this.setBackend(e)}return this.backendInstance}backendNames(){return Object.keys(this.registryFactory)}findBackend(e){if(!(e in this.registry))if(e in this.registryFactory){const{asyncInit:n}=this.initializeBackend(e);if(n)return null}else return null;return this.registry[e]}findBackendFactory(e){return e in this.registryFactory?this.registryFactory[e].factory:null}registerBackend(e,n,s=1){return e in this.registryFactory?(Je(`${e} backend was already registered. Reusing existing backend factory.`),!1):(this.registryFactory[e]={factory:n,priority:s},!0)}async setBackend(e){if(this.registryFactory[e]==null)throw new Error(`Backend name '${e}' not found in registry`);if(this.backendName=e,this.registry[e]==null){this.backendInstance=null;const{success:n,asyncInit:s}=this.initializeBackend(e);if(!(s?await n:n))return!1}return this.backendInstance=this.registry[e],this.setupRegisteredKernels(),this.profiler=new Lf(this.backendInstance),!0}setupRegisteredKernels(){qn(this.backendName).forEach(n=>{n.setupFunc!=null&&n.setupFunc(this.backendInstance)})}disposeRegisteredKernels(e){qn(e).forEach(s=>{s.disposeFunc!=null&&s.disposeFunc(this.registry[e])})}initializeBackend(e){const n=this.registryFactory[e];if(n==null)throw new Error(`Cannot initialize backend ${e}, no registration found.`);try{const s=n.factory();if(s&&!(s instanceof Qa)&&typeof s.then=="function"){const r=++this.pendingBackendInitId,a=s.then(o=>r<this.pendingBackendInitId?!1:(this.registry[e]=o,this.pendingBackendInit=null,!0)).catch(o=>(r<this.pendingBackendInitId||(this.pendingBackendInit=null,Je(`Initialization of backend ${e} failed`),Je(o.stack||o.message)),!1));return this.pendingBackendInit=a,{success:a,asyncInit:!0}}else return this.registry[e]=s,{success:!0,asyncInit:!1}}catch(s){return Je(`Initialization of backend ${e} failed`),Je(s.stack||s.message),{success:!1,asyncInit:!1}}}removeBackend(e){if(!(e in this.registryFactory))throw new Error(`${e} backend not found in registry`);this.backendName===e&&this.pendingBackendInit!=null&&this.pendingBackendInitId++,e in this.registry&&(this.disposeRegisteredKernels(e),this.registry[e].dispose(),delete this.registry[e]),delete this.registryFactory[e],this.backendName===e&&(this.pendingBackendInit=null,this.backendName=null,this.backendInstance=null)}getSortedBackends(){if(Object.keys(this.registryFactory).length===0)throw new Error("No backend found in registry.");return Object.keys(this.registryFactory).sort((e,n)=>this.registryFactory[n].priority-this.registryFactory[e].priority)}initializeBackendsAndReturnBest(){const e=this.getSortedBackends();for(let n=0;n<e.length;n++){const s=e[n],{success:r,asyncInit:a}=this.initializeBackend(s);if(a||r)return{name:s,asyncInit:a}}throw new Error("Could not initialize any backends, all backend initializations failed.")}moveData(e,n){const s=this.state.tensorInfo.get(n),r=s.backend,a=this.readSync(n),o=r.refCount(n);r.disposeData(n,!0),s.backend=e,e.move(n,a,s.shape,s.dtype,o),this.shouldCheckForMemLeaks()&&this.state.numDataMovesStack[this.state.numDataMovesStack.length-1]++}tidy(e,n){let s=null;if(n==null){if(typeof e!="function")throw new Error("Please provide a function to tidy()");n=e}else{if(typeof e!="string"&&!(e instanceof String))throw new Error("When calling with two arguments, the first argument to tidy() must be a string");if(typeof n!="function")throw new Error("When calling with two arguments, the 2nd argument to tidy() must be a function");s=e}let r;return this.scopedRun(()=>this.startScope(s),()=>this.endScope(r),()=>(r=n(),r instanceof Promise&&console.error("Cannot return a Promise inside of tidy."),r))}scopedRun(e,n,s){e();try{const r=s();return n(),r}catch(r){throw n(),r}}nextTensorId(){return Bt.nextTensorId++}nextVariableId(){return Bt.nextVariableId++}clone(e){const n=N.runKernel(fr,{x:e}),s={x:e},r=o=>({x:()=>{const i="float32",u={x:o},c={dtype:i};return N.runKernel(hr,u,c)}}),a=[];return this.addTapeNode(this.state.activeScope.name,s,[n],r,a,{}),n}runKernel(e,n,s){if(this.backendName==null&&this.backend,!(tn(e,this.backendName)!=null))throw new Error(`Kernel '${e}' not registered for backend '${this.backendName}'`);return this.runKernelFunc({kernelName:e,inputs:n,attrs:s})}shouldCheckForMemLeaks(){return this.ENV.getBool("IS_TEST")}checkKernelForMemLeak(e,n,s){const r=this.backend.numDataIds();let a=0;s.forEach(u=>{a+=u.dtype==="complex64"?3:1});const o=this.state.numDataMovesStack[this.state.numDataMovesStack.length-1],i=r-n-a-o;if(i>0)throw new Error(`Backend '${this.backendName}' has an internal memory leak (${i} data ids) after running '${e}'`)}runKernelFunc(e){let n,s=[];const r=this.isTapeOn(),a=this.state.numBytes,o=this.state.numTensors;this.shouldCheckForMemLeaks()&&this.state.numDataMovesStack.push(0);let i;this.backendName==null&&this.backend;let u;const c=$s(e)?e.kernelName:this.state.activeScope!=null?this.state.activeScope.name:"";if($s(e)){const{kernelName:b,inputs:T,attrs:S}=e;this.backendName==null&&this.backend;const $=tn(b,this.backendName);g($!=null,()=>`Cannot find registered kernel '${b}' for backend '${this.backendName}'`),i=()=>{const O=this.backend.numDataIds();u=$.kernelFunc({inputs:T,attrs:S,backend:this.backend});const v=Array.isArray(u)?u:[u];this.shouldCheckForMemLeaks()&&this.checkKernelForMemLeak(b,O,v);const _=v.map(A=>A.rank!=null?A:this.makeTensorFromTensorInfo(A));if(r){const A=this.getTensorsForGradient(b,T,_);s=this.saveTensorsForBackwardMode(A)}return _}}else{const{forwardFunc:b}=e,T=S=>{r&&(s=S.map($=>this.keep(this.clone($))))};i=()=>{const S=this.backend.numDataIds();u=this.tidy(()=>b(this.backend,T));const $=Array.isArray(u)?u:[u];return this.shouldCheckForMemLeaks()&&this.checkKernelForMemLeak(c,S,$),$}}const{inputs:h,attrs:l}=e,f=$s(e)?null:e.backwardsFunc;let m;return this.scopedRun(()=>this.state.kernelDepth++,()=>this.state.kernelDepth--,()=>{!this.ENV.getBool("DEBUG")&&!this.state.profiling?n=i():(m=this.profiler.profileKernel(c,h,()=>i()),this.ENV.getBool("DEBUG")&&this.profiler.logKernelProfile(m),n=m.outputs)}),r&&this.addTapeNode(c,h,n,f,s,l),this.state.profiling&&this.state.activeProfile.kernels.push({name:c,bytesAdded:this.state.numBytes-a,totalBytesSnapshot:this.state.numBytes,tensorsAdded:this.state.numTensors-o,totalTensorsSnapshot:this.state.numTensors,inputShapes:Object.keys(h).map(b=>h[b]!=null?h[b].shape:null),outputShapes:n.map(b=>b.shape),kernelTimeMs:m.timeMs,extraInfo:m.extraInfo}),Array.isArray(u)?n:n[0]}saveTensorsForBackwardMode(e){return e.map(s=>this.keep(this.clone(s)))}getTensorsForGradient(e,n,s){const r=Fs(e);if(r!=null){const a=r.inputsToSave||[],o=r.outputsToSave||[];let i;r.saveAllInputs?(g(Array.isArray(n),()=>"saveAllInputs is true, expected inputs to be an array."),i=Object.keys(n).map(c=>n[c])):i=a.map(c=>n[c]);const u=s.filter((c,h)=>o[h]);return i.concat(u)}return[]}makeTensor(e,n,s,r){if(e==null)throw new Error("Values passed to engine.makeTensor() are null");s=s||"float32",r=r||this.backend;let a=e;s==="string"&&Qe(e[0])&&(a=e.map(u=>yn(u)));const o=r.write(a,n,s),i=new ne(n,s,o,this.nextTensorId());if(this.trackTensor(i,r),s==="string"){const u=this.state.tensorInfo.get(o),c=oo(a);this.state.numBytes+=c-u.bytes,u.bytes=c}return i}makeTensorFromDataId(e,n,s,r){s=s||"float32";const a={dataId:e,shape:n,dtype:s};return this.makeTensorFromTensorInfo(a,r)}makeTensorFromTensorInfo(e,n){const{dataId:s,shape:r,dtype:a}=e,o=new ne(r,a,s,this.nextTensorId());return this.trackTensor(o,n),o}makeVariable(e,n=!0,s,r){s=s||this.nextVariableId().toString(),r!=null&&r!==e.dtype&&(e=e.cast(r));const a=new sn(e,n,s,this.nextTensorId());if(this.state.registeredVariables[a.name]!=null)throw new Error(`Variable with name ${a.name} was already registered`);return this.state.registeredVariables[a.name]=a,this.incRef(a,this.backend),a}trackTensor(e,n){this.state.numTensors++,e.dtype==="string"&&this.state.numStringTensors++;let s=0;e.dtype!=="complex64"&&e.dtype!=="string"&&(s=e.size*Un(e.dtype)),this.state.numBytes+=s,this.state.tensorInfo.has(e.dataId)||(this.state.numDataBuffers++,this.state.tensorInfo.set(e.dataId,{backend:n||this.backend,dtype:e.dtype,shape:e.shape,bytes:s})),e instanceof sn||this.track(e)}incRef(e,n){this.trackTensor(e,n),this.backend.incRef(e.dataId)}removeDataId(e,n){this.state.tensorInfo.has(e)&&this.state.tensorInfo.get(e).backend===n&&(this.state.tensorInfo.delete(e),this.state.numDataBuffers--)}disposeTensor(e){if(!this.state.tensorInfo.has(e.dataId))return;const n=this.state.tensorInfo.get(e.dataId);if(this.state.numTensors--,e.dtype==="string"&&(this.state.numStringTensors--,this.state.numBytes-=n.bytes),e.dtype!=="complex64"&&e.dtype!=="string"){const s=e.size*Un(e.dtype);this.state.numBytes-=s}n.backend.disposeData(e.dataId)&&this.removeDataId(e.dataId,n.backend)}disposeVariables(){for(const e in this.state.registeredVariables){const n=this.state.registeredVariables[e];this.disposeVariable(n)}}disposeVariable(e){this.disposeTensor(e),this.state.registeredVariables[e.name]!=null&&delete this.state.registeredVariables[e.name]}memory(){const e=this.backend.memory();return e.numTensors=this.state.numTensors,e.numDataBuffers=this.state.numDataBuffers,e.numBytes=this.state.numBytes,this.state.numStringTensors>0&&(e.unreliable=!0,e.reasons==null&&(e.reasons=[]),e.reasons.push("Memory usage by string tensors is approximate (2 bytes per character)")),e}async profile(e){this.state.profiling=!0;const n=this.state.numBytes,s=this.state.numTensors;this.state.activeProfile.kernels=[],this.state.activeProfile.result=await e(),this.state.profiling=!1,this.state.activeProfile.peakBytes=Math.max(...this.state.activeProfile.kernels.map(r=>r.totalBytesSnapshot)),this.state.activeProfile.newBytes=this.state.numBytes-n,this.state.activeProfile.newTensors=this.state.numTensors-s;for(const r of this.state.activeProfile.kernels)r.kernelTimeMs=await r.kernelTimeMs,r.extraInfo=await r.extraInfo;return this.state.activeProfile}isTapeOn(){return this.state.gradientDepth>0&&this.state.kernelDepth===0}addTapeNode(e,n,s,r,a,o){const i={id:this.state.nextTapeNodeId++,kernelName:e,inputs:n,outputs:s,saved:a},u=Fs(e);u!=null&&(r=u.gradFunc),r!=null&&(i.gradient=c=>(c=c.map((h,l)=>{if(h==null){const f=s[l],m=ns(f.size,f.dtype);return this.makeTensor(m,f.shape,f.dtype)}return h}),r(c.length>1?c:c[0],a,o))),this.state.activeTape.push(i)}keep(e){return e.kept=!0,e}startTape(){this.state.gradientDepth===0&&(this.state.activeTape=[]),this.state.gradientDepth++}endTape(){this.state.gradientDepth--}startScope(e){const n={track:[],name:"unnamed scope",id:this.state.nextScopeId++};e&&(n.name=e),this.state.scopeStack.push(n),this.state.activeScope=n}endScope(e){const n=gr(e),s=new Set(n.map(a=>a.id));for(let a=0;a<this.state.activeScope.track.length;a++){const o=this.state.activeScope.track[a];!o.kept&&!s.has(o.id)&&o.dispose()}const r=this.state.scopeStack.pop();this.state.activeScope=this.state.scopeStack.length===0?null:this.state.scopeStack[this.state.scopeStack.length-1],n.forEach(a=>{!a.kept&&a.scopeId===r.id&&this.track(a)})}gradients(e,n,s,r=!1){if(g(n.length>0,()=>"gradients() received an empty list of xs."),s!=null&&s.dtype!=="float32")throw new Error(`dy must have 'float32' dtype, but has '${s.dtype}'`);const a=this.scopedRun(()=>this.startTape(),()=>this.endTape(),()=>this.tidy("forward",e));g(a instanceof ne,()=>"The result y returned by f() must be a tensor.");const o=zf(this.state.activeTape,n,a);if(!r&&o.length===0&&n.length>0)throw new Error("Cannot compute gradient of y=f(x) with respect to x. Make sure that the f you passed encloses all operations that lead from x to y.");return this.tidy("backward",()=>{const i={};i[a.id]=s??Zf(a.shape),Vf(i,o,c=>this.tidy(c),Jf);const u=n.map(c=>i[c.id]);return this.state.gradientDepth===0&&(this.state.activeTape.forEach(c=>{for(const h of c.saved)h.dispose()}),this.state.activeTape=null),{value:a,grads:u}})}customGrad(e){return g(st(e),()=>"The f passed in customGrad(f) must be a function."),(...n)=>{g(n.every(i=>i instanceof ne),()=>"The args passed in customGrad(f)(x1, x2,...) must all be tensors");let s;const r={};n.forEach((i,u)=>{r[u]=i});const a=(i,u)=>(s=e(...n,u),g(s.value instanceof ne,()=>"The function f passed in customGrad(f) must return an object where `obj.value` is a tensor"),g(st(s.gradFunc),()=>"The function f passed in customGrad(f) must return an object where `obj.gradFunc` is a function."),s.value),o=(i,u)=>{const c=s.gradFunc(i,u),h=Array.isArray(c)?c:[c];g(h.length===n.length,()=>"The function f passed in customGrad(f) must return an object where `obj.gradFunc` is a function that returns the same number of tensors as inputs passed to f(...)."),g(h.every(f=>f instanceof ne),()=>"The function f passed in customGrad(f) must return an object where `obj.gradFunc` is a function that returns a list of only tensors.");const l={};return h.forEach((f,m)=>{l[m]=()=>f}),l};return this.runKernelFunc({forwardFunc:a,backwardsFunc:o,inputs:r})}}readSync(e){return this.state.tensorInfo.get(e).backend.readSync(e)}read(e){return this.state.tensorInfo.get(e).backend.read(e)}readToGPU(e,n){return this.state.tensorInfo.get(e).backend.readToGPU(e,n)}async time(e){const n=nn(),s=await this.backend.time(e);return s.wallMs=nn()-n,s}track(e){return this.state.activeScope!=null&&(e.scopeId=this.state.activeScope.id,this.state.activeScope.track.push(e)),e}get registeredVariables(){return this.state.registeredVariables}reset(){this.pendingBackendInitId++,this.state.dispose(),this.ENV.reset(),this.state=new $a;for(const e in this.registry)this.disposeRegisteredKernels(e),this.registry[e].dispose(),delete this.registry[e];this.backendName=null,this.backendInstance=null,this.pendingBackendInit=null}}Bt.nextTensorId=0;Bt.nextVariableId=0;function Zf(t){const e=ir(G(t),"float32");return N.makeTensor(e,t,"float32")}function dc(){const t=ho();if(t._tfengine==null){const e=new lo(t);t._tfengine=new Bt(e)}return Yp(t._tfengine.ENV),Uf(()=>t._tfengine),t._tfengine}const N=dc();function Jf(t,e){const n={a:t,b:e};return N.runKernel(lr,n)}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Yf(){return typeof navigator<"u"&&navigator!=null}let Vs;function Qf(t){Vs=t}function ed(t){if(Vs!==void 0)return Vs;if(t||Yf()){if(t||(t=navigator),t.product==="ReactNative")return!0;const e=t.userAgent||t.vendor||(typeof window<"u"?window.opera:"");if(!e){const n=t;return n.userAgentData&&n.userAgentData.mobile}return/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(e)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(e.substr(0,4))}return!1}function mc(){return typeof window<"u"&&window.document!=null||typeof WorkerGlobalScope<"u"}const td=Object.freeze(Object.defineProperty({__proto__:null,isBrowser:mc,isMobile:ed,mockIsMobile:Qf},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const ye=P();ye.registerFlag("DEBUG",()=>!1,t=>{t&&console.warn("Debugging mode is ON. The output of every math call will be downloaded to CPU and checked for NaNs. This significantly impacts performance.")});ye.registerFlag("IS_BROWSER",()=>mc());ye.registerFlag("IS_NODE",()=>typeof process<"u"&&typeof process.versions<"u"&&typeof process.versions.node<"u");ye.registerFlag("IS_CHROME",()=>typeof navigator<"u"&&navigator!=null&&navigator.userAgent!=null&&/Chrome/.test(navigator.userAgent)&&/Google Inc/.test(navigator.vendor));ye.registerFlag("IS_SAFARI",()=>typeof navigator<"u"&&navigator!=null&&navigator.userAgent!=null&&/Safari/.test(navigator.userAgent)&&/Apple/.test(navigator.vendor));ye.registerFlag("PROD",()=>!1);ye.registerFlag("TENSORLIKE_CHECK_SHAPE_CONSISTENCY",()=>ye.getBool("DEBUG"));ye.registerFlag("DEPRECATION_WARNINGS_ENABLED",()=>!0);ye.registerFlag("IS_TEST",()=>!1);ye.registerFlag("CHECK_COMPUTATION_FOR_ERRORS",()=>ye.getBool("DEBUG"));ye.registerFlag("WRAP_TO_IMAGEBITMAP",()=>!1);ye.registerFlag("CANVAS2D_WILL_READ_FREQUENTLY_FOR_GPU",()=>!1);ye.registerFlag("USE_SETTIMEOUTCUSTOM",()=>!1);/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Be(t,e){let n=t;if(ie(t))return e==="string"?[]:[t.length];if(lc(t)){const r=t.channels||"RGBA";return[t.height,t.width*r.length]}else if(hc(t))return[t.buffer.size/(e==null?4:Un(e))];if(!Array.isArray(t))return[];const s=[];for(;Array.isArray(n)||ie(n)&&e!=="string";)s.push(n.length),n=n[0];return Array.isArray(t)&&P().getBool("TENSORLIKE_CHECK_SHAPE_CONSISTENCY")&&gc(t,s,[]),s}function gc(t,e,n){if(n=n||[],!Array.isArray(t)&&!ie(t)){g(e.length===0,()=>`Element arr[${n.join("][")}] is a primitive, but should be an array/TypedArray of ${e[0]} elements`);return}g(e.length>0,()=>`Element arr[${n.join("][")}] should be a primitive, but is an array of ${t.length} elements`),g(t.length===e[0],()=>`Element arr[${n.join("][")}] should have ${e[0]} elements, but has ${t.length} elements`);const s=e.slice(1);for(let r=0;r<t.length;++r)gc(t[r],s,n.concat(r))}function Ea(t,e,n,s){if(t!=="string_or_numeric"){if(t==null)throw new Error("Expected dtype cannot be null.");if(t!=="numeric"&&t!==e||t==="numeric"&&e==="string")throw new Error(`Argument '${n}' passed to '${s}' must be ${t} tensor, but got ${e} tensor`)}}function d(t,e,n,s="numeric"){if(t instanceof cc())return Ea(s,t.dtype,e,n),t;let r=mn(t);if(r!=="string"&&["bool","int32","float32"].indexOf(s)>=0&&(r=s),Ea(s,r,e,n),t==null||!ie(t)&&!Array.isArray(t)&&typeof t!="number"&&typeof t!="boolean"&&typeof t!="string"){const u=t==null?"null":t.constructor.name;throw new Error(`Argument '${e}' passed to '${n}' must be a Tensor or TensorLike, but got '${u}'`)}const a=Be(t,r);!ie(t)&&!Array.isArray(t)&&(t=[t]);const i=r!=="string"?ss(t,r):at(t,[],!0);return N.makeTensor(i,a,r)}function rn(t,e,n,s="numeric"){if(!Array.isArray(t))throw new Error(`Argument ${e} passed to ${n} must be a \`Tensor[]\` or \`TensorLike[]\``);return t.map((a,o)=>d(a,`${e}[${o}]`,n,s))}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const yr="__op";function w(t){const e=Object.keys(t);if(e.length!==1)throw new Error(`Please provide an object with a single key (operation name) mapping to a function. Got an object with ${e.length} keys.`);let n=e[0];const s=t[n];n.endsWith("_")&&(n=n.substring(0,n.length-1)),n=n+yr;const r=(...a)=>{N.startScope(n);try{const o=s(...a);return rt(o)&&console.error("Cannot return a Promise inside of tidy."),N.endScope(o),o}catch(o){throw N.endScope(null),o}};return Object.defineProperty(r,"name",{value:n,configurable:!0}),r}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function nd(t,e){const n=d(t,"real","complex"),s=d(e,"imag","complex");ge(n.shape,s.shape,`real and imag shapes, ${n.shape} and ${s.shape}, must match in call to tf.complex().`);const r={real:n,imag:s};return N.runKernel(Ro,r)}const Ke=w({complex_:nd});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ct(t,e,n,s){if(s==null)s=mn(t);else if(s==="complex64")throw new Error("Cannot construct a complex64 tensor directly. Please use tf.complex(real, imag).");if(hc(t)||lc(t)){if(s!=="float32"&&s!=="int32")throw new Error(`Creating tensor from GPU data only supports 'float32'|'int32' dtype, while the dtype is ${s}.`);return N.backend.createTensorFromGPUData(t,e||n,s)}if(!ie(t)&&!Array.isArray(t)&&typeof t!="number"&&typeof t!="boolean"&&typeof t!="string")throw new Error("values passed to tensor(values) must be a number/boolean/string or an array of numbers/booleans/strings, or a TypedArray");if(e!=null){$e(e);const r=G(e),a=G(n);g(r===a,()=>`Based on the provided shape, [${e}], the tensor should have ${r} values but has ${a}`);for(let o=0;o<n.length;++o){const i=n[o],u=o===n.length-1?i!==G(e.slice(o)):!0;g(n[o]===e[o]||!u,()=>`Error creating a new Tensor. Inferred shape (${n}) does not match the provided shape (${e}). `)}}return!ie(t)&&!Array.isArray(t)&&(t=[t]),e=e||n,t=s!=="string"?ss(t,s):at(t,[],!0),N.makeTensor(t,e,s)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function De(t,e,n){const s=Be(t,n);return ct(t,e,s,n)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const St={float32:4,float16:2,int32:4,uint16:2,uint8:1,bool:1,complex64:8};class Re{static join(e){return new Re(e).slice()}constructor(e){if(this.shards=[],this.previousShardIndex=0,e==null||(e instanceof Array||(e=[e]),e=e.map(s=>ie(s)?s.buffer:s),e.length===0))return;this.bufferUniformSize=e[0].byteLength;let n=0;for(let s=0;s<e.length;s++){const r=e[s];s!==e.length-1&&r.byteLength!==this.bufferUniformSize&&(this.bufferUniformSize=void 0);const a=n+r.byteLength;this.shards.push({buffer:r,start:n,end:a}),n=a}this.shards.length===0&&(this.byteLength=0),this.byteLength=this.shards[this.shards.length-1].end}slice(e=0,n=this.byteLength){if(this.shards.length===0)return new ArrayBuffer(0);if(e=isNaN(Number(e))?0:e,n=isNaN(Number(n))?0:n,e=Math.max(0,e),n=Math.min(this.byteLength,n),n<=e)return new ArrayBuffer(0);const s=this.findShardForByte(e);if(s===-1)throw new Error(`Could not find start shard for byte ${e}`);const r=n-e,a=new ArrayBuffer(r),o=new Uint8Array(a);let i=0;for(let u=s;u<this.shards.length;u++){const c=this.shards[u],l=e+i-c.start,f=i,b=Math.min(n,c.end)-c.start,T=new Uint8Array(c.buffer,l,b-l);if(o.set(T,f),i+=T.length,n<c.end)break}return a}findShardForByte(e){if(this.shards.length===0||e<0||e>=this.byteLength)return-1;if(this.bufferUniformSize!=null)return this.previousShardIndex=Math.floor(e/this.bufferUniformSize),this.previousShardIndex;function n(r){return e<r.start?-1:e>=r.end?1:0}if(n(this.shards[this.previousShardIndex])===0)return this.previousShardIndex;const s=sd(this.shards,n);return s===-1?-1:(this.previousShardIndex=s,this.previousShardIndex)}}function sd(t,e){let n=0,s=t.length;for(;n<=s;){const r=Math.floor((s-n)/2)+n,a=e(t[r]);if(a===0)return r;a<0?s=r:n=r+1}return-1}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function rd(){P().set("PROD",!0)}function ad(){P().set("DEBUG",!0)}function od(){P().set("DEPRECATION_WARNINGS_ENABLED",!1),console.warn("TensorFlow.js deprecation warnings have been disabled.")}function id(t){P().getBool("DEPRECATION_WARNINGS_ENABLED")&&console.warn(t+" You can disable deprecation warnings with tf.disableDeprecationWarnings().")}function ud(){N.disposeVariables()}function cd(){return N}function ld(){return N.memory()}function hd(t){return N.profile(t)}function q(t,e){return N.tidy(t,e)}function me(t){gr(t).forEach(n=>n.dispose())}function Oe(t){return N.keep(t)}function pd(t){return N.time(t)}function fd(t){return N.setBackend(t)}function dd(){return N.ready()}function yc(){return N.backendName}function md(t){N.removeBackend(t)}function gd(t){return N.findBackend(t)}function yd(t){return N.findBackendFactory(t)}function bd(t,e,n=1){return N.registerBackend(t,e,n)}function bc(){return N.backend}function wd(t,e){P().setPlatform(t,e)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const ot=4;async function Nd(t,e){const n=[],s=[],r=Array.isArray(t)?t.map(o=>o.name):Object.keys(t);for(let o=0;o<r.length;++o){const i=r[o],u=Array.isArray(t)?t[o].tensor:t[i];if(u.dtype!=="float32"&&u.dtype!=="int32"&&u.dtype!=="bool"&&u.dtype!=="string"&&u.dtype!=="complex64")throw new Error(`Unsupported dtype in weight '${i}': ${u.dtype}`);const c={name:i,shape:u.shape,dtype:u.dtype};if(u.dtype==="string"){const h=new Promise(async l=>{const f=await u.bytes(),m=f.reduce((S,$)=>S+$.length,0)+ot*f.length,b=new Uint8Array(m);let T=0;for(let S=0;S<f.length;S++){const $=f[S],O=new Uint8Array(new Uint32Array([$.length]).buffer);b.set(O,T),T+=ot,b.set($,T),T+=$.length}l(b)});s.push(h)}else s.push(u.data());e!=null&&(c.group=e),n.push(c)}const a=await Promise.all(s);return{data:$d(a),specs:n}}function wc(t,e){const n=new Re(t),s={};let r=0;for(const a of e){const o=Sd(a,(i,u)=>n.slice(r+i,r+u));s[a.name]=Nc(a,n.slice(r,r+o)),r+=o}return s}function Sd(t,e){const n=G(t.shape);let s;if("quantization"in t){const r=t.quantization;s=St[r.dtype]}else if(t.dtype==="string"){let r=0;for(let a=0;a<n;a++)r+=ot+new Uint32Array(e(r,r+ot))[0];return r}else s=St[t.dtype];return n*s}async function Td(t,e){const n=G(t.shape);let s;if("quantization"in t){const r=t.quantization;s=St[r.dtype]}else if(t.dtype==="string"){let r=0;for(let a=0;a<n;a++)r+=ot+new Uint32Array(await e(r,r+ot))[0];return r}else s=St[t.dtype];return n*s}function Nc(t,e){const n=t.name,s=t.dtype,r=t.shape,a=G(r);let o,i=0;if("quantization"in t){const u=t.quantization;if(u.dtype==="uint8"||u.dtype==="uint16"){if(!("min"in u&&"scale"in u))throw new Error(`Weight ${t.name} with quantization ${u.dtype} doesn't have corresponding metadata min and scale.`)}else if(u.dtype==="float16"){if(s!=="float32")throw new Error(`Weight ${t.name} is quantized with ${u.dtype} which only supports weights of type float32 not ${s}.`)}else throw new Error(`Weight ${t.name} has unknown quantization dtype ${u.dtype}. Supported quantization dtypes are: 'uint8', 'uint16', and 'float16'.`);const c=St[u.dtype],h=u.dtype==="uint8"?new Uint8Array(e):new Uint16Array(e);if(s==="float32")if(u.dtype==="uint8"||u.dtype==="uint16"){o=new Float32Array(h.length);for(let l=0;l<h.length;l++){const f=h[l];o[l]=f*u.scale+u.min}}else if(u.dtype==="float16")o=Ad()(h);else throw new Error(`Unsupported quantization type ${u.dtype} for weight type float32.`);else if(s==="int32"){if(u.dtype!=="uint8"&&u.dtype!=="uint16")throw new Error(`Unsupported quantization type ${u.dtype} for weight type int32.`);o=new Int32Array(h.length);for(let l=0;l<h.length;l++){const f=h[l];o[l]=Math.round(f*u.scale+u.min)}}else throw new Error(`Unsupported dtype in weight '${n}': ${s}`);i+=a*c}else if(s==="string"){const u=G(t.shape);o=[];for(let c=0;c<u;c++){const h=new Uint32Array(e.slice(i,i+ot))[0];i+=ot;const l=new Uint8Array(e.slice(i,i+h));o.push(l),i+=h}}else{const u=St[s];if(s==="float32")o=new Float32Array(e);else if(s==="int32")o=new Int32Array(e);else if(s==="bool")o=new Uint8Array(e);else if(s==="complex64"){o=new Float32Array(e);const c=new Float32Array(o.length/2),h=new Float32Array(o.length/2);for(let b=0;b<c.length;b++)c[b]=o[b*2],h[b]=o[b*2+1];const l=De(c,r,"float32"),f=De(h,r,"float32"),m=Ke(l,f);return l.dispose(),f.dispose(),m}else throw new Error(`Unsupported dtype in weight '${n}': ${s}`);i+=a*u}return De(o,r,s)}async function ka(t,e,n){let s=new Uint8Array(e);for(;s.byteLength<n;){const{done:r,value:a}=await t.read();if(r&&a==null){const i=n-s.byteLength;throw new Error(`Reader is done but ${i} bytes are still expected`)}const o=new Uint8Array(s.length+a.byteLength);o.set(s,0),o.set(new Uint8Array(a),s.length),s=o}return s.buffer}async function Sc(t,e){const n={},s=t.getReader();let r=new ArrayBuffer(0);for(const a of e){const o=await Td(a,async(c,h)=>(r=await ka(s,r,h),r.slice(c,h)));r=await ka(s,r,o);const i=r.slice(0,o);r=r.slice(o);const u=Nc(a,i);if(n[a.name]=u,yc()==="webgpu"){const c=bc();"uploadToGPU"in c&&G(u.shape)>=P().get("WEBGPU_CPU_HANDOFF_SIZE_THRESHOLD")&&c.uploadToGPU(u.dataId)}}return n}function $d(t){if(t===null)throw new Error(`Invalid input value: ${JSON.stringify(t)}`);let e=0;const n=[];t.forEach(a=>{if(e+=a.byteLength,n.push(a.byteLength===a.buffer.byteLength?a:new a.constructor(a)),!(a instanceof Float32Array||a instanceof Int32Array||a instanceof Uint8Array))throw new Error(`Unsupported TypedArray subtype: ${a.constructor.name}`)});const s=new Uint8Array(e);let r=0;return n.forEach(a=>{s.set(new Uint8Array(a.buffer),r),r+=a.byteLength}),s.buffer}const br=typeof Buffer<"u"&&(typeof Blob>"u"||typeof atob>"u"||typeof btoa>"u");function va(t){return br?Buffer.byteLength(t,"utf8"):new Blob([t]).size}function Ed(t){if(br)return Buffer.from(t).toString("base64");const e=new Uint8Array(t);let n="";for(let s=0,r=e.length;s<r;s++)n+=String.fromCharCode(e[s]);return btoa(n)}function kd(t){if(br){const s=Buffer.from(t,"base64");return s.buffer.slice(s.byteOffset,s.byteOffset+s.byteLength)}const e=atob(t),n=new Uint8Array(e.length);for(let s=0;s<e.length;++s)n.set([e.charCodeAt(s)],s);return n.buffer}function vd(t){return Re.join(t)}function _a(t){const e="/";for(t=t.trim();t.endsWith(e);)t=t.slice(0,t.length-1);const n=t.split(e);return n[n.length-1]}function Tc(t,e){const n={modelTopology:t.modelTopology,format:t.format,generatedBy:t.generatedBy,convertedBy:t.convertedBy,weightsManifest:e};return t.signature!=null&&(n.signature=t.signature),t.userDefinedMetadata!=null&&(n.userDefinedMetadata=t.userDefinedMetadata),t.modelInitializer!=null&&(n.modelInitializer=t.modelInitializer),t.initializerSignature!=null&&(n.initializerSignature=t.initializerSignature),t.trainingConfig!=null&&(n.trainingConfig=t.trainingConfig),n}function wr(t,e,n){const s={modelTopology:t.modelTopology,format:t.format,generatedBy:t.generatedBy,convertedBy:t.convertedBy};if(t.trainingConfig!=null&&(s.trainingConfig=t.trainingConfig),t.weightsManifest!=null){if(!e)throw new Error("modelJSON has weightsManifest but weightSpecs is null");if(!n)throw new Error("modelJSON has weightsManifest but weightData is null");s.weightSpecs=e,s.weightData=n}return t.signature!=null&&(s.signature=t.signature),t.userDefinedMetadata!=null&&(s.userDefinedMetadata=t.userDefinedMetadata),t.modelInitializer!=null&&(s.modelInitializer=t.modelInitializer),t.initializerSignature!=null&&(s.initializerSignature=t.initializerSignature),s}async function Nr(t,e){let n,s;return t.weightsManifest!=null&&([n,s]=await e(t.weightsManifest)),wr(t,n,s)}function bn(t){if(t.modelTopology instanceof ArrayBuffer)throw new Error("Expected JSON model topology, received ArrayBuffer.");return{dateSaved:new Date,modelTopologyType:"JSON",modelTopologyBytes:t.modelTopology==null?0:va(JSON.stringify(t.modelTopology)),weightSpecsBytes:t.weightSpecs==null?0:va(JSON.stringify(t.weightSpecs)),weightDataBytes:t.weightData==null?0:new Re(t.weightData).byteLength}}function Kn(t){const e=[];for(const n of t)e.push(...n.weights);return e}function _d(){const t=n=>{let s=n<<13,r=0;for(;(s&8388608)===0;)r-=8388608,s<<=1;return s&=-8388609,r+=947912704,s|r},e=new Uint32Array(2048);e[0]=0;for(let n=1;n<1024;n++)e[n]=t(n);for(let n=1024;n<2048;n++)e[n]=939524096+(n-1024<<13);return e}function Id(){const t=new Uint32Array(64);t[0]=0,t[31]=1199570944,t[32]=2147483648,t[63]=3347054592;for(let e=1;e<31;e++)t[e]=e<<23;for(let e=33;e<63;e++)t[e]=2147483648+(e-32<<23);return t}function xd(){const t=new Uint32Array(64);for(let e=0;e<64;e++)t[e]=1024;return t[0]=t[32]=0,t}function Ad(){const t=_d(),e=Id(),n=xd();return s=>{const r=new ArrayBuffer(4*s.length),a=new Uint32Array(r);for(let o=0;o<s.length;o++){const i=s[o],u=t[n[i>>10]+(i&1023)]+e[i>>10];a[o]=u}return new Float32Array(r)}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class Q{constructor(){this.saveRouters=[],this.loadRouters=[]}static getInstance(){return Q.instance==null&&(Q.instance=new Q),Q.instance}static registerSaveRouter(e){Q.getInstance().saveRouters.push(e)}static registerLoadRouter(e){Q.getInstance().loadRouters.push(e)}static getSaveHandlers(e){return Q.getHandlers(e,"save")}static getLoadHandlers(e,n){return Q.getHandlers(e,"load",n)}static getHandlers(e,n,s){const r=[];return(n==="load"?Q.getInstance().loadRouters:Q.getInstance().saveRouters).forEach(o=>{const i=o(e,s);i!==null&&r.push(i)}),r}}const Od=t=>Q.registerSaveRouter(t),Dd=t=>Q.registerLoadRouter(t),Fd=t=>Q.getSaveHandlers(t),Cd=(t,e)=>Q.getLoadHandlers(t,e);/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const Ws="tensorflowjs",Ms=1,yt="models_store",et="model_info_store";function $c(){if(!P().getBool("IS_BROWSER"))throw new Error("Failed to obtain IndexedDB factory because the current environmentis not a web browser.");const t=typeof window>"u"?self:window,e=t.indexedDB||t.mozIndexedDB||t.webkitIndexedDB||t.msIndexedDB||t.shimIndexedDB;if(e==null)throw new Error("The current browser does not appear to support IndexedDB.");return e}function Us(t){const e=t.result;e.createObjectStore(yt,{keyPath:"modelPath"}),e.createObjectStore(et,{keyPath:"modelPath"})}class Tt{constructor(e){if(this.indexedDB=$c(),e==null||!e)throw new Error("For IndexedDB, modelPath must not be null, undefined or empty.");this.modelPath=e}async save(e){if(e.modelTopology instanceof ArrayBuffer)throw new Error("BrowserLocalStorage.save() does not support saving model topology in binary formats yet.");return this.databaseAction(this.modelPath,e)}async load(){return this.databaseAction(this.modelPath)}databaseAction(e,n){return new Promise((s,r)=>{const a=this.indexedDB.open(Ws,Ms);a.onupgradeneeded=()=>Us(a),a.onsuccess=()=>{const o=a.result;if(n==null){const i=o.transaction(yt,"readonly"),c=i.objectStore(yt).get(this.modelPath);c.onsuccess=()=>{if(c.result==null)return o.close(),r(new Error(`Cannot find model with path '${this.modelPath}' in IndexedDB.`));s(c.result.modelArtifacts)},c.onerror=h=>(o.close(),r(c.error)),i.oncomplete=()=>o.close()}else{n.weightData=Re.join(n.weightData);const i=bn(n),u=o.transaction(et,"readwrite");let c=u.objectStore(et),h;try{h=c.put({modelPath:this.modelPath,modelArtifactsInfo:i})}catch(f){return r(f)}let l;h.onsuccess=()=>{l=o.transaction(yt,"readwrite");const f=l.objectStore(yt);let m;try{m=f.put({modelPath:this.modelPath,modelArtifacts:n,modelArtifactsInfo:i})}catch(b){return r(b)}m.onsuccess=()=>s({modelArtifactsInfo:i}),m.onerror=b=>{c=u.objectStore(et);const T=c.delete(this.modelPath);T.onsuccess=()=>(o.close(),r(m.error)),T.onerror=S=>(o.close(),r(m.error))}},h.onerror=f=>(o.close(),r(h.error)),u.oncomplete=()=>{l==null?o.close():l.oncomplete=()=>o.close()}}},a.onerror=o=>r(a.error)})}}Tt.URL_SCHEME="indexeddb://";const Ec=t=>P().getBool("IS_BROWSER")&&!Array.isArray(t)&&t.startsWith(Tt.URL_SCHEME)?Rd(t.slice(Tt.URL_SCHEME.length)):null;Q.registerSaveRouter(Ec);Q.registerLoadRouter(Ec);function Rd(t){return new Tt(t)}function Ld(t){return t.startsWith(Tt.URL_SCHEME)?t.slice(Tt.URL_SCHEME.length):t}class Bd{constructor(){this.indexedDB=$c()}async listModels(){return new Promise((e,n)=>{const s=this.indexedDB.open(Ws,Ms);s.onupgradeneeded=()=>Us(s),s.onsuccess=()=>{const r=s.result,a=r.transaction(et,"readonly"),i=a.objectStore(et).getAll();i.onsuccess=()=>{const u={};for(const c of i.result)u[c.modelPath]=c.modelArtifactsInfo;e(u)},i.onerror=u=>(r.close(),n(i.error)),a.oncomplete=()=>r.close()},s.onerror=r=>n(s.error)})}async removeModel(e){return e=Ld(e),new Promise((n,s)=>{const r=this.indexedDB.open(Ws,Ms);r.onupgradeneeded=()=>Us(r),r.onsuccess=()=>{const a=r.result,o=a.transaction(et,"readwrite"),i=o.objectStore(et),u=i.get(e);let c;u.onsuccess=()=>{if(u.result==null)return a.close(),s(new Error(`Cannot find model with path '${e}' in IndexedDB.`));{const h=i.delete(e),l=()=>{c=a.transaction(yt,"readwrite");const m=c.objectStore(yt).delete(e);m.onsuccess=()=>n(u.result.modelArtifactsInfo),m.onerror=b=>s(u.error)};h.onsuccess=l,h.onerror=f=>(l(),a.close(),s(u.error))}},u.onerror=h=>(a.close(),s(u.error)),o.oncomplete=()=>{c==null?a.close():c.oncomplete=()=>a.close()}},r.onerror=a=>s(r.error)})}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const qe="/",At="tensorflowjs_models",kc="info",Pd="model_topology",zd="weight_specs",Vd="weight_data",Wd="model_metadata";function vc(t){return{info:[At,t,kc].join(qe),topology:[At,t,Pd].join(qe),weightSpecs:[At,t,zd].join(qe),weightData:[At,t,Vd].join(qe),modelMetadata:[At,t,Wd].join(qe)}}function _c(t){for(const e of Object.values(t))window.localStorage.removeItem(e)}function Md(t){const e=t.split(qe);if(e.length<3)throw new Error(`Invalid key format: ${t}`);return e.slice(1,e.length-1).join(qe)}function Ud(t){return t.startsWith($t.URL_SCHEME)?t.slice($t.URL_SCHEME.length):t}class $t{constructor(e){if(!P().getBool("IS_BROWSER")||typeof window>"u"||typeof window.localStorage>"u")throw new Error("The current environment does not support local storage.");if(this.LS=window.localStorage,e==null||!e)throw new Error("For local storage, modelPath must not be null, undefined or empty.");this.modelPath=e,this.keys=vc(this.modelPath)}async save(e){if(e.modelTopology instanceof ArrayBuffer)throw new Error("BrowserLocalStorage.save() does not support saving model topology in binary formats yet.");{const n=JSON.stringify(e.modelTopology),s=JSON.stringify(e.weightSpecs),r=bn(e),a=Re.join(e.weightData);try{this.LS.setItem(this.keys.info,JSON.stringify(r)),this.LS.setItem(this.keys.topology,n),this.LS.setItem(this.keys.weightSpecs,s),this.LS.setItem(this.keys.weightData,Ed(a));const o={format:e.format,generatedBy:e.generatedBy,convertedBy:e.convertedBy,signature:e.signature!=null?e.signature:void 0,userDefinedMetadata:e.userDefinedMetadata!=null?e.userDefinedMetadata:void 0,modelInitializer:e.modelInitializer!=null?e.modelInitializer:void 0,initializerSignature:e.initializerSignature!=null?e.initializerSignature:void 0,trainingConfig:e.trainingConfig!=null?e.trainingConfig:void 0};return this.LS.setItem(this.keys.modelMetadata,JSON.stringify(o)),{modelArtifactsInfo:r}}catch{throw _c(this.keys),new Error(`Failed to save model '${this.modelPath}' to local storage: size quota being exceeded is a possible cause of this failure: modelTopologyBytes=${r.modelTopologyBytes}, weightSpecsBytes=${r.weightSpecsBytes}, weightDataBytes=${r.weightDataBytes}.`)}}}async load(){const e=JSON.parse(this.LS.getItem(this.keys.info));if(e==null)throw new Error(`In local storage, there is no model with name '${this.modelPath}'`);if(e.modelTopologyType!=="JSON")throw new Error("BrowserLocalStorage does not support loading non-JSON model topology yet.");const n={},s=JSON.parse(this.LS.getItem(this.keys.topology));if(s==null)throw new Error(`In local storage, the topology of model '${this.modelPath}' is missing.`);n.modelTopology=s;const r=JSON.parse(this.LS.getItem(this.keys.weightSpecs));if(r==null)throw new Error(`In local storage, the weight specs of model '${this.modelPath}' are missing.`);n.weightSpecs=r;const a=this.LS.getItem(this.keys.modelMetadata);if(a!=null){const i=JSON.parse(a);n.format=i.format,n.generatedBy=i.generatedBy,n.convertedBy=i.convertedBy,i.signature!=null&&(n.signature=i.signature),i.userDefinedMetadata!=null&&(n.userDefinedMetadata=i.userDefinedMetadata),i.modelInitializer!=null&&(n.modelInitializer=i.modelInitializer),i.initializerSignature!=null&&(n.initializerSignature=i.initializerSignature),i.trainingConfig!=null&&(n.trainingConfig=i.trainingConfig)}const o=this.LS.getItem(this.keys.weightData);if(o==null)throw new Error(`In local storage, the binary weight values of model '${this.modelPath}' are missing.`);return n.weightData=kd(o),n}}$t.URL_SCHEME="localstorage://";const Ic=t=>P().getBool("IS_BROWSER")&&!Array.isArray(t)&&t.startsWith($t.URL_SCHEME)?jd(t.slice($t.URL_SCHEME.length)):null;Q.registerSaveRouter(Ic);Q.registerLoadRouter(Ic);function jd(t){return new $t(t)}class qd{constructor(){g(P().getBool("IS_BROWSER"),()=>"Current environment is not a web browser"),g(typeof window>"u"||typeof window.localStorage<"u",()=>"Current browser does not appear to support localStorage"),this.LS=window.localStorage}async listModels(){const e={},n=At+qe,s=qe+kc;for(let r=0;r<this.LS.length;++r){const a=this.LS.key(r);if(a.startsWith(n)&&a.endsWith(s)){const o=Md(a);e[o]=JSON.parse(this.LS.getItem(a))}}return e}async removeModel(e){e=Ud(e);const n=vc(e);if(this.LS.getItem(n.info)==null)throw new Error(`Cannot find model at path '${e}'`);const s=JSON.parse(this.LS.getItem(n.info));return _c(n),s}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const Ot="://";class pe{constructor(){this.managers={}}static getInstance(){return pe.instance==null&&(pe.instance=new pe),pe.instance}static registerManager(e,n){g(e!=null,()=>"scheme must not be undefined or null."),e.endsWith(Ot)&&(e=e.slice(0,e.indexOf(Ot))),g(e.length>0,()=>"scheme must not be an empty string.");const s=pe.getInstance();g(s.managers[e]==null,()=>`A model store manager is already registered for scheme '${e}'.`),s.managers[e]=n}static getManager(e){const n=pe.getInstance().managers[e];if(n==null)throw new Error(`Cannot find model manager for scheme '${e}'`);return n}static getSchemes(){return Object.keys(pe.getInstance().managers)}}function Fn(t){if(t.indexOf(Ot)===-1)throw new Error(`The url string provided does not contain a scheme. Supported schemes are: ${pe.getSchemes().join(",")}`);return{scheme:t.split(Ot)[0],path:t.split(Ot)[1]}}async function xc(t,e,n=!1){g(t!==e,()=>`Old path and new path are the same: '${t}'`);const s=Q.getLoadHandlers(t);g(s.length>0,()=>`Copying failed because no load handler is found for source URL ${t}.`),g(s.length<2,()=>`Copying failed because more than one (${s.length}) load handlers for source URL ${t}.`);const r=s[0],a=Q.getSaveHandlers(e);g(a.length>0,()=>`Copying failed because no save handler is found for destination URL ${e}.`),g(a.length<2,()=>`Copying failed because more than one (${s.length}) save handlers for destination URL ${e}.`);const o=a[0],i=Fn(t).scheme,u=Fn(t).path,c=i===Fn(t).scheme,h=await r.load();n&&c&&await pe.getManager(i).removeModel(u);const l=await o.save(h);return n&&!c&&await pe.getManager(i).removeModel(u),l.modelArtifactsInfo}async function Gd(){const t=pe.getSchemes(),e={};for(const n of t){const s=await pe.getManager(n).listModels();for(const r in s){const a=n+Ot+r;e[a]=s[r]}}return e}async function Hd(t){const e=Fn(t);return pe.getManager(e.scheme).removeModel(e.path)}async function Kd(t,e){return xc(t,e,!1)}async function Xd(t,e){return xc(t,e,!0)}/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class Zd{constructor(){this.messageName="setTimeoutCustom",this.functionRefs=[],this.handledMessageCount=0,this.hasEventListener=!1}fetch(e,n){return fetch(e,n)}now(){return performance.now()}encode(e,n){if(n!=="utf-8"&&n!=="utf8")throw new Error(`Browser's encoder only supports utf-8, but got ${n}`);return this.textEncoder==null&&(this.textEncoder=new TextEncoder),this.textEncoder.encode(e)}decode(e,n){return new TextDecoder(n).decode(e)}setTimeoutCustom(e,n){if(typeof window>"u"||!P().getBool("USE_SETTIMEOUTCUSTOM")){setTimeout(e,n);return}this.functionRefs.push(e),setTimeout(()=>{window.postMessage({name:this.messageName,index:this.functionRefs.length-1},"*")},n),this.hasEventListener||(this.hasEventListener=!0,window.addEventListener("message",s=>{if(s.source===window&&s.data.name===this.messageName){s.stopPropagation();const r=this.functionRefs[s.data.index];r(),this.handledMessageCount++,this.handledMessageCount===this.functionRefs.length&&(this.functionRefs=[],this.handledMessageCount=0)}},!0))}isTypedArray(e){return sc(e)}}if(P().get("IS_BROWSER")){P().setPlatform("browser",new Zd);try{pe.registerManager($t.URL_SCHEME,new qd)}catch{}try{pe.registerManager(Tt.URL_SCHEME,new Bd)}catch{}}/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const Jd={importFetch:()=>require("node-fetch")};let Es;class Yd{constructor(){this.util=require("util"),this.textEncoder=new this.util.TextEncoder}fetch(e,n){return P().global.fetch!=null?P().global.fetch(e,n):(Es==null&&(Es=Jd.importFetch()),Es(e,n))}now(){const e=process.hrtime();return e[0]*1e3+e[1]/1e6}encode(e,n){if(n!=="utf-8"&&n!=="utf8")throw new Error(`Node built-in encoder only supports utf-8, but got ${n}`);return this.textEncoder.encode(e)}decode(e,n){return e.length===0?"":new this.util.TextDecoder(n).decode(e)}isTypedArray(e){return this.util.types.isFloat32Array(e)||this.util.types.isInt32Array(e)||this.util.types.isUint8Array(e)||this.util.types.isUint8ClampedArray(e)}}P().get("IS_NODE")&&!P().get("IS_BROWSER")&&P().setPlatform("node",new Yd);/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Pe(t,e="float32",n){return e=e||"float32",$e(t),new Hn(t,e,n)}/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Qd(t,e){const n=d(t,"x","cast");if(!ao(e))throw new Error(`Failed to cast to unknown dtype ${e}`);if(e==="string"&&n.dtype!=="string"||e!=="string"&&n.dtype==="string")throw new Error("Only strings can be casted to strings");const s={x:n},r={dtype:e};return N.runKernel(hr,s,r)}const J=w({cast_:Qd});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function em(t){const n={x:d(t,"x","clone","string_or_numeric")};return N.runKernel(fr,n)}const Ge=w({clone_:em});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Sr(t,e=!1){console.log(t.toString(e))}/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */dc();const tm={buffer:Pe,cast:J,clone:Ge,print:Sr};jf(tm);/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function nm(t,e){let n=d(t,"a","add"),s=d(e,"b","add");[n,s]=ee(n,s);const r={a:n,b:s};return N.runKernel(lr,r)}const B=w({add_:nm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function sm(t,e){let n=d(t,"a","floorDiv"),s=d(e,"b","floorDiv");[n,s]=ee(n,s);const r={a:n,b:s};return N.runKernel(fi,r)}const Tr=w({floorDiv_:sm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function rm(t,e){let n=d(t,"a","div"),s=d(e,"b","div");if([n,s]=ee(n,s),n.dtype==="int32"&&s.dtype==="int32")return Tr(n,s);const r={a:n,b:s},a={};return N.runKernel(ti,r,a)}const Z=w({div_:rm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function am(t,e){let n=d(t,"a","mul"),s=d(e,"b","mul");[n,s]=ee(n,s);const r={a:n,b:s};return N.runKernel(qi,r)}const D=w({mul_:am});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function om(t){const e=d(t,"x","abs");if(e.dtype==="complex64"){const n={x:e};return N.runKernel(Lo,n)}else{const n={x:e};return N.runKernel(po,n)}}const Se=w({abs_:om});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function im(t){const n={x:d(t,"x","acos")};return N.runKernel(fo,n)}const Ac=w({acos_:im});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function um(t){const n={x:d(t,"x","acosh")};return N.runKernel(mo,n)}const Oc=w({acosh_:um});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function cm(t){g(Array.isArray(t),()=>"The argument passed to tf.addN() must be a list of tensors"),g(t.length>=1,()=>`Must pass at least one tensor to tf.addN(), but got ${t.length}`);const e=t.map((r,a)=>d(r,`tensors${a}`,"addN")),n=e[0];e.forEach(r=>{if(r.dtype!==n.dtype)throw new Error("All tensors passed to tf.addN() must have the same dtype")}),e.forEach(r=>{if(!Ce(r.shape,n.shape))throw new Error("All tensors passed to tf.addN() must have the same shape")});const s=e;return N.runKernel(go,s)}const Dc=w({addN_:cm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function lm(t,e=null,n=!1){const r={x:d(t,"x","all","bool")},a={axis:e,keepDims:n};return N.runKernel(yo,r,a)}const Fc=w({all_:lm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function hm(t,e=null,n=!1){const r={x:d(t,"x","any","bool")},a={axis:e,keepDims:n};return N.runKernel(bo,r,a)}const Cc=w({any_:hm});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function pm(t,e=0){const s={x:d(t,"x","argMax")},r={axis:e};return N.runKernel(wo,s,r)}const Rc=w({argMax_:pm});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function fm(t,e=0){const s={x:d(t,"x","argMin")},r={axis:e};return N.runKernel(No,s,r)}const Lc=w({argMin_:fm});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function dm(t){const n={x:d(t,"x","asin")};return N.runKernel(So,n)}const Bc=w({asin_:dm});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function mm(t){const n={x:d(t,"x","asinh")};return N.runKernel(To,n)}const Pc=w({asinh_:mm});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function gm(t){const n={x:d(t,"x","atan")};return N.runKernel($o,n)}const zc=w({atan_:gm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ym(t,e){let n=d(t,"a","atan2"),s=d(e,"b","atan2");[n,s]=ee(n,s);const r={a:n,b:s};return N.runKernel(ko,r)}const Vc=w({atan2_:ym});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function bm(t){const n={x:d(t,"x","atanh")};return N.runKernel(Eo,n)}const Wc=w({atanh_:bm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function wm(t,e,n,s,r="NHWC",a){const o=t[3],i=[...e,o],u=jc(r);return wn(t,i,n,a,s,null,null,u)}function Mc(t,e,n,s,r,a,o="channelsLast"){const[i,u]=an(e);let c;if(o==="channelsLast")c=[i,u,t[3],t[3]];else if(o==="channelsFirst")c=[i,u,t[1],t[1]];else throw new Error(`Unknown dataFormat ${o}`);return wn(t,c,n,s,r,a,!1,o)}function Nm(t,e,n,s,r,a,o="NDHWC"){const[i,u,c]=js(e);let h,l;if(o==="NDHWC")l="channelsLast",h=[i,u,c,t[4],t[4]];else if(o==="NCDHW")l="channelsFirst",h=[i,u,c,t[1],t[1]];else throw new Error(`Unknown dataFormat ${o}`);return Uc(t,h,n,s,r,!1,l,a)}function wn(t,e,n,s,r,a,o=!1,i="channelsLast"){let[u,c,h,l]=[-1,-1,-1,-1];if(i==="channelsLast")[u,c,h,l]=t;else if(i==="channelsFirst")[u,l,c,h]=t;else throw new Error(`Unknown dataFormat ${i}`);const[f,m,,b]=e,[T,S]=an(n),[$,O]=an(s),v=Dt(f,$),_=Dt(m,O),{padInfo:A,outHeight:F,outWidth:L}=$m(r,c,h,T,S,v,_,a,i),C=o?b*l:b;let k;return i==="channelsFirst"?k=[u,C,F,L]:i==="channelsLast"&&(k=[u,F,L,C]),{batchSize:u,dataFormat:i,inHeight:c,inWidth:h,inChannels:l,outHeight:F,outWidth:L,outChannels:C,padInfo:A,strideHeight:T,strideWidth:S,filterHeight:f,filterWidth:m,effectiveFilterHeight:v,effectiveFilterWidth:_,dilationHeight:$,dilationWidth:O,inShape:t,outShape:k,filterShape:e}}function Uc(t,e,n,s,r,a=!1,o="channelsLast",i){let[u,c,h,l,f]=[-1,-1,-1,-1,-1];if(o==="channelsLast")[u,c,h,l,f]=t;else if(o==="channelsFirst")[u,f,c,h,l]=t;else throw new Error(`Unknown dataFormat ${o}`);const[m,b,T,,S]=e,[$,O,v]=js(n),[_,A,F]=js(s),L=Dt(m,_),C=Dt(b,A),k=Dt(T,F),{padInfo:E,outDepth:y,outHeight:x,outWidth:R}=Em(r,c,h,l,$,O,v,L,C,k,i),z=a?S*f:S;let V;return o==="channelsFirst"?V=[u,z,y,x,R]:o==="channelsLast"&&(V=[u,y,x,R,z]),{batchSize:u,dataFormat:o,inDepth:c,inHeight:h,inWidth:l,inChannels:f,outDepth:y,outHeight:x,outWidth:R,outChannels:z,padInfo:E,strideDepth:$,strideHeight:O,strideWidth:v,filterDepth:m,filterHeight:b,filterWidth:T,effectiveFilterDepth:L,effectiveFilterHeight:C,effectiveFilterWidth:k,dilationDepth:_,dilationHeight:A,dilationWidth:F,inShape:t,outShape:V,filterShape:e}}function Sm(t,e,n,s,r){s==null&&(s=$r(t,e,n));const a=t[0],o=t[1],i=on((a-e+2*s)/n+1,r),u=on((o-e+2*s)/n+1,r);return[i,u]}function Tm(t,e,n,s,r,a){r==null&&(r=$r(t,e[0],s[0]));const o=[0,0,0,n];for(let i=0;i<3;i++)t[i]+2*r>=e[i]&&(o[i]=on((t[i]-e[i]+2*r)/s[i]+1,a));return o}function $r(t,e,n,s=1){const r=Dt(e,s);return Math.floor((t[0]*(n-1)-n+r)/2)}function an(t){return typeof t=="number"?[t,t,t]:t.length===2?[t[0],t[1],1]:t}function js(t){return typeof t=="number"?[t,t,t]:t}function Dt(t,e){return e<=1?t:t+(t-1)*(e-1)}function $m(t,e,n,s,r,a,o,i,u){let c,h,l;if(typeof t=="number"){c={top:t,bottom:t,left:t,right:t,type:t===0?"VALID":"NUMBER"};const m=Sm([e,n],a,s,t,i);h=m[0],l=m[1]}else if(t==="same"){h=Math.ceil(e/s),l=Math.ceil(n/r);const f=Math.max(0,(h-1)*s+a-e),m=Math.max(0,(l-1)*r+o-n),b=Math.floor(f/2),T=f-b,S=Math.floor(m/2),$=m-S;c={top:b,bottom:T,left:S,right:$,type:"SAME"}}else if(t==="valid")c={top:0,bottom:0,left:0,right:0,type:"VALID"},h=Math.ceil((e-a+1)/s),l=Math.ceil((n-o+1)/r);else if(typeof t=="object"){const f=u==="channelsLast"?t[1][0]:t[2][0],m=u==="channelsLast"?t[1][1]:t[2][1],b=u==="channelsLast"?t[2][0]:t[3][0],T=u==="channelsLast"?t[2][1]:t[3][1];c={top:f,bottom:m,left:b,right:T,type:f===0&&m===0&&b===0&&T===0?"VALID":"EXPLICIT"},h=on((e-a+f+m)/s+1,i),l=on((n-o+b+T)/r+1,i)}else throw Error(`Unknown padding parameter: ${t}`);return{padInfo:c,outHeight:h,outWidth:l}}function Em(t,e,n,s,r,a,o,i,u,c,h){let l,f,m,b;if(t==="valid"&&(t=0),typeof t=="number"){l={top:t,bottom:t,left:t,right:t,front:t,back:t,type:t===0?"VALID":"NUMBER"};const S=Tm([e,n,s,1],[i,u,c],1,[r,a,o],t,h);f=S[0],m=S[1],b=S[2]}else if(t==="same"){f=Math.ceil(e/r),m=Math.ceil(n/a),b=Math.ceil(s/o);const T=(f-1)*r+i-e,S=(m-1)*a+u-n,$=(b-1)*o+c-s,O=Math.floor(T/2),v=T-O,_=Math.floor(S/2),A=S-_,F=Math.floor($/2),L=$-F;l={top:_,bottom:A,left:F,right:L,front:O,back:v,type:"SAME"}}else throw Error(`Unknown padding parameter: ${t}`);return{padInfo:l,outDepth:f,outHeight:m,outWidth:b}}function on(t,e){if(!e)return Math.trunc(t);switch(e){case"round":return Math.round(t);case"ceil":return Math.ceil(t);case"floor":return Math.floor(t);default:throw new Error(`Unknown roundingMode ${e}`)}}function un(t){const[e,n,s]=an(t);return e===1&&n===1&&s===1}function Xe(t,e){return un(t)||un(e)}function Et(t){return an(t).every(e=>e>0)}function jc(t){if(t==="NHWC")return"channelsLast";if(t==="NCHW")return"channelsFirst";throw new Error(`Unknown dataFormat ${t}`)}function xe(t,e,n){if(n!=null){if(typeof e=="string")throw Error(`Error in ${t}: pad must be an integer when using dimRoundingMode ${n} but got pad ${e}.`);if(typeof e=="number")g(Rt(e),()=>`Error in ${t}: pad must be an integer when using dimRoundingMode ${n} but got pad ${e}.`);else if(typeof e=="object")e.forEach(s=>{s.forEach(r=>{g(Rt(r),()=>`Error in ${t}: pad must be an integer when using dimRoundingMode ${n} but got pad ${r}.`)})});else throw Error(`Error in ${t}: Unknown padding parameter: ${e}`)}}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function km(t,e){const s={x:d(t,"x","reshape","string_or_numeric")},r={shape:e};return N.runKernel(hu,s,r)}const I=w({reshape_:km});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function vm(t,e,n,s,r){const a=d(t,"x","avgPool","float32"),o=1;g(Xe(n,o),()=>`Error in avgPool: Either strides or dilations must be 1. Got strides ${n} and dilations '${o}'`);let i=a,u=!1;a.rank===3&&(u=!0,i=I(a,[1,a.shape[0],a.shape[1],a.shape[2]])),g(i.rank===4,()=>`Error in avgPool: x must be rank 4 but got rank ${i.rank}.`),xe("avgPool",s,r);const c={x:i},h={filterSize:e,strides:n,pad:s,dimRoundingMode:r};let l=N.runKernel(vo,c,h);return l=J(l,a.dtype),u?I(l,[l.shape[1],l.shape[2],l.shape[3]]):l}const Er=w({avgPool_:vm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function _m(t,e,n,s,r,a="NDHWC"){const o=d(t,"x","avgPool3d","float32");let i=o,u=!1;o.rank===4&&(u=!0,i=I(o,[1,o.shape[0],o.shape[1],o.shape[2],o.shape[3]])),g(i.rank===5,()=>`Error in avgPool3d: x must be rank 5 but got rank ${i.rank}.`),g(a==="NDHWC",()=>`Error in avgPool3d: Only NDHWC is currently supported, but got dataFormat of ${a}`),g(typeof n=="number"&&n>0||Array.isArray(n)&&n[0]>0&&n[1]>0&&n[2]>0,()=>`Error in avgPool3d: Stride must be > 0, but got '${n}'`),xe("avgPool3d",s,r);const c={x:i},h={filterSize:e,strides:n,pad:s,dimRoundingMode:r,dataFormat:a};let l=N.runKernel(_o,c,h);return l=J(l,i.dtype),u?I(l,[l.shape[1],l.shape[2],l.shape[3],l.shape[4]]):l}const qc=w({avgPool3d_:_m});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Im(t,e=0){g(t.length>=1,()=>"Pass at least one tensor to concat");const n=rn(t,"tensors","concat","string_or_numeric");if(n[0].dtype==="complex64"&&n.forEach(a=>{if(a.dtype!=="complex64")throw new Error(`Cannot concatenate complex64 tensors with a tensor
          with dtype ${a.dtype}. `)}),n.length===1)return Ge(n[0]);const s=n,r={axis:e};return N.runKernel(Bo,s,r)}const he=w({concat_:Im});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function xm(t,e,n=!1,s=!1){let r=d(t,"a","matMul"),a=d(e,"b","matMul");[r,a]=ee(r,a);const o={a:r,b:a},i={transposeA:n,transposeB:s};return N.runKernel(Io,o,i)}const j=w({matMul_:xm});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Am(t){const n={x:d(t,"x","sigmoid","float32")};return N.runKernel(_u,n)}const wt=w({sigmoid_:Am});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Om(t,e,n){const s=d(t,"x","slice","string_or_numeric");if(s.rank===0)throw new Error("Slicing scalar is not possible");const r={x:s},a={begin:e,size:n};return N.runKernel($u,r,a)}const H=w({slice_:Om});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Dm(t){const n={x:d(t,"x","tanh","float32")};return N.runKernel(Hu,n)}const Xn=w({tanh_:Dm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Fm(t,e,n,s,r,a){const o=d(t,"forgetBias","basicLSTMCell"),i=d(e,"lstmKernel","basicLSTMCell"),u=d(n,"lstmBias","basicLSTMCell"),c=d(s,"data","basicLSTMCell"),h=d(r,"c","basicLSTMCell"),l=d(a,"h","basicLSTMCell"),f=he([c,l],1),m=j(f,i),b=B(m,u),T=b.shape[0],S=b.shape[1]/4,$=[T,S],O=H(b,[0,0],$),v=H(b,[0,S],$),_=H(b,[0,S*2],$),A=H(b,[0,S*3],$),F=B(D(wt(O),Xn(v)),D(h,wt(B(o,_)))),L=D(Xn(F),wt(A));return[F,L]}const Gc=w({basicLSTMCell_:Fm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Cm(t,e,n){const s=d(t,"x","batchToSpaceND"),r=e.reduce((i,u)=>i*u);g(s.rank>=1+e.length,()=>`input rank is ${s.rank} but should be > than blockShape.length ${e.length}`),g(n.length===e.length,()=>`crops.length is ${n.length} but should be equal to blockShape.length  ${e.length}`),g(s.shape[0]%r===0,()=>`input tensor batch is ${s.shape[0]} but is not divisible by the product of the elements of blockShape ${e.join(" * ")} === ${r}`);const a={x:s},o={blockShape:e,crops:n};return N.runKernel(xo,a,o)}const kr=w({batchToSpaceND_:Cm});function Rm(t){let e;return t.rank===0||t.rank===1?e=I(t,[1,1,1,t.size]):t.rank===2?e=I(t,[1,1,t.shape[0],t.shape[1]]):t.rank===3?e=I(t,[1,t.shape[0],t.shape[1],t.shape[2]]):e=t,e}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Lm(t,e,n,s,r,a){a==null&&(a=.001);const o=d(t,"x","batchNorm"),i=d(e,"mean","batchNorm"),u=d(n,"variance","batchNorm");let c;r!=null&&(c=d(r,"scale","batchNorm"));let h;s!=null&&(h=d(s,"offset","batchNorm")),g(i.rank===u.rank,()=>"Batch normalization gradient requires mean and variance to have equal ranks."),g(h==null||i.rank===h.rank,()=>"Batch normalization gradient requires mean and offset to have equal ranks."),g(c==null||i.rank===c.rank,()=>"Batch normalization gradient requires mean and scale to have equal ranks.");const f={x:Rm(o),scale:c,offset:h,mean:i,variance:u},m={varianceEpsilon:a},b=N.runKernel(di,f,m);return I(b,o.shape)}const Nn=w({batchNorm_:Lm});function Bm(t,e,n,s,r,a){const o=d(t,"x","batchNorm"),i=d(e,"mean","batchNorm"),u=d(n,"variance","batchNorm");let c;r!=null&&(c=d(r,"scale","batchNorm"));let h;return s!=null&&(h=d(s,"offset","batchNorm")),g(o.rank===2,()=>`Error in batchNorm2D: x must be rank 2 but got rank ${o.rank}.`),g(i.rank===2||i.rank===1,()=>`Error in batchNorm2D: mean must be rank 2 or rank 1 but got rank ${i.rank}.`),g(u.rank===2||u.rank===1,()=>`Error in batchNorm2D: variance must be rank 2 or rank 1 but got rank ${u.rank}.`),c!=null&&g(c.rank===2||c.rank===1,()=>`Error in batchNorm2D: scale must be rank 2 or rank 1 but got rank ${c.rank}.`),h!=null&&g(h.rank===2||h.rank===1,()=>`Error in batchNorm2D: offset must be rank 2 or rank 1 but got rank ${h.rank}.`),Nn(o,i,u,h,c,a)}const Hc=w({batchNorm2d_:Bm});function Pm(t,e,n,s,r,a){const o=d(t,"x","batchNorm"),i=d(e,"mean","batchNorm"),u=d(n,"variance","batchNorm");let c;r!=null&&(c=d(r,"scale","batchNorm"));let h;return s!=null&&(h=d(s,"offset","batchNorm")),g(o.rank===3,()=>`Error in batchNorm3D: x must be rank 3 but got rank ${o.rank}.`),g(i.rank===3||i.rank===1,()=>`Error in batchNorm3D: mean must be rank 3 or rank 1 but got rank ${i.rank}.`),g(u.rank===3||u.rank===1,()=>`Error in batchNorm3D: variance must be rank 3 or rank 1 but got rank ${u.rank}.`),c!=null&&g(c.rank===3||c.rank===1,()=>`Error in batchNorm3D: scale must be rank 3 or rank 1 but got rank ${c.rank}.`),h!=null&&g(h.rank===3||h.rank===1,()=>`Error in batchNorm3D: offset must be rank 3 or rank 1 but got rank ${h.rank}.`),Nn(o,i,u,h,c,a)}const Kc=w({batchNorm3d_:Pm});function zm(t,e,n,s,r,a){const o=d(t,"x","batchNorm"),i=d(e,"mean","batchNorm"),u=d(n,"variance","batchNorm");let c;r!=null&&(c=d(r,"scale","batchNorm"));let h;return s!=null&&(h=d(s,"offset","batchNorm")),g(o.rank===4,()=>`Error in batchNorm4D: x must be rank 4 but got rank ${o.rank}.`),g(i.rank===4||i.rank===1,()=>`Error in batchNorm4D: mean must be rank 4 or rank 1 but got rank ${i.rank}.`),g(u.rank===4||u.rank===1,()=>`Error in batchNorm4D: variance must be rank 4 or rank 1 but got rank ${u.rank}.`),c!=null&&g(c.rank===4||c.rank===1,()=>`Error in batchNorm4D: scale must be rank 4 or rank 1 but got rank ${c.rank}.`),h!=null&&g(h.rank===4||h.rank===1,()=>`Error in batchNorm4D: offset must be rank 4 or rank 1 but got rank ${h.rank}.`),Nn(o,i,u,h,c,a)}const Xc=w({batchNorm4d_:zm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Vm(t,e,n){const s=d(t,"x","bincount"),r=d(e,"weights","bincount");g(s.dtype==="int32",()=>`Error in bincount: input dtype must be int32, but got ${s.dtype}`),g(n>=0,()=>`size must be non-negative, but got ${n}.`),g(r.size===s.size||r.size===0,()=>`Error in bincount: weights must have the same size as input or0-length, but got input shape: ${s.shape}, weights shape: ${r.shape}.`);const a={x:s,weights:r},o={size:n};return N.runKernel(Ao,a,o)}const vr=w({bincount_:Vm});/**
 * @license
 * Copyright 2023 Google LLC.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Wm(t,e){const n=d(t,"x","bitwiseAnd"),s=d(e,"y","bitwiseAnd");if(!Ce(n.shape,s.shape))throw new Error(`BitwiseAnd: Tensors must have the same shape. x: ${n.shape}, y: ${s.shape}`);if(n.dtype!=="int32"||s.dtype!=="int32")throw new Error(`BitwiseAnd: Only supports 'int32' values in tensor, found type of x: ${n.dtype} and type of y: ${s.dtype}`);const r={a:n,b:s};return N.runKernel(Oo,r)}const Zc=w({bitwiseAnd_:Wm});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Mm(t,e){const n=d(t,"s0","broadcastArgs","int32"),s=d(e,"s1","broadcastArgs","int32");if(n.rank!==1)throw new Error(`broadcastArgs(): first input must be a vector (rank=1). Has rank ${n.rank}`);if(s.rank!==1)throw new Error(`broadcastArgs(): second input must be a vector (rank=1). Has rank ${s.rank}`);const r={s0:n,s1:s};return N.runKernel(Do,r)}const Jc=w({broadcastArgs_:Mm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Um(t,e){let n=d(t,"broadcastTo","x");const s=n.shape;if($e(e),e.length<n.rank)throw new Error(`broadcastTo(): shape.length=${e.length} < input.rank=${n.rank}.`);if(e.length>n.rank){const c=n.shape.slice();for(;c.length<e.length;)c.unshift(1);n=I(n,c)}const r=n.shape,a=Array.from(e);for(let c=e.length-1;c>=0;c--)if(r[c]===e[c])a[c]=1;else if(n.shape[c]!==1)throw new Error(`broadcastTo(): [${s}] cannot be broadcast to [${e}].`);if(a.map((c,h)=>c>1?h:-1).filter(c=>c>=0).length===0)return Ge(n);const i={x:n},u={reps:a};return N.runKernel(dr,i,u)}const Yt=w({broadcastTo_:Um});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function jm(t){const n={x:d(t,"x","ceil","float32")};return N.runKernel(Fo,n)}const Yc=w({ceil_:jm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function jt(t,e,n){$e(t),n=n||mn(e);const s={shape:t,value:e,dtype:n};return N.runKernel(li,{},s)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function qm(t,e,n){const s=d(t,"x","clipByValue");if(g(e<=n,()=>`Error in clip: min (${e}) must be less than or equal to max (${n}).`),e===n)return jt(s.shape,e,s.dtype);const r={x:s},a={clipValueMin:e,clipValueMax:n};return N.runKernel(Co,r,a)}const Qc=w({clipByValue_:qm});function Gm(t){return he(t,0)}const el=w({concat1d_:Gm});function Hm(t,e){return he(t,e)}const tl=w({concat2d_:Hm});function Km(t,e){return he(t,e)}const nl=w({concat3d_:Km});function Xm(t,e){return he(t,e)}const sl=w({concat4d_:Xm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Zm(t,e,n,s,r="NHWC",a=[1,1],o){const i=d(t,"x","conv2d","float32"),u=d(e,"filter","conv2d","float32");let c=i,h=!1;i.rank===3&&(h=!0,c=I(i,[1,i.shape[0],i.shape[1],i.shape[2]])),g(c.rank===4,()=>`Error in conv2d: input must be rank 4, but got rank ${c.rank}.`),g(u.rank===4,()=>`Error in conv2d: filter must be rank 4, but got rank ${u.rank}.`),xe("conv2d",s,o);const l=r==="NHWC"?c.shape[3]:c.shape[1];g(l===u.shape[2],()=>`Error in conv2d: depth of input (${l}) must match input depth for filter ${u.shape[2]}.`),g(Xe(n,a),()=>`Error in conv2D: Either strides or dilations must be 1. Got strides ${n} and dilations '${a}'`),g(Et(a),()=>"Error in conv2D: Dilated rates should be larger than 0."),g(Et(n),()=>"Error in conv2D: Strides should be larger than 0.");const f={x:c,filter:u},m={strides:n,pad:s,dataFormat:r,dilations:a,dimRoundingMode:o},b=N.runKernel(Po,f,m);return h?I(b,[b.shape[1],b.shape[2],b.shape[3]]):b}const Sn=w({conv2d_:Zm});function Jm(t,e,n,s,r="NWC",a=1,o){const i=d(t,"x","conv1d"),u=d(e,"filter","conv1d");let c=i,h=!1;i.rank===2&&(h=!0,c=I(i,[1,i.shape[0],i.shape[1]])),g(c.rank===3,()=>`Error in conv1d: input must be rank 3, but got rank ${c.rank}.`),g(u.rank===3,()=>`Error in conv1d: filter must be rank 3, but got rank ${u.rank}.`),xe("conv1d",s,o),g(c.shape[2]===u.shape[1],()=>`Error in conv1d: depth of input (${c.shape[2]}) must match input depth for filter ${u.shape[1]}.`),g(Xe(n,a),()=>`Error in conv1D: Either stride or dilation must be 1. Got stride ${n} and dilation '${a}'`),g(Et(a),()=>"Error in conv1D: Dilated rates should be larger than 0."),g(Et(n),()=>"Error in conv1D: Stride should be larger than 0."),g(r==="NWC",()=>`Error in conv1d: got dataFormat of ${r} but only NWC is currently supported.`);const l=I(u,[1,u.shape[0],u.shape[1],u.shape[2]]),f=I(c,[c.shape[0],1,c.shape[1],c.shape[2]]),S=Sn(f,l,[1,n],s,"NHWC",[1,a],o);return h?I(S,[S.shape[2],S.shape[3]]):I(S,[S.shape[0],S.shape[2],S.shape[3]])}const rl=w({conv1d_:Jm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ym(t,e,n,s,r,a="NHWC",o){g(t.length===e.rank,()=>`Length of inShape (${t.length}) and rank of dy (${e.rank}) must match`);let i=t,u=e,c=!1;e.rank===3&&(c=!0,u=I(e,[1,e.shape[0],e.shape[1],e.shape[2]]),i=[1,t[0],t[1],t[2]]),g(i.length===4,()=>`Error in conv2dDerInput: inShape must be length 4, but got length ${i.length}.`),g(u.rank===4,()=>`Error in conv2dDerInput: dy must be rank 4, but got rank ${u.rank}`),g(n.rank===4,()=>`Error in conv2dDerInput: filter must be rank 4, but got rank ${n.rank}`);const h=a==="NHWC"?i[3]:i[1],l=a==="NHWC"?u.shape[3]:u.shape[1];g(h===n.shape[2],()=>`Error in conv2dDerInput: depth of input (${h}) must match input depth for filter ${n.shape[2]}.`),g(l===n.shape[3],()=>`Error in conv2dDerInput: depth of output (${l}) must match output depth for filter ${n.shape[3]}.`),xe("conv2dDerInput",r,o);const f={dy:u,filter:n},m={strides:s,pad:r,dataFormat:a,dimRoundingMode:o,inputShape:i},b=N.runKernel(Vo,f,m);return c?I(b,[b.shape[1],b.shape[2],b.shape[3]]):b}const al=w({conv2DBackpropInput_:Ym});function Qm(t,e,n,s,r,a){const o=d(t,"x","conv2dTranspose"),i=d(e,"filter","conv2dTranspose");return al(n,o,i,s,r,"NHWC",a)}const ol=w({conv2dTranspose_:Qm});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function eg(t,e,n,s,r="NDHWC",a=[1,1,1]){const o=d(t,"x","conv3d"),i=d(e,"filter","conv3d");let u=o,c=!1;o.rank===4&&(c=!0,u=I(o,[1,o.shape[0],o.shape[1],o.shape[2],o.shape[3]])),g(u.rank===5,()=>`Error in conv3d: input must be rank 5, but got rank ${u.rank}.`),g(i.rank===5,()=>`Error in conv3d: filter must be rank 5, but got rank ${i.rank}.`),g(u.shape[4]===i.shape[3],()=>`Error in conv3d: depth of input (${u.shape[4]}) must match input depth for filter ${i.shape[3]}.`),g(Xe(n,a),()=>`Error in conv3D: Either strides or dilations must be 1. Got strides ${n} and dilations '${a}'`),g(r==="NDHWC",()=>`Error in conv3d: got dataFormat of ${r} but only NDHWC is currently supported.`),g(Et(a),()=>"Error in conv3D: Dilated rates should be larger than 0."),g(Et(n),()=>"Error in conv3D: Strides should be larger than 0.");const h={x:u,filter:i},l={strides:n,pad:s,dataFormat:r,dilations:a},f=N.runKernel(Wo,h,l);return c?I(f,[f.shape[1],f.shape[2],f.shape[3],f.shape[4]]):f}const il=w({conv3d_:eg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function tg(t,e,n,s,r){g(t.length===e.rank,()=>`Length of inShape (${t.length}) and rank of dy (${e.rank}) must match`);let a=t,o=e,i=!1;e.rank===4&&(i=!0,o=I(e,[1,e.shape[0],e.shape[1],e.shape[2],e.shape[3]]),a=[1,t[0],t[1],t[2],t[3]]);const u=a[4],c=o.shape[4];g(a.length===5,()=>`Error in conv3dDerInput: inShape must be length 5, but got length ${a.length}.`),g(o.rank===5,()=>`Error in conv3dDerInput: dy must be rank 5, but got rank ${o.rank}`),g(n.rank===5,()=>`Error in conv3dDerInput: filter must be rank 5, but got rank ${n.rank}`),g(u===n.shape[3],()=>`Error in conv3dDerInput: depth of input (${u}) must match input depth for filter ${n.shape[3]}.`),g(c===n.shape[4],()=>`Error in conv3dDerInput: depth of output (${c}) must match output depth for filter ${n.shape[4]}.`);const h={dy:o,filter:n},l={pad:r,strides:s,inputShape:a},f=N.runKernel(Mo,h,l);return i?I(f,[f.shape[1],f.shape[2],f.shape[3],f.shape[4]]):f}const ng=w({conv3DBackpropInput_:tg});function sg(t,e,n,s,r){const a=d(t,"x","conv3dTranspose"),o=d(e,"filter","conv3dTranspose");return ng(n,a,o,s,r)}const ul=w({conv3dTranspose_:sg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function rg(t){const n={x:d(t,"x","cos","float32")};return N.runKernel(Uo,n)}const cl=w({cos_:rg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ag(t){const n={x:d(t,"x","cosh","float32")};return N.runKernel(jo,n)}const ll=w({cosh_:ag});/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function og(t,e=0,n=!1,s=!1){const a={x:d(t,"x","cumprod")},o={axis:e,exclusive:n,reverse:s};return N.runKernel(qo,a,o)}const hl=w({cumprod_:og});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ig(t,e=0,n=!1,s=!1){const a={x:d(t,"x","cumsum")},o={axis:e,exclusive:n,reverse:s};return N.runKernel(Go,a,o)}const pl=w({cumsum_:ig});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ug(t,e,n,s=!1){const r=d(t,"x","denseBincount"),a=d(e,"weights","denseBincount");g(r.dtype==="int32",()=>`Error in denseBincount: input dtype must be int32, but got ${r.dtype}`),g(r.rank<=2,()=>`Error in denseBincount: input must be at most rank 2, but got rank ${r.rank}.`),g(n>=0,()=>`size must be non-negative, but got ${n}.`),g(a.size===r.size||a.size===0,()=>`Error in denseBincount: weights must have the same shape as x or 0-length, but got x shape: ${r.shape}, weights shape: ${a.shape}.`);const o={x:r,weights:a},i={size:n,binaryOutput:s};return N.runKernel(Ko,o,i)}const fl=w({denseBincount_:ug});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function cg(t,e,n="NHWC"){const s=d(t,"x","depthToSpace","float32"),r=n==="NHWC"?s.shape[1]:s.shape[2],a=n==="NHWC"?s.shape[2]:s.shape[3],o=n==="NHWC"?s.shape[3]:s.shape[1];g(e>1,()=>`blockSize should be > 1 for depthToSpace, but was: ${e}`),g(r*e>=0,()=>`Negative dimension size caused by overflow when multiplying
    ${r} and ${e}  for depthToSpace with input shape
    ${s.shape}`),g(a*e>=0,()=>`Negative dimension size caused by overflow when multiplying
    ${a} and ${e} for depthToSpace with input shape
        ${s.shape}`),g(o%(e*e)===0,()=>`Dimension size must be evenly divisible by ${e*e} but is ${o} for depthToSpace with input shape ${s.shape}`);const i={x:s},u={blockSize:e,dataFormat:n};return N.runKernel(Xo,i,u)}const dl=w({depthToSpace_:cg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function lg(t,e,n,s,r="NHWC",a=[1,1],o){const i=d(t,"x","depthwiseConv2d","float32"),u=d(e,"filter","depthwiseConv2d","float32");let c=i,h=!1;i.rank===3&&(h=!0,c=I(i,[1,i.shape[0],i.shape[1],i.shape[2]])),g(c.rank===4,()=>`Error in depthwiseConv2d: input must be rank 4, but got rank ${c.rank}.`),g(u.rank===4,()=>`Error in depthwiseConv2d: filter must be rank 4, but got rank ${u.rank}.`);const l=r==="NHWC"?c.shape[3]:c.shape[1];g(l===u.shape[2],()=>`Error in depthwiseConv2d: number of input channels (${l}) must match the inChannels dimension in filter ${u.shape[2]}.`),xe("depthwiseConv2d",s,o);const f={x:c,filter:u},m={strides:n,pad:s,dataFormat:r,dilations:a,dimRoundingMode:o},b=N.runKernel(Zo,f,m);return h?I(b,[b.shape[1],b.shape[2],b.shape[3]]):b}const as=w({depthwiseConv2d_:lg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function hg(t){const n={x:d(t,"x","diag")};return N.runKernel(Qo,n)}const ml=w({diag_:hg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function pg(t,e,n,s,r=[1,1],a="NHWC"){const o=d(t,"x","dilation2d"),i=d(e,"filter","dilation2d");g(o.rank===3||o.rank===4,()=>`Error in dilation2d: input must be rank 3 or 4, but got rank ${o.rank}.`),g(i.rank===3,()=>`Error in dilation2d: filter must be rank 3, but got rank ${i.rank}.`),g(a==="NHWC",()=>`Error in dilation2d: Only NHWC is currently supported, but got dataFormat of ${a}`);let u=o,c=!1;o.rank===3&&(u=I(o,[1,o.shape[0],o.shape[1],o.shape[2]]),c=!0),g(u.shape[3]===i.shape[2],()=>`Error in dilation2d:  input and filter must have the same depth: ${u.shape[3]} vs ${i.shape[2]}`);const h={x:u,filter:i},l={strides:n,pad:s,dilations:r},f=N.runKernel(ei,h,l);return c?I(f,[f.shape[1],f.shape[2],f.shape[3]]):f}const gl=w({dilation2d_:pg});/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function yl(t,e){const n=t.length,s=[];for(let r=0;r<n;r++){const a=n-1-r,o=t[a]||1;(e[e.length-1-r]||1)>1&&o===1&&s.unshift(a)}return s}function _r(t,e){const n=[];for(let s=0;s<e.length;s++){const r=t[t.length-s-1],a=e.length-s-1,o=e[a];(r==null||r===1&&o>1)&&n.unshift(a)}return n}function re(t,e){const n=Math.max(t.length,e.length),s=new Array(n);for(let r=0;r<n;r++){let a=t[t.length-r-1];a==null&&(a=1);let o=e[e.length-r-1];if(o==null&&(o=1),a===1)s[n-r-1]=o;else if(o===1)s[n-r-1]=a;else if(a!==o){const i=`Operands could not be broadcast together with shapes ${t} and ${e}.`;throw Error(i)}else s[n-r-1]=a}return s}const fg=Object.freeze(Object.defineProperty({__proto__:null,assertAndGetBroadcastShape:re,getBroadcastDims:yl,getReductionAxes:_r},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function dg(t,e){let n=d(t,"a","equal","string_or_numeric"),s=d(e,"b","equal","string_or_numeric");[n,s]=ee(n,s),re(n.shape,s.shape);const r={a:n,b:s};return N.runKernel(ai,r)}const Ir=w({equal_:dg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function mg(t,e,n){const s=d(e,"a","where"),r=d(n,"b","where"),a=d(t,"condition","where","bool"),o=re(re(a.shape,s.shape),r.shape),i=Yt(a,o),u=Yt(s,o),c=Yt(r,o),h={condition:i,t:u,e:c};return N.runKernel(Su,h)}const He=w({where_:mg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function gg(t){const n={x:d(t,"x","zerosLike")};return N.runKernel(Qu,n)}const Te=w({zerosLike_:gg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function yg(t,e){let n=d(t,"a","div"),s=d(e,"b","div");[n,s]=ee(n,s);const r=Z(n,s),a=Te(r),o=Ir(s,a);return He(o,a,r)}const bl=w({divNoNan_:yg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function bg(t,e){const n=d(t,"t1","dot"),s=d(e,"t2","dot");g((n.rank===1||n.rank===2)&&(s.rank===1||s.rank===2),()=>`Error in dot: inputs must all be rank 1 or 2, but got ranks ${n.rank} and ${s.rank}.`);const r=n.rank===1?n.size:n.shape[1],a=s.rank===1?s.size:s.shape[0];if(g(r===a,()=>`Error in dot: inner dimensions of inputs must match, but got ${r} and ${a}.`),n.rank===1&&s.rank===1){const o=I(n,[1,-1]),i=I(s,[-1,1]),u=j(o,i);return I(u,[])}else if(n.rank===1&&s.rank===2){const o=I(n,[1,-1]),i=I(s,[s.shape[0],s.shape[1]]),u=j(o,i);return I(u,[u.size])}else if(n.rank===2&&s.rank===1){const o=I(s,[-1,1]),i=j(n,o);return I(i,[i.size])}else{const o=I(s,[s.shape[0],s.shape[1]]);return j(n,o)}}const wl=w({dot_:bg});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function wg(t,...e){const n=e.map((r,a)=>d(r,`tensors${a}`,"einsum")),s={equation:t};return N.runKernel(ni,n,s)}const mt=w({einsum_:wg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ng(t){const n={x:d(t,"x","elu","float32")};return N.runKernel(si,n)}const xr=w({elu_:Ng});/**
 * @license
 * Copyright 2023 Google LLC.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Sg(t,e){const n=d(t,"x","ensureShape","string_or_numeric");if(!to(n.shape,e))throw new Error(`EnsureShape: Shape of tensor ${n.shape} is not compatible with expected shape ${e}`);return t}const Nl=w({ensureShape_:Sg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Tg(t){let e=d(t,"x","erf");g(e.dtype==="int32"||e.dtype==="float32",()=>"Input dtype must be `int32` or `float32`."),e.dtype==="int32"&&(e=J(e,"float32"));const n={x:e};return N.runKernel(ri,n)}const Sl=w({erf_:Tg});/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ar(t,e){for(let n=0;n<t.length;++n)if(t[t.length-n-1]!==e-1-n)return!1;return!0}function Tl(t,e,n){const s=t.length+e.length,r=[];let a=0,o=0;for(let i=0;i<s;i++)n.indexOf(i)===-1?r.push(t[a++]):r.push(e[o++]);return r}function $g(t,e){const n=[],s=t.length;for(let a=0;a<s;a++)e.indexOf(a)===-1&&n.push(t[a]);const r=e.map(a=>t[a]);return[n,r]}function Tn(t,e){const n=e.map(s=>1);return Tl(t,n,e)}function Eg(t,e,n){g(Ar(e,n),()=>`${t} supports only inner-most axes for now. Got axes ${e} and rank-${n} input.`)}function kg(t,e){if(Ar(t,e))return null;const n=[];for(let s=0;s<e;++s)t.indexOf(s)===-1&&n.push(s);return t.forEach(s=>n.push(s)),n}function vg(t){return t.map((e,n)=>[n,e]).sort((e,n)=>e[1]-n[1]).map(e=>e[0])}function _g(t,e){const n=[];for(let s=e-t;s<e;++s)n.push(s);return n}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ig(t,e=null,n=!1){const r={x:d(t,"x","max")},a={reductionIndices:e,keepDims:n};return N.runKernel(Ci,r,a)}const Nt=w({max_:Ig});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function xg(t,e=null,n=!1){const r={x:d(t,"x","min")},a={axis:e,keepDims:n};return N.runKernel(Vi,r,a)}const Zn=w({min_:xg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ag(t,e){let n=d(t,"base","pow"),s=d(e,"exp","pow");[n,s]=ee(n,s);const r={a:n,b:s};return N.runKernel(tu,r)}const Pt=w({pow_:Ag});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function M(t,e){if((ie(t)&&e!=="string"||Array.isArray(t))&&e!=="complex64")throw new Error("Error creating a new Scalar: value must be a primitive (number|boolean|string)");if(e==="string"&&ie(t)&&!(t instanceof Uint8Array))throw new Error("When making a scalar from encoded string, the value must be `Uint8Array`.");return ct(t,[],[],e)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Og(t){const n={x:d(t,"x","sqrt","float32")};return N.runKernel(xu,n)}const ze=w({sqrt_:Og});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Dg(t){const e=d(t,"x","square"),n={};return N.runKernel("Square",{x:e},n)}const Ie=w({square_:Dg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Fg(t,e=null,n=!1){let s=d(t,"x","sum");s.dtype==="bool"&&(s=J(s,"int32"));const r={x:s},a={axis:e,keepDims:n};return N.runKernel(Au,r,a)}const X=w({sum_:Fg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Cg(t,e="euclidean",n=null,s=!1){t=d(t,"x","norm");const r=$l(t,e,n);let a=r.shape;if(s){const o=dn(n,t.shape);a=Tn(r.shape,o)}return I(r,a)}function $l(t,e,n=null){if(t.rank===0)return Se(t);if(t.rank!==1&&n===null)return $l(I(t,[-1]),e,n);if(t.rank===1||typeof n=="number"||Array.isArray(n)&&n.length===1){if(e===1)return X(Se(t),n);if(e===1/0)return Nt(Se(t),n);if(e===-1/0)return Zn(Se(t),n);if(e==="euclidean"||e===2)return ze(X(Pt(Se(t),M(2,"int32")),n));throw new Error(`Error in norm: invalid ord value: ${e}`)}if(Array.isArray(n)&&n.length===2){if(e===1)return Nt(X(Se(t),n[0]),n[1]-1);if(e===1/0)return Nt(X(Se(t),n[1]),n[0]);if(e===-1/0)return Zn(X(Se(t),n[1]),n[0]);if(e==="fro"||e==="euclidean")return ze(X(Ie(t),n));throw new Error(`Error in norm: invalid ord value: ${e}`)}throw new Error(`Error in norm: invalid axis: ${n}`)}const $n=w({norm_:Cg});/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Rg(t,e=null,n=!1){return $n(t,"euclidean",e,n)}const El=w({euclideanNorm_:Rg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Lg(t){const n={x:d(t,"x","exp")};return N.runKernel(oi,n)}const it=w({exp_:Lg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Bg(t,e=0){const n=d(t,"x","expandDims","string_or_numeric");g(e<=n.rank,()=>"Axis must be <= rank of the tensor");const s={input:n},r={dim:e};return N.runKernel(ii,s,r)}const Me=w({expandDims_:Bg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Pg(t){const n={x:d(t,"x","expm1")};return N.runKernel(ui,n)}const kl=w({expm1_:Pg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function zg(t,e){const n=d(t,"x","tile","string_or_numeric");g(n.rank===e.length,()=>`Error in transpose: rank of input ${n.rank} must match length of reps ${e}.`);const s={x:n},r={reps:e};return N.runKernel(dr,s,r)}const Ft=w({tile_:zg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Vg(t,e,n,s="float32"){e==null&&(e=t);const r=Pe([t,e],s),a=t<=e?t:e;for(let i=0;i<a;++i)r.set(1,i,i);const o=I(r.toTensor(),[t,e]);if(n==null)return o;if(n.length===1)return Ft(Me(o,0),[n[0],1,1]);if(n.length===2)return Ft(Me(Me(o,0),0),[n[0],n[1],1,1]);if(n.length===3)return Ft(Me(Me(Me(o,0),0),0),[n[0],n[1],n[2],1,1]);throw new Error(`eye() currently supports only 1D and 2D batchShapes, but received ${n.length}D.`)}const Or=w({eye_:Vg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Wg(t){const n={x:d(t,"x","floor","float32")};return N.runKernel(pi,n)}const Dr=w({floor_:Wg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Mg(t,e,n=0,s=0){const r=d(t,"x","gather"),a=d(e,"indices","gather","int32"),o={x:r,indices:a},i={axis:n,batchDims:s};return N.runKernel(mi,o,i)}const Fr=w({gather_:Mg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ug(t,e){let n=d(t,"a","greater","string_or_numeric"),s=d(e,"b","greater","string_or_numeric");[n,s]=ee(n,s),re(n.shape,s.shape);const r={a:n,b:s};return N.runKernel(yi,r)}const En=w({greater_:Ug});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function jg(t,e){let n=d(t,"a","greaterEqual","string_or_numeric"),s=d(e,"b","greaterEqual","string_or_numeric");[n,s]=ee(n,s),re(n.shape,s.shape);const r={a:n,b:s};return N.runKernel(bi,r)}const Cr=w({greaterEqual_:jg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function qg(t){const n={input:d(t,"input","imag")};return N.runKernel(Ni,n)}const kn=w({imag_:qg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Gg(t){const n={x:d(t,"x","isFinite")};return N.runKernel(Si,n)}const vl=w({isFinite_:Gg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Hg(t){const n={x:d(t,"x","isInf")};return N.runKernel(Ti,n)}const _l=w({isInf_:Hg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Kg(t){const n={x:d(t,"x","isNaN")};return N.runKernel($i,n)}const Il=w({isNaN_:Kg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Xg(t,e=.2){const s={x:d(t,"x","leakyRelu")},r={alpha:e};return N.runKernel(Ei,s,r)}const Rr=w({leakyRelu_:Xg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Zg(t,e){let n=d(t,"a","less","string_or_numeric"),s=d(e,"b","less","string_or_numeric");[n,s]=ee(n,s),re(n.shape,s.shape);const r={a:n,b:s};return N.runKernel(ki,r)}const Jn=w({less_:Zg});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Jg(t,e){let n=d(t,"a","lessEqual","string_or_numeric"),s=d(e,"b","lessEqual","string_or_numeric");[n,s]=ee(n,s),re(n.shape,s.shape);const r={a:n,b:s};return N.runKernel(vi,r)}const os=w({lessEqual_:Jg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function xl(t,e,n){if(n<=0)throw new Error("The number of values should be positive.");const s={start:t,stop:e,num:n};return N.runKernel(_i,{},s)}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Yg(t,e=5,n=1,s=1,r=.5){const a=d(t,"x","localResponseNormalization");g(a.rank===4||a.rank===3,()=>`Error in localResponseNormalization: x must be rank 3 or 4 but got
               rank ${a.rank}.`),g(Rt(e),()=>`Error in localResponseNormalization: depthRadius must be an integer but got depthRadius ${e}.`);let o=a,i=!1;a.rank===3&&(i=!0,o=I(a,[1,a.shape[0],a.shape[1],a.shape[2]]));const u={x:o},c={depthRadius:e,bias:n,alpha:s,beta:r},h=N.runKernel(Fi,u,c);return i?I(h,[h.shape[1],h.shape[2],h.shape[3]]):h}const Al=w({localResponseNormalization_:Yg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Qg(t){const n={x:d(t,"x","log","float32")};return N.runKernel(Ii,n)}const zt=w({log_:Qg});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ey(t){const n={x:d(t,"x","log1p")};return N.runKernel(xi,n)}const Lr=w({log1p_:ey});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ty(t){return g(st(t),()=>"The f passed in grad(f) must be a function"),(e,n)=>{const s=d(e,"x","tf.grad","string_or_numeric"),r=n!=null?d(n,"dy","tf.grad"):null;return N.tidy(()=>{const{value:a,grads:o}=N.gradients(()=>t(s),[s],r);return r!=null&&ge(a.shape,r.shape,"The shape of dy passed in grad(f)(x, dy) must match the shape returned by f(x)"),is(o),o[0]})}}function ny(t){return g(st(t),()=>"The f passed in grads(f) must be a function"),(e,n)=>{g(Array.isArray(e),()=>"The args passed in grads(f)(args) must be an array of `Tensor`s or `TensorLike`s");const s=rn(e,"args","tf.grads","string_or_numeric"),r=n!=null?d(n,"dy","tf.grads"):null;return N.tidy(()=>{const{value:a,grads:o}=N.gradients(()=>t(...s),s,r);return r!=null&&ge(a.shape,r.shape,"The shape of dy passed in grads(f)([x1,...], dy) must match the shape returned by f([x1,...])"),is(o),o})}}function sy(t){return g(st(t),()=>"The f passed in valueAndGrad(f) must be a function"),(e,n)=>{g(e instanceof ne,()=>"The x passed in valueAndGrad(f)(x) must be a tensor"),g(n==null||n instanceof ne,()=>"The dy passed in valueAndGrad(f)(x, dy) must be a tensor");const{grads:s,value:r}=N.gradients(()=>t(e),[e],n);return is(s),{grad:s[0],value:r}}}function ry(t){return g(st(t),()=>"The f passed in valueAndGrads(f) must be a function"),(e,n)=>{g(Array.isArray(e)&&e.every(r=>r instanceof ne),()=>"The args passed in valueAndGrads(f)(args) must be array of tensors"),g(n==null||n instanceof ne,()=>"The dy passed in valueAndGrads(f)(args, dy) must be a tensor");const s=N.gradients(()=>t(...e),e,n);return n!=null&&ge(s.value.shape,n.shape,"The shape of dy passed in valueAndGrads(f)([x1,...], dy) must match the shape returned by f([x1,...])"),is(s.grads),s}}function Ol(t,e){g(st(t),()=>"The f passed in variableGrads(f) must be a function"),g(e==null||Array.isArray(e)&&e.every(c=>c instanceof sn),()=>"The varList passed in variableGrads(f, varList) must be an array of variables");const n=e!=null;if(!n){e=[];for(const c in N.registeredVariables)e.push(N.registeredVariables[c])}const s=n?e.filter(c=>!c.trainable):null,r=e.length;e=e.filter(c=>c.trainable),g(e.length>0,()=>`variableGrads() expects at least one of the input variables to be trainable, but none of the ${r} variables is trainable.`);const a=!0,{value:o,grads:i}=N.gradients(t,e,null,a);g(i.some(c=>c!=null),()=>"Cannot find a connection between any variable and the result of the loss function y=f(x). Please make sure the operations that use variables are inside the function f passed to minimize()."),g(o.rank===0,()=>`The f passed in variableGrads(f) must return a scalar, but it returned a rank-${o.rank} tensor`);const u={};return e.forEach((c,h)=>{i[h]!=null&&(u[c.name]=i[h])}),s!=null&&s.forEach(c=>u[c.name]=null),{value:o,grads:u}}function Ve(t){return N.customGrad(t)}function is(t){if(t.filter(n=>n==null).length>0)throw new Error(`Cannot compute gradient of y=f(x) with respect to x. Make sure that
    the f you passed encloses all operations that lead from x to y.`)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ay(t){const n={x:d(t,"x","neg")};return N.runKernel(Gi,n)}const Fe=w({neg_:ay});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function oy(t){const n={x:d(t,"x","softplus")};return N.runKernel(Iu,n)}const Br=w({softplus_:oy});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function iy(t){const e=d(t,"x","logSigmoid");return Ve(s=>({value:Fe(Br(Fe(s))),gradFunc:o=>D(o,wt(Fe(s)))}))(e)}const Dl=w({logSigmoid_:iy});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function uy(t,e){let n=d(t,"a","sub"),s=d(e,"b","sub");[n,s]=ee(n,s);const r={a:n,b:s};return N.runKernel(qu,r)}const W=w({sub_:uy});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function cy(t,e=-1){const n=d(t,"logits","logSoftmax");if(e===-1&&(e=n.rank-1),e!==n.rank-1)throw Error(`Log Softmax along a non-last dimension is not yet supported. Logits was rank ${n.rank} and axis was ${e}`);return Ve((r,a)=>{const i=Nt(r,e,!0),u=W(r,i),c=W(J(u,"float32"),zt(X(it(u),e,!0)));return a([c]),{value:c,gradFunc:(l,f)=>{const[m]=f,b=!0,T=it(m);return W(l,D(X(l,e,b),T))}}})(n)}const Fl=w({logSoftmax_:cy});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ly(t,e=null,n=!1){const s=d(t,"x","logSumExp"),r=dn(e,s.shape),a=Nt(s,r,!0),o=W(s,a),i=it(o),u=X(i,r),c=zt(u),h=B(I(a,c.shape),c);if(n){const l=Tn(h.shape,r);return I(h,l)}return h}const Pr=w({logSumExp_:ly});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function hy(t,e){const n=d(t,"a","logicalAnd","bool"),s=d(e,"b","logicalAnd","bool");re(n.shape,s.shape);const r={a:n,b:s};return N.runKernel(Ai,r)}const cn=w({logicalAnd_:hy});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function py(t){const n={x:d(t,"x","logicalNot","bool")};return N.runKernel(Oi,n)}const zr=w({logicalNot_:py});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function fy(t,e){const n=d(t,"a","logicalOr","bool"),s=d(e,"b","logicalOr","bool");re(n.shape,s.shape);const r={a:n,b:s};return N.runKernel(Di,r)}const Vr=w({logicalOr_:fy});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function dy(t,e){const n=d(t,"a","logicalXor","bool"),s=d(e,"b","logicalXor","bool");return re(n.shape,s.shape),cn(Vr(t,e),zr(cn(t,e)))}const Cl=w({logicalXor_:dy});/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const xn=2147483648;function my(t,e,n="left"){const s=d(t,"sortedSequence","searchSorted"),r=d(e,"values","searchSorted"),a=s.shape[s.shape.length-1],o=r.shape[r.shape.length-1],i=I(s,[-1,a]),u=I(r,[-1,o]);if(i.rank<2)throw new Error("Sorted input argument must be at least 2-dimensional");if(i.shape[0]!==u.shape[0])throw new Error("Leading dimension of 'sortedSequence' and 'values' must match.");if(G(u.shape)>=xn)throw new Error(`values tensor size must less than ${xn}`);if(i.shape[1]>=xn)throw new Error(`trailing dim_size must less than ${xn} for int32 output type, was ${i.shape[1]}`);const c={sortedSequence:i,values:u},h={side:n};return N.runKernel(Nu,c,h)}const us=w({searchSorted_:my});/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Rl(t,e){return us(t,e,"left")}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function gy(t,e,n,s,r){const a=d(t,"x","maxPool"),o=1;let i=a,u=!1;a.rank===3&&(u=!0,i=I(a,[1,a.shape[0],a.shape[1],a.shape[2]])),g(i.rank===4,()=>`Error in maxPool: input must be rank 4 but got rank ${i.rank}.`),g(Xe(n,o),()=>`Error in maxPool: Either strides or dilations must be 1. Got strides ${n} and dilations '${o}'`),xe("maxPool",s,r);const c={x:i},h={filterSize:e,strides:n,pad:s,dimRoundingMode:r},l=N.runKernel(Li,c,h);return u?I(l,[l.shape[1],l.shape[2],l.shape[3]]):l}const Wr=w({maxPool_:gy});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function yy(t,e=[1,1,1],n,s,r,a="NDHWC"){const o=d(t,"x","maxPool3d");let i=o,u=!1;o.rank===4&&(u=!0,i=I(o,[1,o.shape[0],o.shape[1],o.shape[2],o.shape[3]])),g(i.rank===5,()=>`Error in maxPool3d: x must be rank 5 but got rank ${i.rank}.`),g(a==="NDHWC",()=>`Error in maxPool3d: Only NDHWC is currently supported, but got dataFormat of ${a}`),xe("maxPool3d",s,r);const c={x:i},h={filterSize:e,strides:n,pad:s,dimRoundingMode:r,dataFormat:a},l=N.runKernel(Bi,c,h);return u?I(l,[l.shape[1],l.shape[2],l.shape[3],l.shape[4]]):l}const Ll=w({maxPool3d_:yy});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function by(t,e,n,s,r=!1){const o={x:d(t,"x","maxPoolWithArgmax")},i={filterSize:e,strides:n,pad:s,includeBatchInIndex:r},u=N.runKernel(Pi,o,i);return{result:u[0],indexes:u[1]}}const Bl=w({maxPoolWithArgmax_:by});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function wy(t,e){let n=d(t,"a","maximum"),s=d(e,"b","maximum");[n,s]=ee(n,s),n.dtype==="bool"&&(n=J(n,"int32"),s=J(s,"int32")),re(n.shape,s.shape);const r={a:n,b:s};return N.runKernel(Ri,r)}const Mr=w({maximum_:wy});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ny(t,e=null,n=!1){const r={x:d(t,"x","mean")},a={axis:e,keepDims:n};return N.runKernel(zi,r,a)}const ln=w({mean_:Ny});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function kt(t,e="float32"){if($e(t),e==="complex64"){const s=kt(t,"float32"),r=kt(t,"float32");return Ke(s,r)}const n=ns(G(t),e);return N.makeTensor(n,t,e)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function tt(t,e="float32"){if($e(t),e==="complex64"){const s=tt(t,"float32"),r=kt(t,"float32");return Ke(s,r)}const n=ir(G(t),e);return N.makeTensor(n,t,e)}/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Pl(t,e,{indexing:n="xy"}={}){if(n!=="xy"&&n!=="ij")throw new TypeError(`${n} is not a valid third argument to meshgrid`);if(t===void 0)return[];let s=d(t,"x","meshgrid",t instanceof ne?t.dtype:"float32");if(e===void 0)return[s];let r=d(e,"y","meshgrid",e instanceof ne?e.dtype:"float32");const a=G(s.shape),o=G(r.shape);return n==="xy"?(s=I(s,[1,-1]),r=I(r,[-1,1]),[j(tt([o,1],s.dtype),s),j(r,tt([1,a],r.dtype))]):(s=I(s,[-1,1]),r=I(r,[1,-1]),[j(s,tt([1,o],s.dtype)),j(tt([a,1],r.dtype),r)])}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Sy(t,e){let n=d(t,"a","minimum"),s=d(e,"b","minimum");[n,s]=ee(n,s),n.dtype==="bool"&&(n=J(n,"int32"),s=J(s,"int32")),re(n.shape,s.shape);const r={a:n,b:s};return N.runKernel(Wi,r)}const hn=w({minimum_:Sy});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ty(t,e,n){g(n==="reflect"||n==="symmetric",()=>`Invalid mode. Mode must be either reflect or symmetric. Got ${n}.`);const s=d(t,"x","mirrorPad");if(s.rank===0)throw new Error("mirrorPad(scalar) is not defined. Pass non-scalar to mirrorPad");g(e.length===s.rank,()=>`Padding doesn't match input. Must be ${s.rank}. Got ${e.length}.`);const r=n==="reflect"?1:0;for(let i=0;i<s.rank;i++)g(e[i].length===2,()=>"Invalid number of paddings. Must be length of 2 each."),g(e[i][0]>=0&&e[i][0]<=s.shape[i]-r&&e[i][1]>=0&&e[i][1]<=s.shape[i]-r,()=>`Padding in dimension ${i} cannot be greater than or equal to ${s.shape[i]-r} or less than 0 for input of shape ${s.shape}`);const a={paddings:e,mode:n},o={x:s};return N.runKernel(Mi,o,a)}const zl=w({mirrorPad_:Ty});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function $y(t,e){let n=d(t,"a","mod"),s=d(e,"b","mod");[n,s]=ee(n,s);const r={a:n,b:s};return N.runKernel(Ui,r)}const Vl=w({mod_:$y});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ey(t,e=null,n=!1){t=d(t,"x","moments");const s=dn(e,t.shape),r=ln(t,s,n);let a=r.shape;n||(a=Tn(r.shape,s));const o=Ie(W(J(t,"float32"),I(r,a))),i=ln(o,s,n);return{mean:r,variance:i}}const Wl=w({moments_:Ey});function ky(t,e,n,s){const r=d(e,"data","multiRNNCell"),a=rn(n,"c","multiRNNCell"),o=rn(s,"h","multiRNNCell");let i=r;const u=[];for(let l=0;l<t.length;l++){const f=t[l](i,a[l],o[l]);u.push(f[0]),u.push(f[1]),i=f[1]}const c=[],h=[];for(let l=0;l<u.length;l+=2)c.push(u[l]),h.push(u[l+1]);return[c,h]}const Ml=w({multiRNNCell_:ky});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function vy(t,e,n,s=!1){const r=d(t,"logits","multinomial"),a=r.size,o=r.rank;if(a<2)throw new Error(`Error in multinomial: you need at least 2 outcomes, but got ${a}.`);if(o>2)throw new Error(`Rank of probabilities must be 1 or 2, but is ${o}`);n=n||Math.random();const u={logits:o===1?I(r,[1,-1]):r},c={numSamples:e,seed:n,normalized:s},h=N.runKernel(ji,u,c);return o===1?I(h,[h.size]):h}const Ul=w({multinomial_:vy});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function _y(t,e){let n=d(t,"a","notEqual","string_or_numeric"),s=d(e,"b","notEqual","string_or_numeric");[n,s]=ee(n,s),re(n.shape,s.shape);const r={a:n,b:s};return N.runKernel(Hi,r)}const Ur=w({notEqual_:_y});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Iy(t,e,n=1,s=0,r="int32"){if(e<2)throw new Error(`Error in oneHot: depth must be >=2, but it is ${e}`);const o={indices:d(t,"indices","oneHot","int32")},i={dtype:r,depth:e,onValue:n,offValue:s};return N.runKernel(Yi,o,i)}const Yn=w({oneHot_:Iy});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function xy(t){const n={x:d(t,"x","onesLike")};return N.runKernel(Ji,n)}const jl=w({onesLike_:xy});function Ay(t,e){const n=d(t,"v1","outerProduct"),s=d(e,"v2","outerProduct");g(n.rank===1&&s.rank===1,()=>`Error in outerProduct: inputs must be rank 1, but got ranks ${n.rank} and ${s.rank}.`);const r=I(n,[-1,1]),a=I(s,[1,-1]);return j(r,a)}const ql=w({outerProduct_:Ay});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Oy(t,e,n=0){const s=d(t,"x","pad");if(s.rank===0)throw new Error("pad(scalar) is not defined. Pass non-scalar to pad");const r={paddings:e,constantValue:n},a={x:s};return N.runKernel(eu,a,r)}const qt=w({pad_:Oy});function Dy(t,e,n=0){return g(e.length===2,()=>"Invalid number of paddings. Must be length of 2."),qt(t,[e],n)}const Gl=w({pad1d_:Dy});function Fy(t,e,n=0){return g(e.length===2&&e[0].length===2&&e[1].length===2,()=>"Invalid number of paddings. Must be length of 2 each."),qt(t,e,n)}const Hl=w({pad2d_:Fy});function Cy(t,e,n=0){return g(e.length===3&&e[0].length===2&&e[1].length===2&&e[2].length===2,()=>"Invalid number of paddings. Must be length of 2 each."),qt(t,e,n)}const Kl=w({pad3d_:Cy});function Ry(t,e,n=0){return g(e.length===4&&e[0].length===2&&e[1].length===2&&e[2].length===2&&e[3].length===2,()=>"Invalid number of paddings. Must be length of 2 each."),qt(t,e,n)}const Xl=w({pad4d_:Ry});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ly(t,e,n){const s=d(t,"x","spaceToBatchND");g(s.rank>=1+e.length,()=>`input rank ${s.rank} should be > than [blockShape] ${e.length}`),g(n.length===e.length,()=>`paddings.shape[0] ${n.length} must be equal to [blockShape] ${e.length}`),g(s.shape.reduce((o,i,u)=>u>0&&u<=e.length?o&&(i+n[u-1][0]+n[u-1][1])%e[u-1]===0:o,!0),()=>`input spatial dimensions ${s.shape.slice(1)} with paddings ${n.toString()} must be divisible by blockShapes ${e.toString()}`);const r={x:s},a={blockShape:e,paddings:n};return N.runKernel(Ou,r,a)}const jr=w({spaceToBatchND_:Ly});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function By(t,e,n,s,r,a,o){r==null&&(r=[1,1]),a==null&&(a=1),s===0&&(s="valid");const i=d(t,"x","maxPool");let u=i,c=!1;i.rank===3&&(c=!0,u=I(i,[1,i.shape[0],i.shape[1],i.shape[2]])),g(Xe(a,r),()=>`Error in pool: Either strides or dilations must be 1. Got strides ${a} and dilations '${r}'`);const h=Mc(u.shape,e,a,r,s),l=[h.dilationHeight,h.dilationWidth];let f;s==="same"?f=zy([h.filterHeight,h.filterWidth],l):f=[[0,0],[0,0]];const m=l[0]===1&&l[1]===1,[b,T]=Py([h.inHeight,h.inWidth],l,f),S=m?s:"valid",$=m?u:jr(u,l,b),v=(n==="avg"?()=>Er($,e,a,S,o):()=>Wr($,e,a,S,o))(),_=m?v:kr(v,l,T);return c?I(_,[_.shape[1],_.shape[2],_.shape[3]]):_}function Py(t,e,n){const s=n.map(h=>h[0]),r=n.map(h=>h[1]),a=t.concat(s,r),o=e.map((h,l)=>(h-a[l]%h)%h),i=r.map((h,l)=>h+o[l]),u=e.map((h,l)=>[s[l],i[l]]),c=e.map((h,l)=>[0,o[l]]);return[u,c]}function zy(t,e){const s=t.map((o,i)=>o+(o-1)*(e[i]-1)).map(o=>o-1),r=s.map(o=>Math.floor(o/2)),a=s.map((o,i)=>o-r[i]);return s.map((o,i)=>[r[i],a[i]])}const Zl=w({pool_:By});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Vy(t,e){const n=d(t,"x","prelu"),s=d(e,"alpha","prelu"),r={x:n,alpha:s};return N.runKernel(nu,r)}const qr=w({prelu_:Vy});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Wy(t,e=null,n=!1){let s=d(t,"x","prod");s.dtype==="bool"&&(s=J(s,"int32"));const r={x:s},a={axis:e,keepDims:n};return N.runKernel(su,r,a)}const Jl=w({prod_:Wy});/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function My(t,e,n,s){const r=t.map((h,l)=>d(h,`tensors${l}`,"raggedGather","int32")),a=d(e,"paramsDenseValues","raggedGather"),o=d(n,"indices","raggedGather","int32"),i={paramsNestedSplits:r,paramsDenseValues:a,indices:o},u={outputRaggedRank:s},c=N.runKernel(ru,i,u);return{outputNestedSplits:c.slice(0,c.length-1),outputDenseValues:c[c.length-1]}}const Yl=w({raggedGather_:My});/**
 * @license
 * Copyright 2022 Google LLC.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Uy(t,e,n){const s=d(t,"starts","raggedRange"),r=d(e,"limits","raggedRange",s.dtype),a=d(n,"deltas","raggedRange",s.dtype),o={starts:s,limits:r,deltas:a},i=N.runKernel(au,o);return{rtNestedSplits:i[0],rtDenseValues:i[1]}}const Ql=w({raggedRange_:Uy});/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function jy(t,e,n,s,r){const a=d(t,"shape","raggedTensorToTensor","int32"),o=d(e,"values","raggedTensorToTensor"),i=d(n,"defaultValue","raggedTensorToTensor",o.dtype),u=s.map((l,f)=>d(l,`tensors${f}`,"raggedTensorToTensor","int32")),c={shape:a,values:o,defaultValue:i,rowPartitionTensors:u},h={rowPartitionTypes:r};return N.runKernel(ou,c,h)}const eh=w({raggedTensorToTensor_:jy});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function qy(t,e,n){$e(t);const s=G(t);let r=null;if(n==null||n==="float32")r=new Float32Array(s);else if(n==="int32")r=new Int32Array(s);else if(n==="bool")r=new Uint8Array(s);else throw new Error(`Unknown data type ${n}`);for(let a=0;a<s;a++)r[a]=e();return N.makeTensor(r,t,n)}const th=w({rand_:qy});var Cn={exports:{}},Gy=Cn.exports,Ia;function Hy(){return Ia||(Ia=1,function(t){(function(e,n,s){function r(u){var c=this,h=i();c.next=function(){var l=2091639*c.s0+c.c*23283064365386963e-26;return c.s0=c.s1,c.s1=c.s2,c.s2=l-(c.c=l|0)},c.c=1,c.s0=h(" "),c.s1=h(" "),c.s2=h(" "),c.s0-=h(u),c.s0<0&&(c.s0+=1),c.s1-=h(u),c.s1<0&&(c.s1+=1),c.s2-=h(u),c.s2<0&&(c.s2+=1),h=null}function a(u,c){return c.c=u.c,c.s0=u.s0,c.s1=u.s1,c.s2=u.s2,c}function o(u,c){var h=new r(u),l=c&&c.state,f=h.next;return f.int32=function(){return h.next()*4294967296|0},f.double=function(){return f()+(f()*2097152|0)*11102230246251565e-32},f.quick=f,l&&(typeof l=="object"&&a(l,h),f.state=function(){return a(h,{})}),f}function i(){var u=4022871197,c=function(h){h=String(h);for(var l=0;l<h.length;l++){u+=h.charCodeAt(l);var f=.02519603282416938*u;u=f>>>0,f-=u,f*=u,u=f>>>0,f-=u,u+=f*4294967296}return(u>>>0)*23283064365386963e-26};return c}n&&n.exports?n.exports=o:this.alea=o})(Gy,t)}(Cn)),Cn.exports}var Rn={exports:{}},Ky=Rn.exports,xa;function Xy(){return xa||(xa=1,function(t){(function(e,n,s){function r(i){var u=this,c="";u.x=0,u.y=0,u.z=0,u.w=0,u.next=function(){var l=u.x^u.x<<11;return u.x=u.y,u.y=u.z,u.z=u.w,u.w^=u.w>>>19^l^l>>>8},i===(i|0)?u.x=i:c+=i;for(var h=0;h<c.length+64;h++)u.x^=c.charCodeAt(h)|0,u.next()}function a(i,u){return u.x=i.x,u.y=i.y,u.z=i.z,u.w=i.w,u}function o(i,u){var c=new r(i),h=u&&u.state,l=function(){return(c.next()>>>0)/4294967296};return l.double=function(){do var f=c.next()>>>11,m=(c.next()>>>0)/4294967296,b=(f+m)/(1<<21);while(b===0);return b},l.int32=c.next,l.quick=l,h&&(typeof h=="object"&&a(h,c),l.state=function(){return a(c,{})}),l}n&&n.exports?n.exports=o:this.xor128=o})(Ky,t)}(Rn)),Rn.exports}var Ln={exports:{}},Zy=Ln.exports,Aa;function Jy(){return Aa||(Aa=1,function(t){(function(e,n,s){function r(i){var u=this,c="";u.next=function(){var l=u.x^u.x>>>2;return u.x=u.y,u.y=u.z,u.z=u.w,u.w=u.v,(u.d=u.d+362437|0)+(u.v=u.v^u.v<<4^(l^l<<1))|0},u.x=0,u.y=0,u.z=0,u.w=0,u.v=0,i===(i|0)?u.x=i:c+=i;for(var h=0;h<c.length+64;h++)u.x^=c.charCodeAt(h)|0,h==c.length&&(u.d=u.x<<10^u.x>>>4),u.next()}function a(i,u){return u.x=i.x,u.y=i.y,u.z=i.z,u.w=i.w,u.v=i.v,u.d=i.d,u}function o(i,u){var c=new r(i),h=u&&u.state,l=function(){return(c.next()>>>0)/4294967296};return l.double=function(){do var f=c.next()>>>11,m=(c.next()>>>0)/4294967296,b=(f+m)/(1<<21);while(b===0);return b},l.int32=c.next,l.quick=l,h&&(typeof h=="object"&&a(h,c),l.state=function(){return a(c,{})}),l}n&&n.exports?n.exports=o:this.xorwow=o})(Zy,t)}(Ln)),Ln.exports}var Bn={exports:{}},Yy=Bn.exports,Oa;function Qy(){return Oa||(Oa=1,function(t){(function(e,n,s){function r(i){var u=this;u.next=function(){var h=u.x,l=u.i,f,m;return f=h[l],f^=f>>>7,m=f^f<<24,f=h[l+1&7],m^=f^f>>>10,f=h[l+3&7],m^=f^f>>>3,f=h[l+4&7],m^=f^f<<7,f=h[l+7&7],f=f^f<<13,m^=f^f<<9,h[l]=m,u.i=l+1&7,m};function c(h,l){var f,m=[];if(l===(l|0))m[0]=l;else for(l=""+l,f=0;f<l.length;++f)m[f&7]=m[f&7]<<15^l.charCodeAt(f)+m[f+1&7]<<13;for(;m.length<8;)m.push(0);for(f=0;f<8&&m[f]===0;++f);for(f==8?m[7]=-1:m[f],h.x=m,h.i=0,f=256;f>0;--f)h.next()}c(u,i)}function a(i,u){return u.x=i.x.slice(),u.i=i.i,u}function o(i,u){i==null&&(i=+new Date);var c=new r(i),h=u&&u.state,l=function(){return(c.next()>>>0)/4294967296};return l.double=function(){do var f=c.next()>>>11,m=(c.next()>>>0)/4294967296,b=(f+m)/(1<<21);while(b===0);return b},l.int32=c.next,l.quick=l,h&&(h.x&&a(h,c),l.state=function(){return a(c,{})}),l}n&&n.exports?n.exports=o:this.xorshift7=o})(Yy,t)}(Bn)),Bn.exports}var Pn={exports:{}},eb=Pn.exports,Da;function tb(){return Da||(Da=1,function(t){(function(e,n,s){function r(i){var u=this;u.next=function(){var h=u.w,l=u.X,f=u.i,m,b;return u.w=h=h+1640531527|0,b=l[f+34&127],m=l[f=f+1&127],b^=b<<13,m^=m<<17,b^=b>>>15,m^=m>>>12,b=l[f]=b^m,u.i=f,b+(h^h>>>16)|0};function c(h,l){var f,m,b,T,S,$=[],O=128;for(l===(l|0)?(m=l,l=null):(l=l+"\0",m=0,O=Math.max(O,l.length)),b=0,T=-32;T<O;++T)l&&(m^=l.charCodeAt((T+32)%l.length)),T===0&&(S=m),m^=m<<10,m^=m>>>15,m^=m<<4,m^=m>>>13,T>=0&&(S=S+1640531527|0,f=$[T&127]^=m+S,b=f==0?b+1:0);for(b>=128&&($[(l&&l.length||0)&127]=-1),b=127,T=4*128;T>0;--T)m=$[b+34&127],f=$[b=b+1&127],m^=m<<13,f^=f<<17,m^=m>>>15,f^=f>>>12,$[b]=m^f;h.w=S,h.X=$,h.i=b}c(u,i)}function a(i,u){return u.i=i.i,u.w=i.w,u.X=i.X.slice(),u}function o(i,u){i==null&&(i=+new Date);var c=new r(i),h=u&&u.state,l=function(){return(c.next()>>>0)/4294967296};return l.double=function(){do var f=c.next()>>>11,m=(c.next()>>>0)/4294967296,b=(f+m)/(1<<21);while(b===0);return b},l.int32=c.next,l.quick=l,h&&(h.X&&a(h,c),l.state=function(){return a(c,{})}),l}n&&n.exports?n.exports=o:this.xor4096=o})(eb,t)}(Pn)),Pn.exports}var zn={exports:{}},nb=zn.exports,Fa;function sb(){return Fa||(Fa=1,function(t){(function(e,n,s){function r(i){var u=this,c="";u.next=function(){var l=u.b,f=u.c,m=u.d,b=u.a;return l=l<<25^l>>>7^f,f=f-m|0,m=m<<24^m>>>8^b,b=b-l|0,u.b=l=l<<20^l>>>12^f,u.c=f=f-m|0,u.d=m<<16^f>>>16^b,u.a=b-l|0},u.a=0,u.b=0,u.c=-1640531527,u.d=1367130551,i===Math.floor(i)?(u.a=i/4294967296|0,u.b=i|0):c+=i;for(var h=0;h<c.length+20;h++)u.b^=c.charCodeAt(h)|0,u.next()}function a(i,u){return u.a=i.a,u.b=i.b,u.c=i.c,u.d=i.d,u}function o(i,u){var c=new r(i),h=u&&u.state,l=function(){return(c.next()>>>0)/4294967296};return l.double=function(){do var f=c.next()>>>11,m=(c.next()>>>0)/4294967296,b=(f+m)/(1<<21);while(b===0);return b},l.int32=c.next,l.quick=l,h&&(typeof h=="object"&&a(h,c),l.state=function(){return a(c,{})}),l}n&&n.exports?n.exports=o:this.tychei=o})(nb,t)}(zn)),zn.exports}var Vn={exports:{}};const rb={},ab=Object.freeze(Object.defineProperty({__proto__:null,default:rb},Symbol.toStringTag,{value:"Module"})),ob=Ip(ab);var ib=Vn.exports,Ca;function ub(){return Ca||(Ca=1,function(t){(function(e,n,s){var r=256,a=6,o=52,i="random",u=s.pow(r,a),c=s.pow(2,o),h=c*2,l=r-1,f;function m(_,A,F){var L=[];A=A==!0?{entropy:!0}:A||{};var C=$(S(A.entropy?[_,v(n)]:_??O(),3),L),k=new b(L),E=function(){for(var y=k.g(a),x=u,R=0;y<c;)y=(y+R)*r,x*=r,R=k.g(1);for(;y>=h;)y/=2,x/=2,R>>>=1;return(y+R)/x};return E.int32=function(){return k.g(4)|0},E.quick=function(){return k.g(4)/4294967296},E.double=E,$(v(k.S),n),(A.pass||F||function(y,x,R,z){return z&&(z.S&&T(z,k),y.state=function(){return T(k,{})}),R?(s[i]=y,x):y})(E,C,"global"in A?A.global:this==s,A.state)}function b(_){var A,F=_.length,L=this,C=0,k=L.i=L.j=0,E=L.S=[];for(F||(_=[F++]);C<r;)E[C]=C++;for(C=0;C<r;C++)E[C]=E[k=l&k+_[C%F]+(A=E[C])],E[k]=A;(L.g=function(y){for(var x,R=0,z=L.i,V=L.j,U=L.S;y--;)x=U[z=l&z+1],R=R*r+U[l&(U[z]=U[V=l&V+x])+(U[V]=x)];return L.i=z,L.j=V,R})(r)}function T(_,A){return A.i=_.i,A.j=_.j,A.S=_.S.slice(),A}function S(_,A){var F=[],L=typeof _,C;if(A&&L=="object")for(C in _)try{F.push(S(_[C],A-1))}catch{}return F.length?F:L=="string"?_:_+"\0"}function $(_,A){for(var F=_+"",L,C=0;C<F.length;)A[l&C]=l&(L^=A[l&C]*19)+F.charCodeAt(C++);return v(A)}function O(){try{var _;return f&&(_=f.randomBytes)?_=_(r):(_=new Uint8Array(r),(e.crypto||e.msCrypto).getRandomValues(_)),v(_)}catch{var A=e.navigator,F=A&&A.plugins;return[+new Date,e,F,e.screen,v(n)]}}function v(_){return String.fromCharCode.apply(0,_)}if($(s.random(),n),t.exports){t.exports=m;try{f=ob}catch{}}else s["seed"+i]=m})(typeof self<"u"?self:ib,[],Math)}(Vn)),Vn.exports}var ks,Ra;function cb(){if(Ra)return ks;Ra=1;var t=Hy(),e=Xy(),n=Jy(),s=Qy(),r=tb(),a=sb(),o=ub();return o.alea=t,o.xor128=e,o.xorwow=n,o.xorshift7=s,o.xor4096=r,o.tychei=a,ks=o,ks}var Gr=cb();/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const lb=.001,nh=.1;function hb(t,e,n){return n==null&&(n=Hr()),qs(t,e,(s,r)=>Kr(s,r,n))}function Hr(){return N.backend.floatPrecision()===32?lb:nh}function qs(t,e,n){let s=!0;if((ie(t)||ie(e))&&(s=!1),ie(t)&&ie(e)&&(s=!0),s){const o=t.constructor.name,i=e.constructor.name;if(o!==i)throw new Error(`Arrays are of different type. Actual: ${o}. Expected: ${i}`)}if(Array.isArray(t)&&Array.isArray(e)){const o=Be(t),i=Be(e);if(!Ce(o,i))throw new Error(`Arrays have different shapes. Actual: [${o}]. Expected: [${i}]`)}const r=ie(t)?t:at(t),a=ie(e)?e:at(e);if(r.length!==a.length)throw new Error(`Arrays have different lengths actual: ${r.length} vs expected: ${a.length}.
Actual:   ${r}.
Expected: ${a}.`);for(let o=0;o<a.length;++o){const i=r[o],u=a[o];if(!n(i,u))throw new Error(`Arrays differ: actual[${o}] = ${i}, expected[${o}] = ${u}.
Actual:   ${r}.
Expected: ${a}.`)}typeof expect<"u"&&expect().nothing()}function pb(t,e){t().then(()=>e.fail(),()=>e()),typeof expect<"u"&&expect().nothing()}function fb(t,e){const n=typeof e=="string"||typeof e=="number"||typeof e=="boolean"?[e]:e;return Qe(t)||Qe(t[0])||Qe(e)||Qe(e[0])?qs(t,n,(s,r)=>s==r):qs(t,e,(s,r)=>Kr(s,r,0))}function db(t,e,n){if(n==null&&(n=Hr()),!Kr(t,e,n))throw new Error(`Numbers differ: actual === ${t}, expected === ${e}`);typeof expect<"u"&&expect().nothing()}function Kr(t,e,n){return!isFinite(t)&&!isFinite(e)?!0:!(isNaN(t)||isNaN(e)||Math.abs(t-e)>n)}function mb(t,e,n){for(let s=0;s<t.length;s++)if(t[s]<e||t[s]>n)throw new Error(`Value out of range:${t[s]} low: ${e}, high: ${n}`)}function gb(t,e){const n=new Float32Array(t),s=new Float32Array(e);if(n.length!==s.length)throw new Error(`Expected ArrayBuffer to be of length ${s.length}, but it was ${n.length}`);for(let r=0;r<s.length;r++)if(n[r]!==s[r])throw new Error(`Expected ArrayBuffer value at ${r} to be ${s[r]} but got ${n[r]} instead`)}function sh(t){for(let e=0;e<t.length;e++){const n=t[e];Array.isArray(n)?sh(n):t[e]=yn(n)}return t}function yb(t){const e=document.createElement("video");return"playsInline"in e&&(e.playsInline=!0),e.muted=!0,e.loop=!0,e.style.position="fixed",e.style.left="0px",e.style.top="0px",e.preload="auto",e.appendChild(t),new Promise(n=>{e.addEventListener("loadeddata",s=>n(e)),e.load()})}async function bb(t){await t.play(),"requestVideoFrameCallback"in t&&await new Promise(e=>{t.requestVideoFrameCallback(e)})}const wb=Object.freeze(Object.defineProperty({__proto__:null,TEST_EPSILON_FLOAT16:nh,createVideoElement:yb,encodeStrings:sh,expectArrayBuffersEqual:gb,expectArraysClose:hb,expectArraysEqual:fb,expectNumbersClose:db,expectPromiseToFail:pb,expectValuesInRange:mb,play:bb,testEpsilon:Hr},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class Xr{constructor(e,n,s,r,a){this.mean=e,this.stdDev=n,this.dtype=s,this.nextVal=NaN,this.truncated=r,this.truncated&&(this.upper=this.mean+this.stdDev*2,this.lower=this.mean-this.stdDev*2);const o=a||Math.random();this.random=Gr.alea(o.toString())}nextValue(){if(!isNaN(this.nextVal)){const r=this.nextVal;return this.nextVal=NaN,r}let e,n,s=!1;for(;!s;){let r,a,o;do r=2*this.random()-1,a=2*this.random()-1,o=r*r+a*a;while(o>=1||o===0);const i=Math.sqrt(-2*Math.log(o)/o);e=this.mean+this.stdDev*r*i,n=this.mean+this.stdDev*a*i,(!this.truncated||this.isValidTruncated(e))&&(s=!0)}return(!this.truncated||this.isValidTruncated(n))&&(this.nextVal=this.convertValue(n)),this.convertValue(e)}convertValue(e){return this.dtype==null||this.dtype==="float32"?e:Math.round(e)}isValidTruncated(e){return e<=this.upper&&e>=this.lower}}class Nb{constructor(e,n,s,r){this.alpha=e,this.beta=1/n,this.dtype=s;const a=r||Math.random();this.randu=Gr.alea(a.toString()),this.randn=new Xr(0,1,s,!1,this.randu()),e<1?this.d=e+2/3:this.d=e-1/3,this.c=1/Math.sqrt(9*this.d)}nextValue(){let e,n,s,r,a,o;for(;;){do r=this.randn.nextValue(),o=1+this.c*r;while(o<=0);if(o*=o*o,e=r*r,n=1-.331*e*e,s=.5*e+this.d*(1-o+Math.log(o)),a=this.randu(),a<n||Math.log(a)<s)break}return o=1/this.beta*this.d*o,this.alpha<1&&(o*=Math.pow(this.randu(),1/this.alpha)),this.convertValue(o)}convertValue(e){return this.dtype==="float32"?e:Math.round(e)}}class Sb{constructor(e=0,n=1,s,r){if(this.canReturnFloat=()=>this.dtype==null||this.dtype==="float32",this.min=e,this.range=n-e,this.dtype=s,r==null&&(r=Math.random()),typeof r=="number"&&(r=r.toString()),!this.canReturnFloat()&&this.range<=1)throw new Error(`The difference between ${e} - ${n} <= 1 and dtype is not float`);this.random=Gr.alea(r)}convertValue(e){return this.canReturnFloat()?e:Math.round(e)}nextValue(){return this.convertValue(this.min+this.range*this.random())}}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Tb(t,e,n=1,s="float32",r){if($e(t),n==null&&(n=1),s==null&&(s="float32"),s!=="float32"&&s!=="int32")throw new Error(`Unsupported data type ${s}`);const a=new Nb(e,n,s,r),o=Pe(t,s);for(let i=0;i<o.values.length;i++)o.values[i]=a.nextValue();return o.toTensor()}const rh=w({randomGamma_:Tb});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function $b(t,e=0,n=1,s,r){if($e(t),s!=null&&s==="bool")throw new Error(`Unsupported data type ${s}`);const a=new Xr(e,n,s,!1,r),o=Pe(t,s);for(let i=0;i<o.values.length;i++)o.values[i]=a.nextValue();return o.toTensor()}const Zr=w({randomNormal_:$b});/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Eb(t,e,n){if(e!=null&&e==="bool")throw new Error(`Unsupported data type ${e}`);return Zr(t,0,1,e,n)}const ah=w({randomStandardNormal_:Eb});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function kb(t,e=0,n=1,s="float32",r){$e(t);const a=Pe(t,s),o=new Sb(e,n,null,r);for(let i=0;i<a.values.length;i++)a.values[i]=o.nextValue();return a.toTensor()}const cs=w({randomUniform_:kb});/**
 * @license
 * Copyright 2023 Google LLC.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function vb(t,e,n,s){return cs(t,e,n,"int32",s)}const oh=w({randomUniformInt_:vb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Vt(t,e,n=1,s="float32"){if(n===0)throw new Error("Cannot have a step of zero");const r={start:t,stop:e,step:n,dtype:s};return N.runKernel(iu,{},r)}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function _b(t){const n={input:d(t,"input","real")};return N.runKernel(uu,n)}const Wt=w({real_:_b});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ib(t){const n={x:d(t,"x","reciprocal")};return N.runKernel(cu,n)}const ih=w({reciprocal_:Ib});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function xb(t){const n={x:d(t,"x","relu")};return N.runKernel(lu,n)}const vn=w({relu_:xb});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ab(t){const n={x:d(t,"x","relu6")};return N.runKernel(du,n)}const Jr=w({relu6_:Ab});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ob(t,e){const s={x:d(t,"x","reverse")},r={dims:e};return N.runKernel(mu,s,r)}const ut=w({reverse_:Ob});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Db(t){const e=d(t,"x","reverse");return g(e.rank===1,()=>`Error in reverse1D: x must be rank 1 but got rank ${e.rank}.`),ut(e,0)}const uh=w({reverse1d_:Db});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Fb(t,e){const n=d(t,"x","reverse");return g(n.rank===2,()=>`Error in reverse2D: x must be rank 2 but got rank ${n.rank}.`),ut(n,e)}const ch=w({reverse2d_:Fb});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Cb(t,e){const n=d(t,"x","reverse");return g(n.rank===3,()=>`Error in reverse3D: x must be rank 3 but got rank ${n.rank}.`),ut(n,e)}const lh=w({reverse3d_:Cb});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Rb(t,e){const n=d(t,"x","reverse");return g(n.rank===4,()=>`Error in reverse4D: x must be rank 4 but got rank ${n.rank}.`),ut(n,e)}const hh=w({reverse4d_:Rb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Lb(t){const n={x:d(t,"x","round")};return N.runKernel(gu,n)}const Yr=w({round_:Lb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Bb(t){const n={x:d(t,"x","rsqrt","float32")};return N.runKernel(yu,n)}const ph=w({rsqrt_:Bb});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Pb(t){const n={x:d(t,"x","selu")};return N.runKernel(Tu,n)}const fh=w({selu_:Pb});function zb(t,e,n,s,r,a=[1,1],o="NHWC"){const i=d(t,"x","separableConv2d"),u=d(e,"depthwiseFilter","separableConv2d"),c=d(n,"pointwiseFilter","separableConv2d");let h=i,l=!1;if(i.rank===3&&(l=!0,h=I(i,[1,i.shape[0],i.shape[1],i.shape[2]])),o==="NCHW")throw new Error("separableConv2d currently does not support dataFormat NCHW; only NHWC is supported");g(h.rank===4,()=>`Error in separableConv2d: input must be rank 4, but got rank ${h.rank}.`),g(u.rank===4,()=>`Error in separableConv2d: depthwise filter must be rank 4, but got rank ${u.rank}.`),g(c.rank===4,()=>`Error in separableConv2d: pointwise filter must be rank 4, but got rank ${u.rank}.`),g(c.shape[0]===1,()=>`Error in separableConv2d: the first dimension of pointwise filter  must be 1, but got ${c.shape[0]}.`),g(c.shape[1]===1,()=>`Error in separableConv2d: the second dimension of pointwise filter must be 1, but got ${c.shape[1]}.`);const f=u.shape[2],m=u.shape[3];g(c.shape[2]===f*m,()=>`Error in separableConv2d: the third dimension of pointwise filter must be ${f*m}, but got ${c.shape[2]}.`);const b=as(h,u,s,r,o,a),S=Sn(b,c,1,"valid",o);return l?I(S,[S.shape[1],S.shape[2],S.shape[3]]):S}const dh=w({separableConv2d_:zb});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */async function Vb(t,e){const n=d(t,"x","setdiff1d"),s=d(e,"y","setdiff1d");g(n.dtype===s.dtype,()=>`x and y should have the same dtype, but got x (${n.dtype}) and y (${s.dtype}).`),g(n.rank===1,()=>`x should be 1D tensor, but got x (${n.shape}).`),g(s.rank===1,()=>`y should be 1D tensor, but got y (${s.shape}).`);const r=await n.data(),a=await s.data(),o=new Set(a);let i=0;for(let h=0;h<r.length;h++)o.has(r[h])||i++;const u=new Hn([i],n.dtype),c=new Hn([i],"int32");for(let h=0,l=0;h<r.length;h++)o.has(r[h])||(u.values[l]=r[h],c.values[l]=h,l++);return[u.toTensor(),c.toTensor()]}const mh=Vb;/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Wb(t){const n={x:d(t,"x","sign")};return N.runKernel(vu,n)}const gh=w({sign_:Wb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Mb(t){const n={x:d(t,"x","sin","float32")};return N.runKernel(Eu,n)}const yh=w({sin_:Mb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ub(t){const n={x:d(t,"x","sinh")};return N.runKernel(ku,n)}const bh=w({sinh_:Ub});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function jb(t,e,n){const s=d(t,"x","slice1d");return g(s.rank===1,()=>`slice1d expects a rank-1 tensor, but got a rank-${s.rank} tensor`),H(s,[e],[n])}const wh=w({slice1d_:jb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function qb(t,e,n){const s=d(t,"x","slice2d");return g(s.rank===2,()=>`slice2d expects a rank-2 tensor, but got a rank-${s.rank} tensor`),H(s,e,n)}const Nh=w({slice2d_:qb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Gb(t,e,n){const s=d(t,"x","slice3d");return g(s.rank===3,()=>`slice3d expects a rank-3 tensor, but got a rank-${s.rank} tensor`),H(s,e,n)}const Sh=w({slice3d_:Gb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Hb(t,e,n){const s=d(t,"x","slice4d");return g(s.rank===4,()=>`slice4d expects a rank-4 tensor, but got a rank-${s.rank} tensor`),H(s,e,n)}const Th=w({slice4d_:Hb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Kb(t,e=-1){const n=d(t,"logits","softmax","float32");if(e===-1&&(e=n.rank-1),e!==n.rank-1)throw Error(`Softmax along a non-last dimension is not yet supported. Logits was rank ${n.rank} and dim was ${e}`);const s={logits:n},r={dim:e};return N.runKernel(Fu,s,r)}const $h=w({softmax_:Kb});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Xb(t){g(t.dtype==="complex64",()=>`The dtype for tf.spectral.fft() must be complex64 but got ${t.dtype}.`);const e={input:t};return N.runKernel(ci,e)}const ls=w({fft_:Xb});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Zb(t){g(t.dtype==="complex64",()=>`The dtype for tf.spectral.ifft() must be complex64 but got ${t.dtype}.`);const e={input:t};return N.runKernel(wi,e)}const pn=w({ifft_:Zb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Jb(t){const e=t.shape[t.shape.length-1],n=t.size/e;let s;if(e<=2){const r=I(t,[n,e]);s=pn(r)}else{const r=[n,2*(e-1)],a=I(Wt(t),[n,e]),o=I(kn(t),[n,e]),i=ut(H(a,[0,1],[n,e-2]),1),u=D(ut(H(o,[0,1],[n,e-2]),1),M(-1)),c=he([a,i],1),h=he([o,u],1),l=I(Ke(c,h),[r[0],r[1]]);s=pn(l)}if(s=Wt(s),t.rank===3&&t.shape[0]!==0){const r=s,a=t.shape[0];s=I(s,[a,s.shape[0]/a,s.shape[1]]),r.dispose()}return s}const Qr=w({irfft_:Jb});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Yb(t,e,n=0){const r={x:d(t,"x","split")},a={numOrSizeSplits:e,axis:n};return N.runKernel(Du,r,a)}const Mt=w({split_:Yb});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Qb(t,e){g(t.dtype==="float32",()=>`The dtype for rfft() must be real value but got ${t.dtype}`);let n=t.shape[t.shape.length-1];const s=t.size/n;let r;if(e!=null&&e<n){const b=t.shape.map(S=>0),T=t.shape.map(S=>S);T[t.shape.length-1]=e,r=H(t,b,T),n=e}else if(e!=null&&e>n){const b=t.shape.map(T=>T);b[t.shape.length-1]=e-n,r=he([t,kt(b)],t.shape.length-1),n=e}else r=t;const a=Te(r),o=I(Ke(r,a),[s,n]),i=ls(o),u=Math.floor(n/2)+1,c=Wt(i),h=kn(i),l=Mt(c,[u,n-u],c.shape.length-1),f=Mt(h,[u,n-u],h.shape.length-1),m=r.shape.slice();return m[r.shape.length-1]=u,I(Ke(l[0],f[0]),m)}const hs=w({rfft_:Qb});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function e0(t,e){let n=d(t,"a","squaredDifference"),s=d(e,"b","squaredDifference");[n,s]=ee(n,s),re(n.shape,s.shape);const r={a:n,b:s},a={};return N.runKernel(zu,r,a)}const ea=w({squaredDifference_:e0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function t0(t,e){const n=d(t,"x","squeeze","string_or_numeric");return I(n,no(n.shape,e).newShape)}const ps=w({squeeze_:t0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function n0(t,e=0){const n=rn(t,"tensors","stack","string_or_numeric");g(n.length>=1,()=>"Pass at least one tensor to tf.stack"),n.length>0&&g(e<=n[0].rank,()=>"Axis must be <= rank of the tensor");const s=n,r={axis:e};return N.runKernel(Qi,s,r)}const We=w({stack_:n0});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function s0(t,e=0){const s={x:d(t,"x","step")},r={alpha:e};return N.runKernel(ec,s,r)}const ta=w({step_:s0});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function r0(t,e,n,s,r=0,a=0,o=0,i=0,u=0){const h={x:d(t,"x","stridedSlice","string_or_numeric")},l={begin:e,end:n,strides:s,beginMask:r,endMask:a,ellipsisMask:o,newAxisMask:i,shrinkAxisMask:u};return N.runKernel(Wu,h,l)}const Eh=w({stridedSlice_:r0});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function a0(t){const n={x:d(t,"x","tan","float32")};return N.runKernel(Gu,n)}const kh=w({tan_:a0});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ke(t,e){It(t);const n=Be(t,e);if(n.length!==1)throw new Error("tensor1d() requires values to be a flat/TypedArray");return ct(t,null,n,e)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ct(t,e,n){if(It(t),e!=null&&e.length!==2)throw new Error("tensor2d() requires shape to have two numbers");const s=Be(t,n);if(s.length!==2&&s.length!==1)throw new Error("tensor2d() requires values to be number[][] or flat/TypedArray");if(s.length===1&&e==null)throw new Error("tensor2d() requires shape to be provided when `values` are a flat/TypedArray");return ct(t,e,s,n)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function na(t,e,n){if(It(t),e!=null&&e.length!==3)throw new Error("tensor3d() requires shape to have three numbers");const s=Be(t,n);if(s.length!==3&&s.length!==1)throw new Error("tensor3d() requires values to be number[][][] or flat/TypedArray");if(s.length===1&&e==null)throw new Error("tensor3d() requires shape to be provided when `values` are a flat array");return ct(t,e,s,n)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function vh(t,e,n){if(It(t),e!=null&&e.length!==4)throw new Error("tensor4d() requires shape to have four numbers");const s=Be(t,n);if(s.length!==4&&s.length!==1)throw new Error("tensor4d() requires values to be number[][][][] or flat/TypedArray");if(s.length===1&&e==null)throw new Error("tensor4d() requires shape to be provided when `values` are a flat array");return ct(t,e,s,n)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function _h(t,e,n){if(It(t),e!=null&&e.length!==5)throw new Error("tensor5d() requires shape to have five numbers");const s=Be(t,n);if(s.length!==5&&s.length!==1)throw new Error("tensor5d() requires values to be number[][][][][] or flat/TypedArray");if(s.length===1&&e==null)throw new Error("tensor5d() requires shape to be provided when `values` are a flat array");return ct(t,e,s,n)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ih(t,e,n){if(It(t),e!=null&&e.length!==6)throw new Error("tensor6d() requires shape to have six numbers");const s=Be(t,n);if(s.length!==6&&s.length!==1)throw new Error("tensor6d() requires values to be number[][][][][][] or flat/TypedArray");if(s.length===1&&e==null)throw new Error("tensor6d() requires shape to be provided when `values` are a flat array");return e=e||s,ct(t,e,s,n)}function sa(t,e,n){const s=e.rank>1?e.shape[e.rank-1]:1,r=e.rank>1?e.rank-1:1,a=`Must have updates.shape = indices.shape[:batchDim] + shape[sliceDim:], got updates.shape: ${n.shape}, indices.shape: ${e.shape}, shape: ${t}, sliceDim: ${s}, and batchDim: ${r}.`;if(n.rank<r)throw new Error(a+` update.rank < ${r}. `);if(t.length<s+(n.rank-r))throw new Error(a+` Output shape length < ${s+(n.rank-r)}`);if(n.rank!==r+t.length-s)throw new Error(a+` update.rank != ${r+t.length-s}`);for(let o=0;o<r;++o)if(n.shape[o]!==e.shape[o])throw new Error(a+` updates.shape[${o}] (${n.shape[o]}) != indices.shape[${o}] (${e.shape[o]}).`);for(let o=0;o<n.rank-r;++o)if(n.shape[o+r]!==t[o+s])throw new Error(a+` updates.shape[${o+r}] (${n.shape[o+r]}) != shape[${o+r}] (${t[o+r]})`)}function fs(t,e,n){if(e.rank<1)throw new Error(`tf.scatterND() expects the indices to be rank 1 or higher, but the rank was ${e.rank}.`);if(t.rank<1)throw new Error(`tf.scatterND() expects the updates to be rank 1 or higher, but the rank was ${t.rank}.`);if(e.dtype!=="int32")throw new Error(`The dtype of 'indices' should be int32, but got dtype: ${e.dtype}`);if(n.length<1)throw new Error(`Output rank must be greater or equal to 1, but got shape: ${n}`);if(n.length===0){if(e.size===0)throw new Error(`Indices specified for empty output. indices shape: ${e.shape}`);if(t.size===0)throw new Error(`Updates specified for empty output. updates shape: ${t.shape}`)}sa(n,e,t)}function xh(t,e,n){const s=e.shape.length,r=s>1?e.shape[s-1]:1,a=n.length;let o=1;for(let l=r;l<a;++l)o*=n[l];const i=r<1?1:r,u=G(e.shape)/i,c=[...Ut(n.slice(0,r)),1],h=G(n);return{sliceRank:r,numUpdates:u,sliceSize:o,strides:c,outputSize:h}}const o0=Object.freeze(Object.defineProperty({__proto__:null,calculateShapes:xh,validateInput:fs,validateUpdateShape:sa},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function i0(t,e,n){const s=d(t,"tensor","tensorScatterupdate"),r=d(e,"indices","tensorScatterupdate","int32"),a=d(n,"updates","tensorScatterupdate");if(fs(a,r,s.shape),s.dtype!==a.dtype)throw new Error(`tensor and updates must have the same dtype, instead they are ${s.dtype} and ${a.dtype}.`);const o={tensor:s,indices:r,updates:a},i={};return N.runKernel(wu,o,i)}const Ah=w({tensorScatterUpdate_:i0});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function u0(t,e=1,n=!0){const s=d(t,"x","topk");if(s.rank===0)throw new Error("topk() expects the input to be of rank 1 or higher");const r=s.shape[s.shape.length-1];if(e<0)throw new Error(`'k' passed to topk() must be >= 0 but got ${e}`);if(e>r)throw new Error(`'k' passed to topk() must be <= the last dimension (${r}) but got ${e}`);const a={x:s},o={k:e,sorted:n},[i,u]=N.runKernel(Ku,a,o);return{values:i,indices:u}}const Oh=w({topk_:u0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function c0(t,e=0,n=1,s,r){if($e(t),s!=null&&s==="bool")throw new Error("Unsupported data type $ { dtype }");const a=new Xr(e,n,s,!0,r),o=Pe(t,s);for(let i=0;i<o.values.length;i++)o.values[i]=a.nextValue();return o.toTensor()}const Dh=w({truncatedNormal_:c0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function l0(t,e=0){const n=d(t,"x","unique","string_or_numeric");g(n.rank>0,()=>"The input tensor must be at least 1D");const s={x:n},r={axis:e},[a,o]=N.runKernel(Zu,s,r);return{values:a,indices:o}}const Fh=w({unique_:l0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function h0(t,e,n){const s=d(t,"x","unsortedSegmentSum"),r=d(e,"segmentIds","unsortedSegmentSum","int32");g(Rt(n),()=>"numSegments must be of dtype int");const a={x:s,segmentIds:r},o={numSegments:n};return N.runKernel(Yu,a,o)}const Ch=w({unsortedSegmentSum_:h0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function p0(t,e=0){const n=d(t,"x","unstack","string_or_numeric");g(e>=-n.shape.length&&e<n.shape.length,()=>`Axis = ${e} is not in [-${n.shape.length}, ${n.shape.length})`);const s={value:n},r={axis:e};return N.runKernel(Ju,s,r)}const lt=w({unstack_:p0});/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Rh(t,e){return us(t,e,"right")}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Lh(t,e=!0,n,s){return N.makeVariable(t,e,n,s)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Bh(t,e){const n=[];for(let a=0;a<e.length;a++)e[a]&&n.push(a);const s=Pe(t,"int32"),r=Pe([n.length,t.length],"int32");for(let a=0;a<n.length;a++){const o=s.indexToLoc(n[a]),i=a*t.length;r.values.set(o,i)}return r.toTensor()}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */async function f0(t){const e=d(t,"condition","whereAsync","bool"),n=await e.data(),s=Bh(e.shape,n);return t!==e&&e.dispose(),s}const ra=f0;/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */async function d0(t,e,n){const s=d(t,"tensor","boolMask"),r=d(e,"mask","boolMask","bool"),a=n??0,o=r.rank,i=s.shape;g(o>0,()=>"mask cannot be scalar"),ge(i.slice(a,a+o),r.shape,"mask's shape must match the first K dimensions of tensor's shape,");let u=1;for(let T=a;T<a+o;T++)u*=i[T];const c=i.slice(0,a).concat([u],i.slice(a+o)),h=I(s,c),l=I(r,[-1]),f=await ra(l),m=ps(f,[1]),b=Fr(h,m,a);return t!==s&&s.dispose(),e!==r&&r.dispose(),m.dispose(),h.dispose(),l.dispose(),f.dispose(),b}const Ph=d0;/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function m0(t,e,n){const s=d(t,"x","transpose");if(e==null&&(e=s.shape.map((o,i)=>i).reverse()),g(s.rank===e.length,()=>`Error in transpose: rank of input ${s.rank} must match length of perm ${e}.`),e.forEach(o=>{g(o>=0&&o<s.rank,()=>`All entries in 'perm' must be between 0 and ${s.rank-1} but got ${e}`)}),s.rank<=1)return s.clone();const r={x:s},a={perm:e};return s.dtype==="complex64"?q(()=>{let o=Wt(s),i=kn(s);return o=N.runKernel(On,{x:o},a),i=N.runKernel(On,{x:i},a),n&&(i=Fe(i)),Ke(o,i)}):N.runKernel(On,r,a)}const fn=w({transpose_:m0});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function g0(t,e,n,s,r=!0){const a=d(t,"v","movingAverage"),o=d(e,"x","movingAverage"),i=d(n,"decay","movingAverage");pc(a,o),g(Ce(a.shape,o.shape),()=>"Shape mismatch in v and x");const u=M(1),c=W(u,i);let h=D(W(o,a),c);if(r){g(s!=null,()=>"When using zeroDebias: true, step is required.");const l=d(s,"step","movingAverage");h=Z(h,W(u,Pt(i,l)))}return B(a,h)}const zh=w({movingAverage_:g0});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function y0(t,e,n){$e(n);const s=d(t,"indices","scatterND","int32"),r=d(e,"updates","scatterND");fs(r,s,n);const a={indices:s,updates:r},o={shape:n};return N.runKernel(bu,a,o)}const Vh=w({scatterND_:y0});function b0(t,e,n,s){if(t.dtype!=="int32")throw new Error(`tf.sparseToDense() expects the indices to be int32 type, but the dtype was ${t.dtype}.`);if(t.rank>2)throw new Error(`sparseIndices should be a scalar, vector, or matrix, but got shape ${t.shape}.`);const r=t.rank>0?t.shape[0]:1,a=t.rank>1?t.shape[1]:1;if(n.length!==a)throw new Error(`outputShape has incorrect number of elements:, ${n.length}, should be: ${a}.`);const o=e.size;if(!(e.rank===0||e.rank===1&&o===r))throw new Error(`sparseValues has incorrect shape ${e.shape}, should be [] or [${r}]`);if(e.dtype!==s.dtype)throw new Error("sparseValues.dtype must match defaultValues.dtype")}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function w0(t,e,n,s=0){$e(n);const r=d(t,"sparseIndices","sparseToDense","int32"),a=d(e,"sparseValues","sparseToDense","string_or_numeric"),o=d(s,"defaultValue","sparseToDense",a.dtype);b0(r,a,n,o);const i={sparseIndices:r,sparseValues:a,defaultValue:o},u={outputShape:n};return N.runKernel(Pu,i,u)}const Wh=w({sparseToDense_:w0});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function N0(t,e){const n=d(e,"indices","gatherND","int32"),r={params:d(t,"x","gatherND","string_or_numeric"),indices:n};return N.runKernel(gi,r)}const Mh=w({gatherND_:N0});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function S0(t,e){if(e==null)return t.shape.slice();if(Ce(t.shape,e))return e;if(t.shape.length===e.length){const n=[];for(let s=0;s<t.shape.length;s++)e[s]==null&&t.shape[s]!=null?n.push(t.shape[s]):n.push(e[s]);return n}return e}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function T0(t,e,n,s){const r=d(t,"x","dropout");if(g(r.dtype==="float32",()=>`x has to be a floating point tensor since it's going to be scaled, but got a ${r.dtype} tensor instead.`),g(e>=0&&e<1,()=>`rate must be a float in the range [0, 1), but got ${e}.`),e===0)return t instanceof ne?r.clone():r;const a=S0(r,n),o=1-e,i=Z(Dr(B(cs(a,0,1,"float32",s),o)),o);return D(r,i)}const Uh=w({dropout_:T0});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function aa(t){return Math.floor(Math.pow(2,Math.ceil(Math.log(t)/Math.log(2))))}function ds(t,e,n){const s=1-t%2,r=new Float32Array(t);for(let a=0;a<t;++a){const o=2*Math.PI*a/(t+s-1);r[a]=e-n*Math.cos(o)}return ke(r,"float32")}/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */async function $0(t,e,n=1){const s=d(t,"predictions","inTopK"),r=d(e,"targets","inTopK");g(s.rank>1,()=>`inTopK() expects the predictions to be of rank 2 or higher, but got ${s.rank}`),g(s.rank-1===r.rank,()=>`predictions rank should be 1 larger than targets rank, but got predictions rank ${s.rank} and targets rank ${r.rank}`),ge(s.shape.slice(0,s.shape.length-1),r.shape,"predictions's shape should be align with the targets' shape, except the last dimension.");const a=s.shape[s.shape.length-1];g(n>0&&n<=a,()=>`'k' passed to inTopK() must be > 0 && <= the predictions last dimension (${a}), but got ${n}`);const o=await s.data(),i=await r.data(),[u,c]=[o.length/a,a],h=so("bool",u);for(let l=0;l<u;l++){const f=l*c,m=o.subarray(f,f+c),b=[];for(let T=0;T<m.length;T++)b.push({value:m[T],index:T});b.sort((T,S)=>S.value-T.value),h[l]=0;for(let T=0;T<n;T++)if(b[T].index===i[l]){h[l]=1;break}}return t!==s&&s.dispose(),e!==r&&r.dispose(),De(h,r.shape,"bool")}const jh=$0;/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function E0(t,e,n,s,r,a="NHWC",o){let i=t;t.rank===3&&(i=I(t,[1,t.shape[0],t.shape[1],t.shape[2]]));let u=e;u.rank===3&&(u=I(e,[1,e.shape[0],e.shape[1],e.shape[2]])),g(i.rank===4,()=>`Error in conv2dDerFilter: input must be rank 4, but got shape ${i.shape}.`),g(u.rank===4,()=>`Error in conv2dDerFilter: dy must be rank 4, but got shape ${u.shape}.`),g(n.length===4,()=>`Error in conv2dDerFilter: filterShape must be length 4, but got ${n}.`);const c=a==="NHWC"?i.shape[3]:i.shape[1],h=a==="NHWC"?u.shape[3]:u.shape[1];g(c===n[2],()=>`Error in conv2dDerFilter: depth of input ${c}) must match input depth in filter (${n[2]}.`),g(h===n[3],()=>`Error in conv2dDerFilter: depth of dy (${h}) must match output depth for filter (${n[3]}).`),xe("conv2dDerFilter",r,o);const l={x:i,dy:u},f={strides:s,pad:r,dataFormat:a,dimRoundingMode:o,filterShape:n};return N.runKernel(zo,l,f)}const k0=w({conv2DBackpropFilter_:E0});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ms(t,e,n){if(n==null||n==="linear")return t;if(n==="relu")return D(t,ta(e));throw new Error(`Cannot compute gradient for fused activation ${n}.`)}function gs(t,e){let n=e;const s=_r(t.shape,e.shape);return s.length>0&&(n=X(n,s)),I(n,t.shape)}function ys(t,e,n,s){if(e==="linear")return t;if(e==="relu")return vn(t);if(e==="elu")return xr(t);if(e==="relu6")return Jr(t);if(e==="prelu")return qr(t,n);if(e==="leakyrelu")return Rr(t,s);if(e==="sigmoid")return wt(t);throw new Error(`Unknown fused activation ${e}.`)}const bs=(t,e)=>!(t>0)||e==="linear";/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function v0({x:t,filter:e,strides:n,pad:s,dataFormat:r="NHWC",dilations:a=[1,1],dimRoundingMode:o,bias:i,activation:u="linear",preluActivationWeights:c,leakyreluAlpha:h}){if(u=u||"linear",bs(N.state.gradientDepth,u)===!1){g(r==="NHWC",()=>`Error in fused conv2d: got dataFormat of ${r} but only NHWC is currently supported for the case of gradient depth is 0 and the activation is not linear.`);let F=Sn(t,e,n,s,r,a,o);return i!=null&&(F=B(F,i)),ys(F,u,c,h)}const l=d(t,"x","conv2d","float32"),f=d(e,"filter","conv2d","float32");let m=l,b=!1;l.rank===3&&(b=!0,m=I(l,[1,l.shape[0],l.shape[1],l.shape[2]])),g(m.rank===4,()=>`Error in fused conv2d: input must be rank 4, but got rank ${m.rank}.`),g(f.rank===4,()=>`Error in fused conv2d: filter must be rank 4, but got rank ${f.rank}.`),xe("fused conv2d",s,o);const T=r==="NHWC"?m.shape[3]:m.shape[1];g(f.shape[2]===T,()=>`Error in conv2d: depth of input (${T}) must match input depth for filter ${f.shape[2]}.`),g(Xe(n,a),()=>`Error in conv2D: Either strides or dilations must be 1. Got strides ${n} and dilations '${a}'`);const S=wn(m.shape,f.shape,n,a,s,o);let $;i!=null&&($=d(i,"bias","fused conv2d"),[$]=ee($,l),r==="NHWC"?re(S.outShape,$.shape):(g($.shape.length<=1,()=>`Error in fused conv2d: only supports scalar or 1-D Tensor bias for NCHW format but got the bias of rank-${$.shape.length}.`),g($.shape.length===0||$.shape[0]===S.outChannels||$.shape[0]===1,()=>`Error in fused conv2d: bias shape (${$.shape}) is not compatible with the number of output channels (${S.outChannels})`)));let O;if(c!=null){const F=c.shape;if(g(F.length<=1||F.length===3,()=>`Error in fused conv2d: only supports scalar, 1-D Tensor or 3-D Tensor PReLU activation weights but got a tensor of rank-${F.length}.`),F.length===1)g(F[0]===1||F[0]===S.outChannels,()=>`Error in fused conv2d: PReLU activation weights (${F}) is not compatible with the number of output channels (${S.outChannels}).`);else if(F.length===3)try{re(F,S.outShape)}catch{const C=`Error in fused conv2d: PReLU activation weights (${F}) is not compatible with the output shape of the conv2d (${S.outShape}).`;throw Error(C)}O=d(c,"prelu weights","fused conv2d")}const v=(F,L)=>{g(r==="NHWC",()=>`Error in gradient of fused conv2D: got dataFormat of ${r} but only NHWC is currently supported.`);const[C,k,E,y]=L,x=ms(F,E,u);g(un(a),()=>`Error in gradient of fused conv2D: dilation rates greater than 1 are not yet supported in gradients. Got dilations '${a}'`);const R=al(k.shape,x,C,n,s),z=k0(k,x,C.shape,n,s),V=[R,z];if(y!=null){const U=gs(y,x);V.push(U)}return V},_={x:m,filter:f,bias:$,preluActivationWeights:O},A={strides:n,pad:s,dataFormat:r,dilations:a,dimRoundingMode:o,activation:u,leakyreluAlpha:h};return i==null?Ve((L,C,k)=>{let E=N.runKernel(Os,_,A);return k([C,L,E]),b&&(E=I(E,[E.shape[1],E.shape[2],E.shape[3]])),{value:E,gradFunc:v}})(m,f):Ve((L,C,k,E)=>{let y=N.runKernel(Os,_,A);return E([C,L,y,k]),b&&(y=I(y,[y.shape[1],y.shape[2],y.shape[3]])),{value:y,gradFunc:v}})(m,f,$)}const _0=w({fusedConv2d_:v0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function I0(t,e,n,s,r,a=[1,1],o){let i=t;t.rank===3&&(i=I(t,[1,t.shape[0],t.shape[1],t.shape[2]]));let u=e;u.rank===3&&(u=I(e,[1,e.shape[0],e.shape[1],e.shape[2]]));const c={x:i,dy:u},h={strides:s,pad:r,dimRoundingMode:o,dilations:a,filterShape:n};return N.runKernel(Jo,c,h)}const x0=w({depthwiseConv2dNativeBackpropFilter_:I0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function A0(t,e,n,s,r,a=[1,1],o){let i=e,u=!1;e.rank===3&&(u=!0,i=I(e,[1,e.shape[0],e.shape[1],e.shape[2]]));const c={dy:i,filter:n},h={strides:s,pad:r,dimRoundingMode:o,dilations:a,inputShape:t},l=N.runKernel(Yo,c,h);return u?I(l,[l.shape[1],l.shape[2],l.shape[3]]):l}const O0=w({depthwiseConv2dNativeBackpropInput_:A0});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function D0({x:t,filter:e,strides:n,pad:s,dataFormat:r="NHWC",dilations:a=[1,1],dimRoundingMode:o,bias:i,activation:u="linear",preluActivationWeights:c,leakyreluAlpha:h}){if(bs(N.state.gradientDepth,u)===!1){let A=as(t,e,n,s,r,a,o);return i!=null&&(A=B(A,i)),ys(A,u,c,h)}const l=d(t,"x","depthwiseConv2d","float32"),f=d(e,"filter","depthwiseConv2d","float32");let m=l,b=!1;l.rank===3&&(b=!0,m=I(l,[1,l.shape[0],l.shape[1],l.shape[2]])),g(m.rank===4,()=>`Error in fused depthwiseConv2d: input must be rank 4, but got rank ${m.rank}.`),g(f.rank===4,()=>`Error in fused depthwiseConv2d: filter must be rank 4, but got rank ${f.rank}.`),g(m.shape[3]===f.shape[2],()=>`Error in fused depthwiseConv2d: number of input channels (${m.shape[3]}) must match the inChannels dimension in filter ${f.shape[2]}.`),a==null&&(a=[1,1]),g(Xe(n,a),()=>`Error in fused depthwiseConv2d: Either strides or dilations must be 1. Got strides ${n} and dilations '${a}'`),xe("fused depthwiseConv2d",s,o);const T=wn(m.shape,f.shape,n,a,s,o,!0);let S;i!=null&&(S=d(i,"bias","fused conv2d"),[S]=ee(S,l),re(T.outShape,S.shape));let $;c!=null&&($=d(c,"prelu weights","fused depthwiseConv2d"));const O=(A,F)=>{g(un(a),()=>`Error in gradient of fused depthwiseConv2d: dilation rates greater than 1 are not yet supported. Got dilations '${a}'`);const[L,C,k,E]=F,y=ms(A,k,u),x=O0(C.shape,y,L,n,s,a,o),R=x0(C,y,L.shape,n,s,a,o);if(E!=null){const z=gs(S,y);return[x,R,z]}return[x,R]},v={x:m,filter:f,bias:S,preluActivationWeights:$},_={strides:n,pad:s,dataFormat:r,dilations:a,dimRoundingMode:o,activation:u,leakyreluAlpha:h};return i==null?Ve((F,L,C)=>{let k=N.runKernel(Ds,v,_);return C([L,F,k]),b&&(k=I(k,[k.shape[1],k.shape[2],k.shape[3]])),{value:k,gradFunc:O}})(m,f):Ve((F,L,C,k)=>{let E=N.runKernel(Ds,v,_);return k([L,F,E,C]),b&&(E=I(E,[E.shape[1],E.shape[2],E.shape[3]])),{value:E,gradFunc:O}})(m,f,S)}const F0=w({fusedDepthwiseConv2d_:D0});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function C0({a:t,b:e,transposeA:n=!1,transposeB:s=!1,bias:r,activation:a="linear",preluActivationWeights:o,leakyreluAlpha:i=.2}){if(bs(N.state.gradientDepth,a)===!1){let y=j(t,e,n,s);return r!=null&&(y=B(y,r)),ys(y,a,o,i)}let u=d(t,"a","fused matMul"),c=d(e,"b","fused matMul");[u,c]=ee(u,c);const h=n?u.shape[u.rank-2]:u.shape[u.rank-1],l=s?c.shape[c.rank-1]:c.shape[c.rank-2],f=n?u.shape[u.rank-1]:u.shape[u.rank-2],m=s?c.shape[c.rank-2]:c.shape[c.rank-1],b=u.shape.slice(0,-2),T=c.shape.slice(0,-2),S=G(b),$=G(T);g(h===l,()=>`Error in fused matMul: inner shapes (${h}) and (${l}) of Tensors with shapes ${u.shape} and ${c.shape} and transposeA=${n} and transposeB=${s} must match.`);const v=re(u.shape.slice(0,-2),c.shape.slice(0,-2)).concat([f,m]),_=n?I(u,[S,h,f]):I(u,[S,f,h]),A=s?I(c,[$,m,l]):I(c,[$,l,m]);let F;r!=null&&(F=d(r,"bias","fused matMul"),[F]=ee(F,u),re(v,F.shape));let L;o!=null&&(L=d(o,"prelu weights","fused matMul"));const C=(y,x)=>{const[R,z,V,U]=x,Y=ms(I(y,V.shape),V,a);let ae,te;if(!n&&!s?(ae=j(Y,z,!1,!0),te=j(R,Y,!0,!1)):!n&&s?(ae=j(Y,z,!1,!1),te=j(Y,R,!0,!1)):n&&!s?(ae=j(z,Y,!1,!0),te=j(R,Y,!1,!1)):(ae=j(z,Y,!0,!0),te=j(Y,R,!0,!0)),r!=null){const se=gs(U,Y);return[ae,te,se]}else return[ae,te]},k={a:_,b:A,bias:F,preluActivationWeights:L},E={transposeA:n,transposeB:s,activation:a,leakyreluAlpha:i};return r==null?Ve((x,R,z)=>{const V=N.runKernel(As,k,E);return z([x,R,V]),{value:I(V,v),gradFunc:C}})(_,A):Ve((x,R,z,V)=>{const U=N.runKernel(As,k,E);return V([x,R,U,z]),{value:I(U,v),gradFunc:C}})(_,A,F)}const R0=w({fusedMatMul_:C0});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const qh=Object.freeze(Object.defineProperty({__proto__:null,conv2d:_0,depthwiseConv2d:F0,matMul:R0},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function L0(t){return ds(t,.54,.46)}const B0=w({hammingWindow_:L0});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function P0(t){return ds(t,.5,.5)}const Gh=w({hannWindow_:P0});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function z0(t,e,n,s=!1,r=0){let a=0;const o=[];for(;a+e<=t.size;)o.push(H(t,a,e)),a+=n;if(s)for(;a<t.size;){const i=a+e-t.size,u=he([H(t,a,e-i),jt([i],r)]);o.push(u),a+=n}return o.length===0?Ct([],[0,e]):I(he(o),[o.length,e])}const Hh=w({frame_:z0});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function V0(t,e,n,s,r=Gh){s==null&&(s=aa(e));const a=Hh(t,e,n),o=D(a,r(e));return hs(o,s)}const W0=w({stft_:V0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function M0(t,e,n,s,r="bilinear",a=0){const o=d(t,"image","cropAndResize"),i=d(e,"boxes","cropAndResize","float32"),u=d(n,"boxInd","cropAndResize","int32"),c=i.shape[0];g(o.rank===4,()=>`Error in cropAndResize: image must be rank 4,but got rank ${o.rank}.`),g(i.rank===2&&i.shape[1]===4,()=>`Error in cropAndResize: boxes must be have size [${c},4] but had shape ${i.shape}.`),g(u.rank===1&&u.shape[0]===c,()=>`Error in cropAndResize: boxInd must be have size [${c}] but had shape ${i.shape}.`),g(s.length===2,()=>`Error in cropAndResize: cropSize must be of length 2, but got length ${s.length}.`),g(s[0]>=1&&s[1]>=1,()=>`cropSize must be atleast [1,1], but was ${s}`),g(r==="bilinear"||r==="nearest",()=>`method must be bilinear or nearest, but was ${r}`);const h={image:o,boxes:i,boxInd:u},l={method:r,extrapolationValue:a,cropSize:s};return N.runKernel(Ho,h,l)}const U0=w({cropAndResize_:M0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function j0(t){const e=d(t,"image","flipLeftRight","float32");g(e.rank===4,()=>`Error in flipLeftRight: image must be rank 4,but got rank ${e.rank}.`);const n={image:e};return N.runKernel(hi,n,{})}const q0=w({flipLeftRight_:j0});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function G0(t){const e=d(t,"image","grayscaleToRGB"),n=e.rank-1,s=e.shape[n];g(e.rank>=2,()=>`Error in grayscaleToRGB: images must be at least rank 2, but got rank ${e.rank}.`),g(s===1,()=>`Error in grayscaleToRGB: last dimension of a grayscale image should be size 1, but got size ${s}.`);const r=new Array(e.rank);return r.fill(1,0,n),r[n]=3,Ft(e,r)}const H0=w({grayscaleToRGB_:G0});/**
 * @license
 * Copyright 2023 Google LLC.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function K0(t){const e=d(t,"image","RGBToGrayscale"),n=e.rank-1,s=e.shape[n];g(e.rank>=2,()=>`Error in RGBToGrayscale: images must be at least rank 2, but got rank ${e.rank}.`),g(s===3,()=>`Error in RGBToGrayscale: last dimension of an RGB image should be size 3, but got size ${s}.`);const r=e.dtype,a=J(e,"float32"),o=ke([.2989,.587,.114]);let i;switch(e.rank){case 2:i=mt("ij,j->i",a,o);break;case 3:i=mt("ijk,k->ij",a,o);break;case 4:i=mt("ijkl,l->ijk",a,o);break;case 5:i=mt("ijklm,m->ijkl",a,o);break;case 6:i=mt("ijklmn,n->ijklm",a,o);break;default:throw new Error("Not a valid tensor rank.")}return i=Me(i,-1),J(i,r)}const X0=w({rgbToGrayscale_:K0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Z0(t,e,n=0,s=.5){const r=d(t,"image","rotateWithOffset","float32");g(r.rank===4,()=>`Error in rotateWithOffset: image must be rank 4,but got rank ${r.rank}.`);const a={image:r},o={radians:e,fillValue:n,center:s};return N.runKernel(tc,a,o)}const J0=w({rotateWithOffset_:Z0});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Gt(t,e,n,s,r,a){s==null&&(s=.5),r==null&&(r=Number.NEGATIVE_INFINITY),a==null&&(a=0);const o=t.shape[0];return n=Math.min(n,o),g(0<=s&&s<=1,()=>`iouThreshold must be in [0, 1], but was '${s}'`),g(t.rank===2,()=>`boxes must be a 2D tensor, but was of rank '${t.rank}'`),g(t.shape[1]===4,()=>`boxes must have 4 columns, but 2nd dimension was ${t.shape[1]}`),g(e.rank===1,()=>"scores must be a 1D tensor"),g(e.shape[0]===o,()=>`scores has incompatible shape with boxes. Expected ${o}, but was ${e.shape[0]}`),g(0<=a&&a<=1,()=>`softNmsSigma must be in [0, 1], but was '${a}'`),{maxOutputSize:n,iouThreshold:s,scoreThreshold:r,softNmsSigma:a}}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Y0(t,e,n,s=.5,r=Number.NEGATIVE_INFINITY){const a=d(t,"boxes","nonMaxSuppression","float32"),o=d(e,"scores","nonMaxSuppression","float32"),i=Gt(a,o,n,s,r);n=i.maxOutputSize,s=i.iouThreshold,r=i.scoreThreshold;const u={maxOutputSize:n,iouThreshold:s,scoreThreshold:r};return N.runKernel(Ki,{boxes:a,scores:o},u)}const Q0=w({nonMaxSuppression_:Y0});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function ew(t,e,n){const s=tw(t,e,n),r=s<0?-(s+1):s;t.splice(r,0,e)}function tw(t,e,n){return sw(t,e,n||nw)}function nw(t,e){return t>e?1:t<e?-1:0}function sw(t,e,n){let s=0,r=t.length,a=0,o=!1;for(;s<r;){a=s+(r-s>>>1);const i=n(e,t[a]);i>0?s=a+1:(r=a,o=!i)}return o?s:-s-1}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Kh(t,e,n,s,r){return oa(t,e,n,s,r,0)}function Xh(t,e,n,s,r,a){return oa(t,e,n,s,r,0,!1,a,!0)}function Zh(t,e,n,s,r,a){return oa(t,e,n,s,r,a,!0)}function oa(t,e,n,s,r,a,o=!1,i=!1,u=!1){const c=[];for(let S=0;S<e.length;S++)e[S]>r&&c.push({score:e[S],boxIndex:S,suppressBeginIndex:0});c.sort(La);const h=a>0?-.5/a:0,l=[],f=[];for(;l.length<n&&c.length>0;){const S=c.pop(),{score:$,boxIndex:O,suppressBeginIndex:v}=S;if($<r)break;let _=!1;for(let A=l.length-1;A>=v;--A){const F=rw(t,O,l[A]);if(F>=s){_=!0;break}if(S.score=S.score*aw(s,h,F),S.score<=r)break}S.suppressBeginIndex=l.length,_||(S.score===$?(l.push(O),f.push(S.score)):S.score>r&&ew(c,S,La))}const m=l.length,b=n-m;i&&b>0&&(l.push(...new Array(b).fill(0)),f.push(...new Array(b).fill(0)));const T={selectedIndices:l};return o&&(T.selectedScores=f),u&&(T.validOutputs=m),T}function rw(t,e,n){const s=t.subarray(e*4,e*4+4),r=t.subarray(n*4,n*4+4),a=Math.min(s[0],s[2]),o=Math.min(s[1],s[3]),i=Math.max(s[0],s[2]),u=Math.max(s[1],s[3]),c=Math.min(r[0],r[2]),h=Math.min(r[1],r[3]),l=Math.max(r[0],r[2]),f=Math.max(r[1],r[3]),m=(i-a)*(u-o),b=(l-c)*(f-h);if(m<=0||b<=0)return 0;const T=Math.max(a,c),S=Math.max(o,h),$=Math.min(i,l),O=Math.min(u,f),v=Math.max($-T,0)*Math.max(O-S,0);return v/(m+b-v)}function aw(t,e,n){const s=Math.exp(e*n*n);return n<=t?s:0}function La(t,e){return t.score-e.score||t.score===e.score&&e.boxIndex-t.boxIndex}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */async function ow(t,e,n,s=.5,r=Number.NEGATIVE_INFINITY){const a=d(t,"boxes","nonMaxSuppressionAsync"),o=d(e,"scores","nonMaxSuppressionAsync"),i=Gt(a,o,n,s,r);n=i.maxOutputSize,s=i.iouThreshold,r=i.scoreThreshold;const u=await Promise.all([a.data(),o.data()]),c=u[0],h=u[1],{selectedIndices:l}=Kh(c,h,n,s,r);return a!==t&&a.dispose(),o!==e&&o.dispose(),ke(l,"int32")}const iw=ow;/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function uw(t,e,n,s=.5,r=Number.NEGATIVE_INFINITY,a=0){const o=d(t,"boxes","nonMaxSuppression"),i=d(e,"scores","nonMaxSuppression"),u=Gt(o,i,n,s,r,a);n=u.maxOutputSize,s=u.iouThreshold,r=u.scoreThreshold,a=u.softNmsSigma;const c={boxes:o,scores:i},h={maxOutputSize:n,iouThreshold:s,scoreThreshold:r,softNmsSigma:a},l=N.runKernel(Zi,c,h);return{selectedIndices:l[0],selectedScores:l[1]}}const cw=w({nonMaxSuppressionWithScore_:uw});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */async function lw(t,e,n,s=.5,r=Number.NEGATIVE_INFINITY,a=0){const o=d(t,"boxes","nonMaxSuppressionAsync"),i=d(e,"scores","nonMaxSuppressionAsync"),u=Gt(o,i,n,s,r,a);n=u.maxOutputSize,s=u.iouThreshold,r=u.scoreThreshold,a=u.softNmsSigma;const c=await Promise.all([o.data(),i.data()]),h=c[0],l=c[1],{selectedIndices:f,selectedScores:m}=Zh(h,l,n,s,r,a);return o!==t&&o.dispose(),i!==e&&i.dispose(),{selectedIndices:ke(f,"int32"),selectedScores:ke(m)}}const hw=lw;/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function pw(t,e,n,s=.5,r=Number.NEGATIVE_INFINITY,a=!1){const o=d(t,"boxes","nonMaxSuppression"),i=d(e,"scores","nonMaxSuppression"),u=Gt(o,i,n,s,r,null),c=u.maxOutputSize,h=u.iouThreshold,l=u.scoreThreshold,f={boxes:o,scores:i},m={maxOutputSize:c,iouThreshold:h,scoreThreshold:l,padToMaxOutputSize:a},b=N.runKernel(Xi,f,m);return{selectedIndices:b[0],validOutputs:b[1]}}const fw=w({nonMaxSuppressionPadded_:pw});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */async function dw(t,e,n,s=.5,r=Number.NEGATIVE_INFINITY,a=!1){const o=d(t,"boxes","nonMaxSuppressionAsync"),i=d(e,"scores","nonMaxSuppressionAsync"),u=Gt(o,i,n,s,r,null),c=u.maxOutputSize,h=u.iouThreshold,l=u.scoreThreshold,[f,m]=await Promise.all([o.data(),i.data()]),{selectedIndices:b,validOutputs:T}=Xh(f,m,c,h,l,a);return o!==t&&o.dispose(),i!==e&&i.dispose(),{selectedIndices:ke(b,"int32"),validOutputs:M(T,"int32")}}const mw=dw;/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function gw(t,e,n=!1,s=!1){const r=d(t,"images","resizeBilinear");g(r.rank===3||r.rank===4,()=>`Error in resizeBilinear: x must be rank 3 or 4, but got rank ${r.rank}.`),g(e.length===2,()=>`Error in resizeBilinear: new shape must 2D, but got shape ${e}.`),g(s===!1||n===!1,()=>"Error in resizeBilinear: If halfPixelCenters is true, alignCorners must be false.");let a=r,o=!1;r.rank===3&&(o=!0,a=I(r,[1,r.shape[0],r.shape[1],r.shape[2]]));const i={images:a},u={alignCorners:n,halfPixelCenters:s,size:e},c=N.runKernel(fu,i,u);return o?I(c,[c.shape[1],c.shape[2],c.shape[3]]):c}const yw=w({resizeBilinear_:gw});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function bw(t,e,n=!1,s=!1){const r=d(t,"images","resizeNearestNeighbor");g(r.rank===3||r.rank===4,()=>`Error in resizeNearestNeighbor: x must be rank 3 or 4, but got rank ${r.rank}.`),g(e.length===2,()=>`Error in resizeNearestNeighbor: new shape must 2D, but got shape ${e}.`),g(r.dtype==="float32"||r.dtype==="int32",()=>"`images` must have `int32` or `float32` as dtype"),g(s===!1||n===!1,()=>"Error in resizeNearestNeighbor: If halfPixelCenters is true, alignCorners must be false.");let a=r,o=!1;r.rank===3&&(o=!0,a=I(r,[1,r.shape[0],r.shape[1],r.shape[2]]));const i={images:a},u={alignCorners:n,halfPixelCenters:s,size:e},c=N.runKernel(pu,i,u);return o?I(c,[c.shape[1],c.shape[2],c.shape[3]]):c}const ww=w({resizeNearestNeighbor_:bw});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Nw(t,e="binary",n=!1,s=.5){const r=d(t,"image","threshold"),a=.2989,o=.587,i=.114,u=r.shape[0]*r.shape[1];let c=D(ke([s]),255),h,l,f,m;if(g(r.rank===3,()=>`Error in threshold: image must be rank 3,but got rank ${r.rank}.`),g(r.shape[2]===3||r.shape[2]===1,()=>`Error in threshold: image color channel must be equal to 3 or 1but got ${r.shape[2]}.`),g(r.dtype==="int32"||r.dtype==="float32",()=>`Error in dtype: image dtype must be int32 or float32,but got dtype ${r.dtype}.`),g(e==="otsu"||e==="binary",()=>`Method must be binary or otsu, but was ${e}`),r.shape[2]===3){[h,l,f]=Mt(r,[1,1,1],-1);const S=D(h,a),$=D(l,o),O=D(f,i);m=B(B(S,$),O)}else m=t;if(e==="otsu"){const S=vr(J(Yr(m),"int32"),De([]),256);c=Sw(S,u)}const b=n?os(m,c):En(m,c);return J(D(b,255),"int32")}function Sw(t,e){let n=ke([-1]),s=ke([0]),r=ke([0]),a,o,i,u,c,h;for(let l=0;l<t.size-1;l++){a=H(t,0,l+1),o=H(t,l+1),c=Z(X(a),e),h=Z(X(o),e);const f=X(D(a,Vt(0,a.size)));i=Z(f,X(a));const m=jt(o.shape,a.size),b=B(Vt(0,o.size),m),T=D(o,b);u=Z(X(T),X(o));const S=W(i,u),$=W(i,u),O=D(c,h);r=D(D(O,S),$);const v=En(r,s);s=He(v,r,s),n=He(v,ke([l]),n)}return n}const Tw=w({threshold_:Nw});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function $w(t,e,n="nearest",s="constant",r=0,a){const o=d(t,"image","transform","float32"),i=d(e,"transforms","transform","float32");g(o.rank===4,()=>`Error in transform: image must be rank 4,but got rank ${o.rank}.`),g(i.rank===2&&(i.shape[0]===o.shape[0]||i.shape[0]===1)&&i.shape[1]===8,()=>"Error in transform: Input transform should be batch x 8 or 1 x 8"),g(a==null||a.length===2,()=>`Error in transform: outputShape must be [height, width] or null, but got ${a}.`);const u={image:o,transforms:i},c={interpolation:n,fillMode:s,fillValue:r,outputShape:a};return N.runKernel(Xu,u,c)}const Ew=w({transform_:$w});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function kw(t,e,n){const s=d(t,"a","bandPart");g(s.rank>=2,()=>`bandPart(): Rank must be at least 2, got ${s.rank}.`);const r=s.shape,[a,o]=s.shape.slice(-2);let i,u;typeof e=="number"?(g(e%1===0,()=>`bandPart(): numLower must be an integer, got ${e}.`),g(e<=a,()=>`bandPart(): numLower (${e}) must not be greater than the number of rows (${a}).`),i=d(e<0?a:e,"numLower","bandPart")):(g(e.dtype==="int32",()=>"bandPart(): numLower's dtype must be an int32."),i=He(Jn(e,0),a,hn(e,a))),typeof n=="number"?(g(n%1===0,()=>`bandPart(): numUpper must be an integer, got ${n}.`),g(n<=o,()=>`bandPart(): numUpper (${n}) must not be greater than the number of columns (${o}).`),u=d(n<0?o:n,"numUpper","bandPart")):(g(n.dtype==="int32",()=>"bandPart(): numUpper's dtype must be an int32."),u=He(Jn(n,0),o,hn(n,o)));const c=I(Vt(0,a,1,"int32"),[-1,1]),h=Vt(0,o,1,"int32"),l=W(c,h),f=cn(os(l,i),Cr(l,Fe(u))),m=kt([a,o],s.dtype);return I(We(lt(I(s,[-1,a,o])).map(b=>He(f,b,m))),r)}const vw=w({bandPart_:kw});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function _w(t){let e;if(Array.isArray(t)){e=!1,g(t!=null&&t.length>0,()=>"Gram-Schmidt process: input must not be null, undefined, or empty");const r=t[0].shape[0];for(let a=1;a<t.length;++a)g(t[a].shape[0]===r,()=>`Gram-Schmidt: Non-unique lengths found in the input vectors: (${t[a].shape[0]} vs. ${r})`)}else e=!0,t=Mt(t,t.shape[0],0).map(r=>ps(r,[0]));g(t.length<=t[0].shape[0],()=>`Gram-Schmidt: Number of vectors (${t.length}) exceeds number of dimensions (${t[0].shape[0]}).`);const n=[],s=t;for(let r=0;r<t.length;++r)n.push(N.tidy(()=>{let a=s[r];if(r>0)for(let o=0;o<r;++o){const i=D(X(D(n[o],a)),n[o]);a=W(a,i)}return Z(a,$n(a,"euclidean"))}));return e?We(n,0):n}const Iw=w({gramSchmidt_:_w});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function xw(t,e=!1){if(g(t.rank>=2,()=>`qr() requires input tensor to have a rank >= 2, but got rank ${t.rank}`),t.rank===2)return Ba(t,e);{const n=t.shape.slice(0,t.shape.length-2).reduce((u,c)=>u*c),s=lt(I(t,[n,t.shape[t.shape.length-2],t.shape[t.shape.length-1]]),0),r=[],a=[];s.forEach(u=>{const[c,h]=Ba(u,e);r.push(c),a.push(h)});const o=I(We(r,0),t.shape),i=I(We(a,0),t.shape);return[o,i]}}function Ba(t,e=!1){return N.tidy(()=>{g(t.shape.length===2,()=>`qr2d() requires a 2D Tensor, but got a ${t.shape.length}D Tensor.`);const n=t.shape[0],s=t.shape[1];let r=Or(n),a=Ge(t);const o=Ct([[1]],[1,1]);let i=Ge(o);const u=n>=s?s:n;for(let c=0;c<u;++c){const h=a,l=i,f=r;[i,a,r]=N.tidy(()=>{const m=H(a,[c,c],[n-c,1]),b=$n(m),T=H(a,[c,c],[1,1]),S=He(En(T,0),Ct([[-1]]),Ct([[1]])),$=W(T,D(S,b)),O=Z(m,$);O.shape[0]===1?i=Ge(o):i=he([o,H(O,[1,0],[O.shape[0]-1,O.shape[1]])],0);const v=Fe(Z(j(S,$),b)),_=H(a,[c,0],[n-c,s]),A=D(v,i),F=fn(i);if(c===0)a=W(_,j(A,j(F,_)));else{const k=W(_,j(A,j(F,_)));a=he([H(a,[0,0],[c,s]),k],0)}const L=fn(A),C=H(r,[0,c],[n,r.shape[1]-c]);if(c===0)r=W(C,j(j(C,i),L));else{const k=W(C,j(j(C,i),L));r=he([H(r,[0,0],[n,c]),k],1)}return[i,a,r]}),me([h,l,f])}return!e&&n>s&&(r=H(r,[0,0],[n,s]),a=H(a,[0,0],[s,s])),[r,a]})}const Aw=w({qr_:xw});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */var de;(function(t){t[t.NONE=0]="NONE",t[t.MEAN=1]="MEAN",t[t.SUM=2]="SUM",t[t.SUM_BY_NONZERO_WEIGHTS=3]="SUM_BY_NONZERO_WEIGHTS"})(de||(de={}));function Ow(t,e,n=de.SUM_BY_NONZERO_WEIGHTS){const s=d(t,"losses","computeWeightedLoss");let r=null;e!=null&&(r=d(e,"weights","computeWeightedLoss"));const a=r==null?s:D(s,r);if(n===de.NONE)return a;if(n===de.SUM)return X(a);if(n===de.MEAN){if(r==null)return ln(a);{const o=s.size/r.size,i=Z(X(a),X(r));return o>1?Z(i,M(o)):i}}if(n===de.SUM_BY_NONZERO_WEIGHTS){if(r==null)return Z(X(a),M(s.size));{const o=D(r,tt(s.shape)),i=J(X(Ur(o,M(0))),"float32");return Z(X(a),i)}}throw Error(`Unknown reduction: ${n}`)}const Ze=w({computeWeightedLoss_:Ow});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Dw(t,e,n,s=de.SUM_BY_NONZERO_WEIGHTS){const r=d(t,"labels","absoluteDifference"),a=d(e,"predictions","absoluteDifference");let o=null;n!=null&&(o=d(n,"weights","absoluteDifference")),ge(r.shape,a.shape,"Error in absoluteDifference: ");const i=Se(W(r,a));return Ze(i,o,s)}const Fw=w({absoluteDifference_:Dw});function Cw(t,e,n,s,r=de.SUM_BY_NONZERO_WEIGHTS){const a=d(t,"labels","cosineDistance"),o=d(e,"predictions","cosineDistance");let i=null;s!=null&&(i=d(s,"weights","cosineDistance")),ge(a.shape,o.shape,"Error in cosineDistance: ");const u=M(1),c=W(u,X(D(a,o),n,!0));return Ze(c,i,r)}const Rw=w({cosineDistance_:Cw});function Lw(t,e,n,s=de.SUM_BY_NONZERO_WEIGHTS){let r=d(t,"labels","hingeLoss");const a=d(e,"predictions","hingeLoss");let o=null;n!=null&&(o=d(n,"weights","hingeLoss")),ge(r.shape,a.shape,"Error in hingeLoss: ");const i=M(1);r=W(D(M(2),r),i);const u=vn(W(i,D(r,a)));return Ze(u,o,s)}const Bw=w({hingeLoss_:Lw});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Pw(t,e,n,s=1,r=de.SUM_BY_NONZERO_WEIGHTS){const a=d(t,"labels","huberLoss"),o=d(e,"predictions","huberLoss");let i=null;n!=null&&(i=d(n,"weights","huberLoss")),ge(a.shape,o.shape,"Error in huberLoss: ");const u=M(s),c=Se(W(o,a)),h=hn(c,u),l=W(c,h),f=B(D(M(.5),Ie(h)),D(u,l));return Ze(f,i,r)}const zw=w({huberLoss_:Pw});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Vw(t,e,n,s=1e-7,r=de.SUM_BY_NONZERO_WEIGHTS){const a=d(t,"labels","logLoss"),o=d(e,"predictions","logLoss");let i=null;n!=null&&(i=d(n,"weights","logLoss")),ge(a.shape,o.shape,"Error in logLoss: ");const u=M(1),c=M(s),h=Fe(D(a,zt(B(o,c)))),l=D(W(u,a),zt(B(W(u,o),c))),f=W(h,l);return Ze(f,i,r)}const Ww=w({logLoss_:Vw});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Mw(t,e,n,s=de.SUM_BY_NONZERO_WEIGHTS){const r=d(t,"labels","meanSquaredError"),a=d(e,"predictions","meanSquaredError");let o=null;n!=null&&(o=d(n,"weights","meanSquaredError")),ge(r.shape,a.shape,"Error in meanSquaredError: ");const i=ea(r,a);return Ze(i,o,s)}const Uw=w({meanSquaredError_:Mw});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function jw(t,e){const n=d(t,"labels","sigmoidCrossEntropyWithLogits"),s=d(e,"logits","sigmoidCrossEntropyWithLogits");ge(n.shape,s.shape,"Error in sigmoidCrossEntropyWithLogits: ");const r=vn(s),a=D(s,n),o=Lr(it(Fe(Se(s))));return B(W(r,a),o)}function qw(t,e,n,s=0,r=de.SUM_BY_NONZERO_WEIGHTS){let a=d(t,"multiClassLabels","sigmoidCrossEntropy");const o=d(e,"logits","sigmoidCrossEntropy");let i=null;if(n!=null&&(i=d(n,"weights","sigmoidCrossEntropy")),ge(a.shape,o.shape,"Error in sigmoidCrossEntropy: "),s>0){const c=M(s),h=M(1),l=M(.5);a=B(D(a,W(h,c)),D(l,c))}const u=jw(a,o);return Ze(u,i,r)}const Gw=w({sigmoidCrossEntropy_:qw});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Hw(t,e,n=-1){if(n===-1&&(n=e.rank-1),n!==e.rank-1)throw Error(`Softmax cross entropy along a non-last dimension is not yet supported. Labels / logits was rank ${e.rank} and dim was ${n}`);return Ve((r,a,o)=>{const u=Pr(a,[n],!0),c=W(J(a,"float32"),u);o([r,c]);const h=Fe(D(c,r));return{value:X(h,[n]),gradFunc:(m,b)=>{const[T,S]=b,$=Tn(m.shape,[n]);return[D(I(m,$),W(J(T,"float32"),it(S))),D(I(m,$),W(it(S),J(T,"float32")))]}}})(t,e)}function Kw(t,e,n,s=0,r=de.SUM_BY_NONZERO_WEIGHTS){let a=d(t,"onehotLabels","softmaxCrossEntropy");const o=d(e,"logits","softmaxCrossEntropy");let i=null;if(n!=null&&(i=d(n,"weights","softmaxCrossEntropy")),ge(a.shape,o.shape,"Error in softmaxCrossEntropy: "),s>0){const c=M(s),h=M(1),l=M(a.shape[1]);a=B(D(a,W(h,c)),Z(c,l))}const u=Hw(a,o);return Ze(u,i,r)}const Xw=w({softmaxCrossEntropy_:Kw});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Zw(t,e,n,s){const r=d(t,"indices","sparseFillEmptyRows","int32"),a=d(e,"values","sparseFillEmptyRows"),o=d(n,"denseShape","sparseFillEmptyRows","int32"),i=d(s,"defaultValue","sparseFillEmptyRows",a.dtype);if(r.rank!==2)throw new Error(`Indices should be Tensor2D but received shape
        ${r.shape}`);if(a.rank!==1)throw new Error(`Values should be Tensor1D but received shape ${a.shape}`);if(o.rank!==1)throw new Error(`Dense shape should be Tensor1D but received shape ${o.shape}`);if(i.rank!==0)throw new Error(`Default value should be a scalar but received shape ${i.shape}`);const u={indices:r,values:a,denseShape:o,defaultValue:i},c=N.runKernel(Cu,u);return{outputIndices:c[0],outputValues:c[1],emptyRowIndicator:c[2],reverseIndexMap:c[3]}}const Jw=w({sparseFillEmptyRows_:Zw});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Yw(t,e,n){const s=d(t,"inputIndices","sparseReshape","int32"),r=d(e,"inputShape","sparseReshape","int32"),a=d(n,"newShape","sparseReshape","int32");if(s.rank!==2)throw new Error(`Input indices should be Tensor2D but received shape
        ${s.shape}`);if(r.rank!==1)throw new Error(`Input shape should be Tensor1D but received shape ${r.shape}`);if(a.rank!==1)throw new Error(`New shape should be Tensor1D but received shape ${a.shape}`);const o={inputIndices:s,inputShape:r,newShape:a},i=N.runKernel(Ru,o);return{outputIndices:i[0],outputShape:i[1]}}const Qw=w({sparseReshape_:Yw});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function e1(t,e,n){const s=d(t,"data","sparseSegmentMean"),r=d(e,"indices","sparseSegmentMean","int32"),a=d(n,"segmentIds","sparseSegmentMean","int32");if(s.rank<1)throw new Error("Data should be at least 1 dimensional but received scalar");if(r.rank!==1)throw new Error(`Indices should be Tensor1D but received shape
          ${r.shape}`);if(a.rank!==1)throw new Error(`Segment ids should be Tensor1D but received shape
          ${a.shape}`);const o={data:s,indices:r,segmentIds:a};return N.runKernel(Lu,o)}const t1=w({sparseSegmentMean_:e1});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function n1(t,e,n){const s=d(t,"data","sparseSegmentSum"),r=d(e,"indices","sparseSegmentSum","int32"),a=d(n,"segmentIds","sparseSegmentSum","int32");if(s.rank<1)throw new Error("Data should be at least 1 dimensional but received scalar");if(r.rank!==1)throw new Error(`Indices should be Tensor1D but received shape
         ${r.shape}`);if(a.rank!==1)throw new Error(`Segment ids should be Tensor1D but received shape
         ${a.shape}`);const o={data:s,indices:r,segmentIds:a};return N.runKernel(Bu,o)}const s1=w({sparseSegmentSum_:n1});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function r1(t,e,n,s,r,a,o,i){const u=d(t,"data","stringNGrams","string");if(u.dtype!=="string")throw new Error("Data must be of datatype string");if(u.shape.length!==1)throw new Error(`Data must be a vector, saw: ${u.shape}`);const c=d(e,"dataSplits","stringNGrams");if(c.dtype!=="int32")throw new Error("Data splits must be of datatype int32");const h={separator:n,nGramWidths:s,leftPad:r,rightPad:a,padWidth:o,preserveShortSequences:i},l={data:u,dataSplits:c},f=N.runKernel(Mu,l,h);return{nGrams:f[0],nGramsSplits:f[1]}}const a1=w({stringNGrams_:r1});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function o1(t,e,n=!0){const s=d(t,"input","stringSplit","string"),r=d(e,"delimiter","stringSplit","string");if(s.rank!==1)throw new Error(`Input should be Tensor1D but received shape ${s.shape}`);if(r.rank!==0)throw new Error(`Delimiter should be a scalar but received shape ${r.shape}`);const a={skipEmpty:n},o={input:s,delimiter:r},i=N.runKernel(Uu,o,a);return{indices:i[0],values:i[1],shape:i[2]}}const i1=w({stringSplit_:o1});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function u1(t,e){const n=d(t,"input","stringToHashBucketFast","string"),s={numBuckets:e};if(e<=0)throw new Error("Number of buckets must be at least 1");const r={input:n};return N.runKernel(ju,r,s)}const c1=w({stringToHashBucketFast_:u1});/**
 * @license
 * Copyright 2023 Google LLC.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function l1(t,e,n,s=!0){const r=d(t,"input","staticRegexReplace","string"),a={pattern:e,rewrite:n,replaceGlobal:s};return N.runKernel(Vu,{x:r},a)}const h1=w({staticRegexReplace_:l1});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const Jh={fft:ls,ifft:pn,rfft:hs,irfft:Qr},Yh={hammingWindow:B0,hannWindow:Gh,frame:Hh,stft:W0},Qh={flipLeftRight:q0,grayscaleToRGB:H0,resizeNearestNeighbor:ww,resizeBilinear:yw,rgbToGrayscale:X0,rotateWithOffset:J0,cropAndResize:U0,nonMaxSuppression:Q0,nonMaxSuppressionAsync:iw,nonMaxSuppressionWithScore:cw,nonMaxSuppressionWithScoreAsync:hw,nonMaxSuppressionPadded:fw,nonMaxSuppressionPaddedAsync:mw,threshold:Tw,transform:Ew},ep={bandPart:vw,gramSchmidt:Iw,qr:Aw},tp={absoluteDifference:Fw,computeWeightedLoss:Ze,cosineDistance:Rw,hingeLoss:Bw,huberLoss:zw,logLoss:Ww,meanSquaredError:Uw,sigmoidCrossEntropy:Gw,softmaxCrossEntropy:Xw},np={sparseFillEmptyRows:Jw,sparseReshape:Qw,sparseSegmentMean:t1,sparseSegmentSum:s1},sp={stringNGrams:a1,stringSplit:i1,stringToHashBucketFast:c1,staticRegexReplace:h1};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const p1=new Map,Gs=new Map;class rp{getClassName(){return this.constructor.className}static fromConfig(e,n){return new e(n)}}class Ye{constructor(){this.classNameMap={}}static getMap(){return Ye.instance==null&&(Ye.instance=new Ye),Ye.instance}static register(e){Ye.getMap().classNameMap[e.className]=[e,e.fromConfig]}}function ap(t,e,n){g(t.className!=null,()=>"Class being registered does not have the static className property defined."),g(typeof t.className=="string",()=>"className is required to be a string, but got type "+typeof t.className),g(t.className.length>0,()=>"Class being registered has an empty-string as its className, which is disallowed."),typeof e>"u"&&(e="Custom"),typeof n>"u"&&(n=t.className);const s=n,r=e+">"+s;return Ye.register(t),p1.set(r,t),Gs.set(t,r),t}function f1(t){return Gs.has(t)?Gs.get(t):t.className}const d1=Object.freeze(Object.defineProperty({__proto__:null,Serializable:rp,SerializationMap:Ye,getRegisteredName:f1,registerClass:ap},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class ht extends rp{minimize(e,n=!1,s){const{value:r,grads:a}=this.computeGradients(e,s);if(s!=null){const o=s.map(i=>({name:i.name,tensor:a[i.name]}));this.applyGradients(o)}else this.applyGradients(a);return me(a),n?r:(r.dispose(),null)}get iterations(){return this.iterations_==null&&(this.iterations_=0),this.iterations_}incrementIterations(){this.iterations_=this.iterations+1}computeGradients(e,n){return Ol(e,n)}dispose(){this.iterations_!=null&&me(this.iterations_)}async saveIterations(){return this.iterations_==null&&(this.iterations_=0),{name:"iter",tensor:M(this.iterations_,"int32")}}async getWeights(){throw new Error("getWeights() is not implemented for this optimizer yet.")}async setWeights(e){throw new Error(`setWeights() is not implemented for this optimizer class ${this.getClassName()}`)}async extractIterations(e){return this.iterations_=(await e[0].tensor.data())[0],e.slice(1)}}Object.defineProperty(ht,Symbol.hasInstance,{value:t=>t.minimize!=null&&t.computeGradients!=null&&t.applyGradients!=null});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class ia extends ht{static get className(){return"Adadelta"}constructor(e,n,s=null){super(),this.learningRate=e,this.rho=n,this.epsilon=s,this.accumulatedGrads=[],this.accumulatedUpdates=[],s==null&&(this.epsilon=N.backend.epsilon())}applyGradients(e){(Array.isArray(e)?e.map(s=>s.name):Object.keys(e)).forEach((s,r)=>{const a=N.registeredVariables[s],o=!1;this.accumulatedGrads[r]==null&&(this.accumulatedGrads[r]={originalName:`${s}/accum_grad`,variable:q(()=>Te(a).variable(o))}),this.accumulatedUpdates[r]==null&&(this.accumulatedUpdates[r]={originalName:`${s}/accum_var`,variable:q(()=>Te(a).variable(o))});const i=Array.isArray(e)?e[r].tensor:e[s];if(i==null)return;const u=this.accumulatedGrads[r].variable,c=this.accumulatedUpdates[r].variable;q(()=>{const h=B(D(u,this.rho),D(Ie(i),1-this.rho)),l=D(Z(ze(B(c,this.epsilon)),ze(B(u,this.epsilon))),i),f=B(D(c,this.rho),D(Ie(l),1-this.rho));u.assign(h),c.assign(f);const m=B(D(l,-this.learningRate),a);a.assign(m)})}),this.incrementIterations()}dispose(){this.accumulatedUpdates!=null&&(me(this.accumulatedGrads.map(e=>e.variable)),me(this.accumulatedUpdates.map(e=>e.variable)))}async getWeights(){const e=[...this.accumulatedGrads,...this.accumulatedUpdates];return[await this.saveIterations()].concat(e.map(n=>({name:n.originalName,tensor:n.variable})))}async setWeights(e){e=await this.extractIterations(e);const n=e.length/2,s=!1;this.accumulatedGrads=e.slice(0,n).map(r=>({originalName:r.name,variable:r.tensor.variable(s)})),this.accumulatedUpdates=e.slice(n,n*2).map(r=>({originalName:r.name,variable:r.tensor.variable(s)}))}getConfig(){return{learningRate:this.learningRate,rho:this.rho,epsilon:this.epsilon}}static fromConfig(e,n){return new e(n.learningRate,n.rho,n.epsilon)}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class ua extends ht{static get className(){return"Adagrad"}constructor(e,n=.1){super(),this.learningRate=e,this.initialAccumulatorValue=n,this.accumulatedGrads=[]}applyGradients(e){(Array.isArray(e)?e.map(s=>s.name):Object.keys(e)).forEach((s,r)=>{const a=N.registeredVariables[s];this.accumulatedGrads[r]==null&&(this.accumulatedGrads[r]={originalName:`${s}/accumulator`,variable:q(()=>jt(a.shape,this.initialAccumulatorValue).variable(!1))});const o=Array.isArray(e)?e[r].tensor:e[s];if(o==null)return;const i=this.accumulatedGrads[r].variable;q(()=>{const u=B(i,Ie(o));i.assign(u);const c=B(D(Z(o,ze(B(u,N.backend.epsilon()))),-this.learningRate),a);a.assign(c)})}),this.incrementIterations()}dispose(){this.accumulatedGrads!=null&&me(this.accumulatedGrads.map(e=>e.variable))}async getWeights(){return[await this.saveIterations()].concat(this.accumulatedGrads.map(e=>({name:e.originalName,tensor:e.variable})))}async setWeights(e){e=await this.extractIterations(e);const n=!1;this.accumulatedGrads=e.map(s=>({originalName:s.name,variable:s.tensor.variable(n)}))}getConfig(){return{learningRate:this.learningRate,initialAccumulatorValue:this.initialAccumulatorValue}}static fromConfig(e,n){return new e(n.learningRate,n.initialAccumulatorValue)}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class ca extends ht{static get className(){return"Adam"}constructor(e,n,s,r=null){super(),this.learningRate=e,this.beta1=n,this.beta2=s,this.epsilon=r,this.accumulatedFirstMoment=[],this.accumulatedSecondMoment=[],q(()=>{this.accBeta1=M(n).variable(),this.accBeta2=M(s).variable()}),r==null&&(this.epsilon=N.backend.epsilon())}applyGradients(e){const n=Array.isArray(e)?e.map(s=>s.name):Object.keys(e);q(()=>{const s=W(1,this.accBeta1),r=W(1,this.accBeta2);n.forEach((a,o)=>{const i=N.registeredVariables[a],u=!1;this.accumulatedFirstMoment[o]==null&&(this.accumulatedFirstMoment[o]={originalName:`${a}/m`,variable:q(()=>Te(i).variable(u))}),this.accumulatedSecondMoment[o]==null&&(this.accumulatedSecondMoment[o]={originalName:`${a}/v`,variable:q(()=>Te(i).variable(u))});const c=Array.isArray(e)?e[o].tensor:e[a];if(c==null)return;const h=this.accumulatedFirstMoment[o].variable,l=this.accumulatedSecondMoment[o].variable,f=B(D(h,this.beta1),D(c,1-this.beta1)),m=B(D(l,this.beta2),D(Ie(c),1-this.beta2)),b=Z(f,s),T=Z(m,r);h.assign(f),l.assign(m);const S=B(D(Z(b,B(ze(T),this.epsilon)),-this.learningRate),i);i.assign(S)}),this.accBeta1.assign(D(this.accBeta1,this.beta1)),this.accBeta2.assign(D(this.accBeta2,this.beta2))}),this.incrementIterations()}dispose(){this.accBeta1.dispose(),this.accBeta2.dispose(),this.accumulatedFirstMoment!=null&&me(this.accumulatedFirstMoment.map(e=>e.variable)),this.accumulatedSecondMoment!=null&&me(this.accumulatedSecondMoment.map(e=>e.variable))}async getWeights(){const e=[...this.accumulatedFirstMoment,...this.accumulatedSecondMoment];return[await this.saveIterations()].concat(e.map(n=>({name:n.originalName,tensor:n.variable})))}async setWeights(e){e=await this.extractIterations(e),q(()=>{this.accBeta1.assign(Pt(this.beta1,this.iterations_+1)),this.accBeta2.assign(Pt(this.beta2,this.iterations_+1))});const n=e.length/2,s=!1;this.accumulatedFirstMoment=e.slice(0,n).map(r=>({originalName:r.name,variable:r.tensor.variable(s)})),this.accumulatedSecondMoment=e.slice(n,n*2).map(r=>({originalName:r.name,variable:r.tensor.variable(s)}))}getConfig(){return{learningRate:this.learningRate,beta1:this.beta1,beta2:this.beta2,epsilon:this.epsilon}}static fromConfig(e,n){return new e(n.learningRate,n.beta1,n.beta2,n.epsilon)}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class la extends ht{static get className(){return"Adamax"}constructor(e,n,s,r=null,a=0){super(),this.learningRate=e,this.beta1=n,this.beta2=s,this.epsilon=r,this.decay=a,this.accumulatedFirstMoment=[],this.accumulatedWeightedInfNorm=[],q(()=>{this.iteration=M(0).variable(),this.accBeta1=M(n).variable()}),r==null&&(this.epsilon=N.backend.epsilon())}applyGradients(e){const n=Array.isArray(e)?e.map(s=>s.name):Object.keys(e);q(()=>{const s=W(1,this.accBeta1),r=Z(-this.learningRate,B(D(this.iteration,this.decay),1));n.forEach((a,o)=>{const i=N.registeredVariables[a],u=!1;this.accumulatedFirstMoment[o]==null&&(this.accumulatedFirstMoment[o]={originalName:`${a}/m`,variable:Te(i).variable(u)}),this.accumulatedWeightedInfNorm[o]==null&&(this.accumulatedWeightedInfNorm[o]={originalName:`${a}/v`,variable:Te(i).variable(u)});const c=Array.isArray(e)?e[o].tensor:e[a];if(c==null)return;const h=this.accumulatedFirstMoment[o].variable,l=this.accumulatedWeightedInfNorm[o].variable,f=B(D(h,this.beta1),D(c,1-this.beta1)),m=D(l,this.beta2),b=Se(c),T=Mr(m,b);h.assign(f),l.assign(T);const S=B(D(Z(r,s),Z(f,B(T,this.epsilon))),i);i.assign(S)}),this.iteration.assign(B(this.iteration,1)),this.accBeta1.assign(D(this.accBeta1,this.beta1))}),this.incrementIterations()}dispose(){this.accBeta1.dispose(),this.iteration.dispose(),this.accumulatedFirstMoment!=null&&me(this.accumulatedFirstMoment.map(e=>e.variable)),this.accumulatedWeightedInfNorm!=null&&me(this.accumulatedWeightedInfNorm.map(e=>e.variable))}async getWeights(){throw new Error("getWeights() is not implemented for Adamax yet.")}async setWeights(e){throw new Error("setWeights() is not implemented for Adamax yet.")}getConfig(){return{learningRate:this.learningRate,beta1:this.beta1,beta2:this.beta2,epsilon:this.epsilon,decay:this.decay}}static fromConfig(e,n){return new e(n.learningRate,n.beta1,n.beta2,n.epsilon,n.decay)}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class ws extends ht{static get className(){return"SGD"}constructor(e){super(),this.learningRate=e,this.setLearningRate(e)}applyGradients(e){(Array.isArray(e)?e.map(s=>s.name):Object.keys(e)).forEach((s,r)=>{const a=Array.isArray(e)?e[r].tensor:e[s];if(a==null)return;const o=N.registeredVariables[s];q(()=>{const i=B(D(this.c,a),o);o.assign(i)})}),this.incrementIterations()}setLearningRate(e){this.learningRate=e,this.c!=null&&this.c.dispose(),this.c=Oe(M(-e))}dispose(){this.c.dispose()}async getWeights(){return[await this.saveIterations()]}async setWeights(e){if(e=await this.extractIterations(e),e.length!==0)throw new Error("SGD optimizer does not have settable weights.")}getConfig(){return{learningRate:this.learningRate}}static fromConfig(e,n){return new e(n.learningRate)}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class ha extends ws{static get className(){return"Momentum"}constructor(e,n,s=!1){super(e),this.learningRate=e,this.momentum=n,this.useNesterov=s,this.accumulations=[],this.m=M(this.momentum)}applyGradients(e){(Array.isArray(e)?e.map(s=>s.name):Object.keys(e)).forEach((s,r)=>{const a=N.registeredVariables[s];this.accumulations[r]==null&&(this.accumulations[r]={originalName:`${s}/momentum`,variable:q(()=>Te(a).variable(!1))});const o=this.accumulations[r].variable,i=Array.isArray(e)?e[r].tensor:e[s];i!=null&&q(()=>{let u;const c=B(D(this.m,o),i);this.useNesterov?u=B(D(this.c,B(i,D(c,this.m))),a):u=B(D(this.c,c),a),o.assign(c),a.assign(u)})}),this.incrementIterations()}dispose(){this.m.dispose(),this.accumulations!=null&&me(this.accumulations.map(e=>e.variable))}setMomentum(e){this.momentum=e}async getWeights(){return[await this.saveIterations()].concat(this.accumulations.map(e=>({name:e.originalName,tensor:e.variable})))}async setWeights(e){e=await this.extractIterations(e);const n=!1;this.accumulations=e.map(s=>({originalName:s.name,variable:s.tensor.variable(n)}))}getConfig(){return{learningRate:this.learningRate,momentum:this.momentum,useNesterov:this.useNesterov}}static fromConfig(e,n){return new e(n.learningRate,n.momentum,n.useNesterov)}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class pa extends ht{static get className(){return"RMSProp"}constructor(e,n=.9,s=0,r=null,a=!1){if(super(),this.learningRate=e,this.decay=n,this.momentum=s,this.epsilon=r,this.accumulatedMeanSquares=[],this.accumulatedMoments=[],this.accumulatedMeanGrads=[],this.centered=a,r==null&&(this.epsilon=N.backend.epsilon()),e==null)throw new Error("learningRate for RMSPropOptimizer must be defined.")}applyGradients(e){(Array.isArray(e)?e.map(s=>s.name):Object.keys(e)).forEach((s,r)=>{const a=N.registeredVariables[s],o=!1;this.accumulatedMeanSquares[r]==null&&(this.accumulatedMeanSquares[r]={originalName:`${s}/rms`,variable:q(()=>Te(a).variable(o))}),this.accumulatedMoments[r]==null&&(this.accumulatedMoments[r]={originalName:`${s}/momentum`,variable:q(()=>Te(a).variable(o))}),this.accumulatedMeanGrads[r]==null&&this.centered&&(this.accumulatedMeanGrads[r]={originalName:`${s}/mg`,variable:q(()=>Te(a).variable(o))});const i=Array.isArray(e)?e[r].tensor:e[s];if(i==null)return;const u=this.accumulatedMeanSquares[r].variable,c=this.accumulatedMoments[r].variable;q(()=>{const h=B(D(u,this.decay),D(Ie(i),1-this.decay));if(this.centered){const l=this.accumulatedMeanGrads[r].variable,f=B(D(l,this.decay),D(i,1-this.decay)),m=Z(D(i,this.learningRate),ze(W(h,B(Ie(f),this.epsilon)))),b=B(D(c,this.momentum),m);u.assign(h),l.assign(f),c.assign(b);const T=W(a,b);a.assign(T)}else{const l=B(D(u,this.decay),D(Ie(i),1-this.decay)),f=B(D(c,this.momentum),Z(D(i,this.learningRate),ze(B(l,this.epsilon))));u.assign(l),c.assign(f);const m=W(a,f);a.assign(m)}})}),this.incrementIterations()}dispose(){this.accumulatedMeanSquares!=null&&me(this.accumulatedMeanSquares.map(e=>e.variable)),this.accumulatedMeanGrads!=null&&this.centered&&me(this.accumulatedMeanGrads.map(e=>e.variable)),this.accumulatedMoments!=null&&me(this.accumulatedMoments.map(e=>e.variable))}async getWeights(){const e=[...this.accumulatedMeanSquares,...this.accumulatedMoments];return this.centered&&e.push(...this.accumulatedMeanGrads),[await this.saveIterations()].concat(e.map(n=>({name:n.originalName,tensor:n.variable})))}async setWeights(e){e=await this.extractIterations(e);const n=this.centered?e.length/3:e.length/2,s=!1;this.accumulatedMeanSquares=e.slice(0,n).map(r=>({originalName:r.name,variable:r.tensor.variable(s)})),this.accumulatedMoments=e.slice(n,n*2).map(r=>({originalName:r.name,variable:r.tensor.variable(s)})),this.centered&&(this.accumulatedMeanGrads=e.slice(n*2,n*3).map(r=>({originalName:r.name,variable:r.tensor.variable(s)})))}getConfig(){return{learningRate:this.learningRate,decay:this.decay,momentum:this.momentum,epsilon:this.epsilon,centered:this.centered}}static fromConfig(e,n){return new e(n.learningRate,n.decay,n.momentum,n.epsilon,n.centered)}}/**
 * @license
 * Copyright 2022 Google LLC.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const m1=[ia,ua,ca,la,ha,pa,ws];function g1(){for(const t of m1)ap(t)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const y1="model",b1=".json",w1=".weights.bin";function Pa(t){return new Promise(e=>setTimeout(e)).then(t)}class vt{constructor(e){if(!P().getBool("IS_BROWSER"))throw new Error("browserDownloads() cannot proceed because the current environment is not a browser.");e.startsWith(vt.URL_SCHEME)&&(e=e.slice(vt.URL_SCHEME.length)),(e==null||e.length===0)&&(e=y1),this.modelJsonFileName=e+b1,this.weightDataFileName=e+w1}async save(e){if(typeof document>"u")throw new Error("Browser downloads are not supported in this environment since `document` is not present");const n=Re.join(e.weightData),s=window.URL.createObjectURL(new Blob([n],{type:"application/octet-stream"}));if(e.modelTopology instanceof ArrayBuffer)throw new Error("BrowserDownloads.save() does not support saving model topology in binary formats yet.");{const r=[{paths:["./"+this.weightDataFileName],weights:e.weightSpecs}],a=Tc(e,r),o=window.URL.createObjectURL(new Blob([JSON.stringify(a)],{type:"application/json"})),i=this.modelJsonAnchor==null?document.createElement("a"):this.modelJsonAnchor;if(i.download=this.modelJsonFileName,i.href=o,await Pa(()=>i.dispatchEvent(new MouseEvent("click"))),e.weightData!=null){const u=this.weightDataAnchor==null?document.createElement("a"):this.weightDataAnchor;u.download=this.weightDataFileName,u.href=s,await Pa(()=>u.dispatchEvent(new MouseEvent("click")))}return{modelArtifactsInfo:bn(e)}}}}vt.URL_SCHEME="downloads://";class N1{constructor(e){if(e==null||e.length<1)throw new Error(`When calling browserFiles, at least 1 file is required, but received ${e}`);this.jsonFile=e[0],this.weightsFiles=e.slice(1)}async load(){return new Promise((e,n)=>{const s=new FileReader;s.onload=r=>{const a=JSON.parse(r.target.result),o=a.modelTopology;if(o==null){n(new Error(`modelTopology field is missing from file ${this.jsonFile.name}`));return}if(a.weightsManifest==null){n(new Error(`weightManifest field is missing from file ${this.jsonFile.name}`));return}if(this.weightsFiles.length===0){e({modelTopology:o});return}const u=Nr(a,c=>this.loadWeights(c));e(u)},s.onerror=r=>n(`Failed to read model topology and weights manifest JSON from file '${this.jsonFile.name}'. BrowserFiles supports loading Keras-style tf.Model artifacts only.`),s.readAsText(this.jsonFile)})}loadWeights(e){const n=[],s=[];for(const o of e)n.push(...o.weights),s.push(...o.paths);const r=this.checkManifestAndWeightFiles(e),a=s.map(o=>this.loadWeightsFile(o,r[o]));return Promise.all(a).then(o=>[n,o])}loadWeightsFile(e,n){return new Promise((s,r)=>{const a=new FileReader;a.onload=o=>{const i=o.target.result;s(i)},a.onerror=o=>r(`Failed to weights data from file of path '${e}'.`),a.readAsArrayBuffer(n)})}checkManifestAndWeightFiles(e){const n=[],s=this.weightsFiles.map(a=>_a(a.name)),r={};for(const a of e)a.paths.forEach(o=>{const i=_a(o);if(n.indexOf(i)!==-1)throw new Error(`Duplicate file basename found in weights manifest: '${i}'`);if(n.push(i),s.indexOf(i)===-1)throw new Error(`Weight file with basename '${i}' is not provided.`);r[o]=this.weightsFiles[s.indexOf(i)]});if(n.length!==this.weightsFiles.length)throw new Error(`Mismatch in the number of files in weights manifest (${n.length}) and the number of weight files provided (${this.weightsFiles.length}).`);return r}}const S1=t=>P().getBool("IS_BROWSER")&&!Array.isArray(t)&&t.startsWith(vt.URL_SCHEME)?T1(t.slice(vt.URL_SCHEME.length)):null;Q.registerSaveRouter(S1);function T1(t="model"){return new vt(t)}function $1(t){return new N1(t)}/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function za(t,e,n,s){o(t),n=n??0,s=s??1,i(n,s);let r=0;const a=u=>(u.then(c=>{const h=n+ ++r/t.length*(s-n);return e(h),c}),u);function o(u){g(u!=null&&Array.isArray(u)&&u.length>0,()=>"promises must be a none empty array")}function i(u,c){g(u>=0&&u<=1,()=>`Progress fraction must be in range [0, 1], but got startFraction ${u}`),g(c>=0&&c<=1,()=>`Progress fraction must be in range [0, 1], but got endFraction ${c}`),g(c>=u,()=>`startFraction must be no more than endFraction, but got startFraction ${u} and endFraction ${c}`)}return Promise.all(t.map(a))}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */async function op(t,e){e==null&&(e={});const n=e.fetchFunc==null?P().platform.fetch:e.fetchFunc,s=t.map(l=>n(l,e.requestInit,{isBinary:!0})),i=(e.onProgress==null?await Promise.all(s):await za(s,e.onProgress,0,.5)).map(l=>l.arrayBuffer());return e.onProgress==null?await Promise.all(i):await za(i,e.onProgress,.5,1)}function E1(t,e){var n;const s=e.fetchFunc==null?P().platform.fetch:e.fetchFunc;let r=0,a;return(n=e.onProgress)===null||n===void 0||n.call(e,0),new ReadableStream({pull:async o=>{for(var i;r<t.length;){a||(a=(await s(t[r],e.requestInit,{isBinary:!0})).body.getReader());const{done:u,value:c}=await a.read();if(u){r++,a=void 0,(i=e.onProgress)===null||i===void 0||i.call(e,r/t.length);continue}o.enqueue(c);return}o.close()}})}async function k1(t,e="",n,s){return ip(o=>op(o,{requestInit:s}))(t,e,n)}function ip(t){return async(e,n="",s)=>{const r=e.map(()=>!1),a={},o=s!=null?s.map(()=>!1):[],i=[];if(e.forEach((m,b)=>{let T=0;m.weights.forEach(S=>{const $="quantization"in S?S.quantization.dtype:S.dtype,O=St[$]*G(S.shape),v=()=>{r[b]=!0,a[b]==null&&(a[b]=[]),a[b].push({manifestEntry:S,groupOffset:T,sizeBytes:O})};s!=null?s.forEach((_,A)=>{_===S.name&&(v(),o[A]=!0)}):v(),i.push(S.name),T+=O})}),!o.every(m=>m)){const m=s.filter((b,T)=>!o[T]);throw new Error(`Could not find weights in manifest with names: ${m.join(", ")}. 
Manifest JSON has weights with names: ${i.join(", ")}.`)}const u=r.reduce((m,b,T)=>(b&&m.push(T),m),[]),c=[];u.forEach(m=>{e[m].paths.forEach(b=>{const T=n+(n.endsWith("/")?"":"/")+b;c.push(T)})});const h=await t(c),l={};let f=0;return u.forEach(m=>{const b=e[m].paths.length,T=new Re(h.slice(f,f+b));a[m].forEach($=>{const O=T.slice($.groupOffset,$.groupOffset+$.sizeBytes),v=wc(O,[$.manifestEntry]);for(const _ in v)l[_]=v[_]}),f+=b}),l}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const v1="application/octet-stream",_1="application/json";class fa{constructor(e,n){if(this.DEFAULT_METHOD="POST",n==null&&(n={}),this.weightPathPrefix=n.weightPathPrefix,this.weightUrlConverter=n.weightUrlConverter,n.fetchFunc!=null?(g(typeof n.fetchFunc=="function",()=>"Must pass a function that matches the signature of `fetch` (see https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)"),this.fetch=n.fetchFunc):this.fetch=P().platform.fetch,g(e!=null&&e.length>0,()=>"URL path for http must not be null, undefined or empty."),Array.isArray(e)&&g(e.length===2,()=>`URL paths for http must have a length of 2, (actual length is ${e.length}).`),this.path=e,n.requestInit!=null&&n.requestInit.body!=null)throw new Error("requestInit is expected to have no pre-existing body, but has one.");this.requestInit=n.requestInit||{},this.loadOptions=n}async save(e){if(e.modelTopology instanceof ArrayBuffer)throw new Error("BrowserHTTPRequest.save() does not support saving model topology in binary formats yet.");const n=Object.assign({method:this.DEFAULT_METHOD},this.requestInit);n.body=new FormData;const s=[{paths:["./model.weights.bin"],weights:e.weightSpecs}],r=Tc(e,s);if(n.body.append("model.json",new Blob([JSON.stringify(r)],{type:_1}),"model.json"),e.weightData!=null){const o=Re.join(e.weightData);n.body.append("model.weights.bin",new Blob([o],{type:v1}),"model.weights.bin")}const a=await this.fetch(this.path,n);if(a.ok)return{modelArtifactsInfo:bn(e),responses:[a]};throw new Error(`BrowserHTTPRequest.save() failed due to HTTP response status ${a.status}.`)}async loadModelJSON(){const e=await this.fetch(this.path,this.requestInit);if(!e.ok)throw new Error(`Request to ${this.path} failed with status code ${e.status}. Please verify this URL points to the model JSON of the model to load.`);let n;try{n=await e.json()}catch{let o=`Failed to parse model JSON of response from ${this.path}.`;throw this.path.endsWith(".pb")?o+=" Your path contains a .pb file extension. Support for .pb models have been removed in TensorFlow.js 1.0 in favor of .json models. You can re-convert your Python TensorFlow model using the TensorFlow.js 1.0 conversion scripts or you can convert your.pb models with the 'pb2json'NPM script in the tensorflow/tfjs-converter repository.":o+=" Please make sure the server is serving valid JSON for this request.",new Error(o)}const s=n.modelTopology,r=n.weightsManifest;if(s==null&&r==null)throw new Error(`The JSON from HTTP path ${this.path} contains neither model topology or manifest for weights.`);return n}async load(){if(this.loadOptions.streamWeights)return this.loadStream();const e=await this.loadModelJSON();return Nr(e,n=>this.loadWeights(n))}async loadStream(){const e=await this.loadModelJSON(),n=await this.getWeightUrls(e.weightsManifest),s=Kn(e.weightsManifest),r=()=>E1(n,this.loadOptions);return Object.assign(Object.assign({},e),{weightSpecs:s,getWeightStream:r})}async getWeightUrls(e){const n=Array.isArray(this.path)?this.path[1]:this.path,[s,r]=I1(n),a=this.weightPathPrefix||s,o=[],i=[];for(const u of e)for(const c of u.paths)this.weightUrlConverter!=null?i.push(this.weightUrlConverter(c)):o.push(a+c+r);return this.weightUrlConverter&&o.push(...await Promise.all(i)),o}async loadWeights(e){const n=await this.getWeightUrls(e),s=Kn(e),r=await op(n,this.loadOptions);return[s,r]}}fa.URL_SCHEME_REGEX=/^https?:\/\//;function I1(t){const e=t.lastIndexOf("/"),n=t.lastIndexOf("?"),s=t.substring(0,e),r=n>e?t.substring(n):"";return[s+"/",r]}function Hs(t){return t.match(fa.URL_SCHEME_REGEX)!=null}const up=(t,e)=>{if(typeof fetch>"u"&&(e==null||e.fetchFunc==null))return null;{let n=!0;if(Array.isArray(t)?n=t.every(s=>Hs(s)):n=Hs(t),n)return da(t,e)}return null};Q.registerSaveRouter(up);Q.registerLoadRouter(up);function da(t,e){return new fa(t,e)}function x1(t,e){return da(t,e)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class vs{constructor(e){this.modelArtifacts=e}load(){return this.modelArtifacts}}class cp{constructor(e){this.saveHandler=e}save(e){return this.saveHandler(e)}}class A1{constructor(e){e.load&&(this.load=()=>Promise.resolve(e.load())),e.save&&(this.save=n=>Promise.resolve(e.save(n)))}}function O1(t,e,n,s){const r=arguments;return new A1(Qn(...r))}function Qn(t,e,n,s){return arguments.length===1?t.modelTopology!=null||t.weightSpecs!=null?new vs(t):(console.warn("Please call tf.io.fromMemory() with only one argument. The argument should be of type ModelArtifacts. The multi-argument signature of tf.io.fromMemory() has been deprecated and will be removed in a future release."),new vs({modelTopology:t})):(console.warn("Please call tf.io.fromMemory() with only one argument. The argument should be of type ModelArtifacts. The multi-argument signature of tf.io.fromMemory() has been deprecated and will be removed in a future release."),new vs({modelTopology:t,weightSpecs:e,weightData:n,trainingConfig:s}))}function D1(t){return new cp(t)}function F1(t){return new cp(t)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const ma=Object.freeze(Object.defineProperty({__proto__:null,CompositeArrayBuffer:Re,browserFiles:$1,browserHTTPRequest:x1,concatenateArrayBuffers:vd,copyModel:Kd,decodeWeights:wc,decodeWeightsStream:Sc,encodeWeights:Nd,fromMemory:O1,fromMemorySync:Qn,getLoadHandlers:Cd,getModelArtifactsForJSON:Nr,getModelArtifactsForJSONSync:wr,getModelArtifactsInfoForJSON:bn,getSaveHandlers:Fd,getWeightSpecs:Kn,http:da,isHTTPScheme:Hs,listModels:Gd,loadWeights:k1,moveModel:Xd,registerLoadRouter:Dd,registerSaveRouter:Od,removeModel:Hd,weightsLoaderFactory:ip,withSaveHandler:D1,withSaveHandlerSync:F1},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function C1(t,e,n){const s=d(t,"labels","confusionMatrix"),r=d(e,"predictions","confusionMatrix");g(n==null||n>0&&Number.isInteger(n),()=>`If provided, numClasses must be a positive integer, but got ${n}`),g(s.rank===1,()=>`Expected the rank of labels to be 1, but got ${s.rank}`),g(r.rank===1,()=>`Expected the rank of predictions to be 1, but got ${r.rank}`),g(s.shape[0]===r.shape[0],()=>`Mismatch in the number of examples: ${s.shape[0]} vs. ${r.shape[0]}. Labels and predictions should have the same number of elements.`),g(n>0&&Number.isInteger(n),()=>`numClasses is required to be a positive integer, but got ${n}`);const a=Yn(J(s,"int32"),n),o=Yn(J(r,"int32"),n),i=fn(a),u=j(i,o);return J(u,"int32")}const R1=w({confusionMatrix_:C1});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const L1=Object.freeze(Object.defineProperty({__proto__:null,confusionMatrix:R1},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */let pt,Va=!1;function lp(t,e=3){if(e>4)throw new Error("Cannot construct Tensor with more than 4 channels from pixels.");if(t==null)throw new Error("pixels passed to tf.browser.fromPixels() can not be null");let n=!1,s=!1,r=!1,a=!1,o=!1,i=!1;if(t.data instanceof Uint8Array)n=!0;else if(typeof ImageData<"u"&&t instanceof ImageData)s=!0;else if(typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement)r=!0;else if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement)a=!0;else if(t.getContext!=null)o=!0;else if(typeof ImageBitmap<"u"&&t instanceof ImageBitmap)i=!0;else throw new Error(`pixels passed to tf.browser.fromPixels() must be either an HTMLVideoElement, HTMLImageElement, HTMLCanvasElement, ImageData in browser, or OffscreenCanvas, ImageData in webworker or {data: Uint32Array, width: number, height: number}, but was ${t.constructor.name}`);if(tn(xs,N.backendName)!=null){const b={pixels:t},T={numChannels:e};return N.runKernel(xs,b,T)}const[c,h]=r?[t.videoWidth,t.videoHeight]:[t.width,t.height];let l;if(o)l=t.getContext("2d").getImageData(0,0,c,h).data;else if(s||n)l=t.data;else if(a||r||i){if(pt==null)if(typeof document>"u")if(typeof OffscreenCanvas<"u"&&typeof OffscreenCanvasRenderingContext2D<"u")pt=new OffscreenCanvas(1,1).getContext("2d");else throw new Error("Cannot parse input in current context. Reason: OffscreenCanvas Context2D rendering is not supported.");else pt=document.createElement("canvas").getContext("2d",{willReadFrequently:!0});pt.canvas.width=c,pt.canvas.height=h,pt.drawImage(t,0,0,c,h),l=pt.getImageData(0,0,c,h).data}let f;if(e===4)f=new Int32Array(l);else{const b=c*h;f=new Int32Array(b*e);for(let T=0;T<b;T++)for(let S=0;S<e;++S)f[T*e+S]=l[T*4+S]}return na(f,[h,c,e],"int32")}function B1(t){return t!=null&&t.data instanceof Uint8Array}function P1(){return typeof window<"u"&&typeof ImageBitmap<"u"&&window.hasOwnProperty("createImageBitmap")}function z1(t){return t!=null&&t.width!==0&&t.height!==0}function V1(t){return P1()&&!(t instanceof ImageBitmap)&&z1(t)&&!B1(t)}async function W1(t,e=3){let n=null;if(P().getBool("WRAP_TO_IMAGEBITMAP")&&V1(t)){let s;try{s=await createImageBitmap(t,{premultiplyAlpha:"none"})}catch{s=null}s!=null&&s.width===t.width&&s.height===t.height?n=s:n=t}else n=t;return lp(n,e)}function hp(t){if(t.rank!==2&&t.rank!==3)throw new Error(`toPixels only supports rank 2 or 3 tensors, got rank ${t.rank}.`);const e=t.rank===2?1:t.shape[2];if(e>4||e===2)throw new Error(`toPixels only supports depth of size 1, 3 or 4 but got ${e}`);if(t.dtype!=="float32"&&t.dtype!=="int32")throw new Error(`Unsupported type for toPixels: ${t.dtype}. Please use float32 or int32 tensors.`)}function M1(t){const e=(t==null?void 0:t.alpha)||1;if(e>1||e<0)throw new Error(`Alpha value ${e} is suppoed to be in range [0 - 1].`)}async function U1(t,e){let n=d(t,"img","toPixels");if(!(t instanceof ne)){const c=n;n=J(c,"int32"),c.dispose()}hp(n);const[s,r]=n.shape.slice(0,2),a=n.rank===2?1:n.shape[2],o=await n.data(),i=n.dtype==="float32"?255:1,u=new Uint8ClampedArray(r*s*4);for(let c=0;c<s*r;++c){const h=[0,0,0,255];for(let f=0;f<a;f++){const m=o[c*a+f];if(n.dtype==="float32"){if(m<0||m>1)throw new Error(`Tensor values for a float32 Tensor must be in the range [0 - 1] but encountered ${m}.`)}else if(n.dtype==="int32"&&(m<0||m>255))throw new Error(`Tensor values for a int32 Tensor must be in the range [0 - 255] but encountered ${m}.`);a===1?(h[0]=m*i,h[1]=m*i,h[2]=m*i):h[f]=m*i}const l=c*4;u[l+0]=Math.round(h[0]),u[l+1]=Math.round(h[1]),u[l+2]=Math.round(h[2]),u[l+3]=Math.round(h[3])}if(e!=null){Va||tn(pr,N.backendName)!=null&&(console.warn("tf.browser.toPixels is not efficient to draw tensor on canvas. Please try tf.browser.draw instead."),Va=!0),e.width=r,e.height=s;const c=e.getContext("2d"),h=new ImageData(u,r,s);c.putImageData(h,0,0)}return n!==t&&n.dispose(),u}function j1(t,e,n){let s=d(t,"img","draw");if(!(t instanceof ne)){const o=s;s=J(o,"int32"),o.dispose()}hp(s),M1(n==null?void 0:n.imageOptions);const r={image:s},a={canvas:e,options:n};N.runKernel(pr,r,a)}const q1=w({fromPixels_:lp}),G1=Object.freeze(Object.defineProperty({__proto__:null,draw:j1,fromPixels:q1,fromPixelsAsync:W1,toPixels:U1},Symbol.toStringTag,{value:"Module"}));function pp(t,e){const n=t.shape.length,s=e.shape.length;if(n<1)throw new Error(`tf.gatherND() expects the input to be rank 1 or higher, but the rank was ${n}.`);if(s<1)throw new Error(`tf.gatherND() expects the indices to be rank 1 or higher, but the rank was ${s}.`);if(e.dtype!=="int32")throw new Error(`tf.gatherND() expects the indices to be int32 type, but the dtype was ${e.dtype}.`);if(e.shape[s-1]>n)throw new Error(`index innermost dimension length must be <= tensor rank; saw: ${e.shape[s-1]} vs. ${n}`);if(G(t.shape)===0)throw new Error(`Requested more than 0 entries, but input is empty. Input shape: ${t.shape}.`);const r=e.shape,a=r[r.length-1];let o=1;for(let l=0;l<r.length-1;++l)o*=r[l];const i=t.shape,u=r.slice();u.pop();let c=1;for(let l=a;l<n;++l)c*=i[l],u.push(i[l]);const h=[...Ut(t.shape).map(l=>l/c),1].slice(0,a);return[u,o,c,h]}const H1=Object.freeze(Object.defineProperty({__proto__:null,prepareAndValidate:pp},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const Ks=-2,K1=-1;function X1(t,e,n){const s=t.shape.length;g(s===e.length,()=>`Error in slice${s}D: Length of begin ${e} must match the rank of the array (${s}).`),g(s===n.length,()=>`Error in slice${s}D: Length of size ${n} must match the rank of the array (${s}).`);for(let r=0;r<s;++r)g(e[r]+n[r]<=t.shape[r],()=>`Error in slice${s}D: begin[${r}] + size[${r}] (${e[r]+n[r]}) would overflow input.shape[${r}] (${t.shape[r]})`)}function Z1(t){const e=[];let n=0;for(;t>0;)t&1&&e.push(n),t/=2,n++;return e}function J1(t,e,n){const s=[];for(let r=0;r<t.length;r++)s[r]=Math.ceil((e[r]-t[r])/n[r]);return s}function fp(t,e,n,s){const r=[...t];for(let a=r.length;a<s.length;a++)r.push(1);for(let a=0;a<n;a++)a===0?r[e]=1:(r.splice(e,0,1),r.pop());return r}function dp(t,e,n){return n<=t?n:n-(e-1)}function mp(t,e){const n=[];for(let s=0;s<t;s++)n.push(e+s);return n}function Y1(t,e,n,s,r,a,o,i,u){const c=t.length;let h=new Array(c),l=new Array(c),f=new Array(c);if(e.length&&n>0){const m=e[0],b=n+1;h=gp(o,m,b,s,t),l=yp(i,m,b,r,t),f=fp(a,m,b,t)}else for(let m=0;m<c;m++)h[m]=wp(o,s,a,t,m,u),l[m]=Np(i,r,a,t,m,u),f[m]=bp(a,m,u);return{begin:h,end:l,strides:f}}function gp(t,e,n,s,r){const a=[...r],o=mp(n,e);for(let i=0;i<a.length;i++)if(o.indexOf(i)>-1)a[i]=0;else{const u=dp(e,n,i);let c=s[u];t&1<<u&&(c=0),a[i]=c}return a}function yp(t,e,n,s,r){const a=[...r],o=mp(n,e);for(let i=0;i<a.length;i++)if(o.indexOf(i)>-1)a[i]=Number.MAX_SAFE_INTEGER;else{const u=dp(e,n,i);let c=s[u];t&1<<u&&(c=Number.MAX_SAFE_INTEGER),a[i]=c}for(let i=0;i<a.length;i++){const u=r[i];a[i]<0&&(a[i]+=u),a[i]=Qt(0,a[i],r[i])}return a}function bp(t,e,n){let s=t[e];return(n&1<<e||s==null)&&(s=1),s}function wp(t,e,n,s,r,a){let o=e[r];const i=n[r]||1;(t&1<<r||a&1<<r||o==null)&&(i>0?o=Number.MIN_SAFE_INTEGER:o=Number.MAX_SAFE_INTEGER);const u=s[r];return o<0&&(o+=u),o=Qt(0,o,u-1),o}function Np(t,e,n,s,r,a){let o=e[r];const i=n[r]||1;(t&1<<r||a&1<<r||o==null)&&(i>0?o=Number.MAX_SAFE_INTEGER:o=Number.MIN_SAFE_INTEGER);const u=s[r];return o<0&&(o+=u),i>0?o=Qt(0,o,u):o=Qt(-1,o,u-1),o}function Q1(t,e,n){let s=n.length;for(let r=0;r<n.length;r++)if(n[r]>1){s=r;break}for(let r=s+1;r<n.length;r++)if(e[r]>0||n[r]!==t[r])return!1;return!0}function eN(t,e){let n=t.length>0?t[t.length-1]:1;for(let s=0;s<t.length-1;s++)n+=t[s]*e[s];return n}function tN(t,e,n){let s;const r=t.shape.length;typeof e=="number"?s=[e,...new Array(r-1).fill(0)]:e.length<r?s=e.concat(new Array(r-e.length).fill(0)):s=e.slice(),s.forEach(o=>{g(o!==-1,()=>"slice() does not support negative begin indexing.")});let a;return n==null?a=new Array(r).fill(-1):typeof n=="number"?a=[n,...new Array(r-1).fill(-1)]:n.length<r?a=n.concat(new Array(r-n.length).fill(-1)):a=n,a=a.map((o,i)=>o>=0?o:(g(o===-1,()=>`Negative size values should be exactly -1 but got ${o} for the slice() size at index ${i}.`),t.shape[i]-s[i])),[s,a]}function nN(t,e,n,s,r,a,o,i,u){let c;if(s==null?(c=new Array(e.length),c.fill(1)):c=s,o!=null&&(o&o-1)!==0)throw new Error("Multiple ellipses in slice is not allowed.");let h=!1;const l={dims:c.length,numAddAxisAfterEllipsis:0,begin:e.slice(),end:n.slice(),strides:c.slice(),beginMask:r,endMask:a,ellipsisMask:o,newAxisMask:i,shrinkAxisMask:u};for(let v=0;v<l.dims;v++)h&&(1<<v&i)!==0&&l.numAddAxisAfterEllipsis++,1<<v&o&&(h=!0);h||(l.ellipsisMask|=1<<l.dims,l.dims++);const f={dims:t.length,beginMask:0,endMask:0,beginValid:!1,endValid:!1};sN(l,f);let m=!0,b=!0,T=!0;const S=[],$=[];for(let v=0;v<t.length;++v){if(f.strides[v]===0)throw Error(`strides[${v}] must be non-zero`);const _=!!(f.shrinkAxisMask&1<<v),A=t[v];if(A===-1){S.push(_?1:-1);continue}const F=[f.beginMask&1<<v,f.endMask&1<<v],L=[f.strides[v]>0?0:-1,f.strides[v]>0?A:A-1];if(_&&f.strides[v]<=0)throw Error("only stride 1 allowed on non-range indexing.");T=T&&f.strides[v]===1;const C=!!(f.beginMask&1<<v&&f.endMask&1<<v);if(f.beginValid&&f.endValid){if(_){const x=f.begin[v]<0?A+f.begin[v]:f.begin[v];if(f.begin[v]=x,f.end[v]=f.begin[v]+1,x<0||x>=A)throw Error(`slice index ${f.begin[v]} of dimension ${v} out of bounds.`)}else f.begin[v]=Wa(f.begin[v],0,f.strides[v],A,F,L),f.end[v]=Wa(f.end[v],1,f.strides[v],A,F,L);const y=f.strides[v]===1&&f.begin[v]===0&&f.end[v]===A;m=m&&y,b=b&&(v===0&&f.strides[v]===1||y)}else m=m&&f.strides[v]===1&&C,b=b&&(v===0&&f.strides[v]===1||C);let k,E=!1;if(f.beginValid&&f.endValid?(k=f.end[v]-f.begin[v],E=!0):_?(k=1,E=!0):C&&A>=0&&(f.strides[v]<0?k=-A:k=A,E=!0),E){let y;k===0||k<0!=f.strides[v]<0?y=0:y=Math.trunc(k/f.strides[v])+(k%f.strides[v]!==0?1:0),S.push(y)}else S.push(-1)}for(let v=0;v<f.finalShapeGatherIndices.length;++v){const _=f.finalShapeGatherIndices[v];_>=0?$.push(S[_]):_===Ks&&$.push(1)}return{finalShapeSparse:$.filter((v,_)=>f.finalShapeGatherIndices[_]!==Ks),finalShape:$,isIdentity:m,sliceDim0:b,isSimpleSlice:T,begin:f.begin,end:f.end,strides:f.strides}}function sN(t,e){e.beginMask=0,e.endMask=0,e.shrinkAxisMask=0;let n=0;e.beginValid=t.begin!=null,e.endValid=t.end!=null,e.begin=new Array(e.dims),e.end=new Array(e.dims),e.strides=new Array(e.dims),e.finalShapeGatherIndices=[],e.finalShapeGatherIndicesSparse=[],e.inputShapeGatherIndicesSparse=new Array(e.dims);for(let s=0;s<t.dims;s++)if(1<<s&t.ellipsisMask){const r=Math.min(e.dims-(t.dims-s)+1+t.numAddAxisAfterEllipsis,e.dims);for(;n<r;n++)e.begin[n]=0,e.end[n]=0,e.strides[n]=1,e.beginMask|=1<<n,e.endMask|=1<<n,e.finalShapeGatherIndices.push(n),e.finalShapeGatherIndicesSparse.push(-1),e.inputShapeGatherIndicesSparse[n]=s}else if(1<<s&t.newAxisMask)e.finalShapeGatherIndices.push(Ks),e.finalShapeGatherIndicesSparse.push(-1);else{if(n===e.begin.length)throw Error(`Index out of range using input dim ${n}; input has only ${e.dims} dims, ${e.begin.length}.`);t.begin!=null&&(e.begin[n]=t.begin[s]),t.end!=null&&(e.end[n]=t.end[s]),e.strides[n]=t.strides[s],t.beginMask&1<<s&&(e.beginMask|=1<<n),t.endMask&1<<s&&(e.endMask|=1<<n),t.shrinkAxisMask&1<<s?(e.finalShapeGatherIndices.push(K1),e.finalShapeGatherIndicesSparse.push(-1),e.shrinkAxisMask|=1<<n):(e.finalShapeGatherIndices.push(n),e.finalShapeGatherIndicesSparse.push(s)),e.inputShapeGatherIndicesSparse[n]=s,n++}}function Wa(t,e,n,s,r,a){if(r[e])return n>0?a[e]:a[e+1&1];{const o=t<0?s+t:t;return o<a[0]?a[0]:o>a[1]?a[1]:o}}const Sp=Object.freeze(Object.defineProperty({__proto__:null,assertParamsValid:X1,computeFlatOffset:eN,computeOutShape:J1,getNormalizedAxes:Y1,isSliceContinous:Q1,maskToAxes:Z1,parseSliceParams:tN,sliceInfo:nN,startForAxis:wp,startIndicesWithElidedDims:gp,stopForAxis:Np,stopIndicesWithElidedDims:yp,stridesForAxis:bp,stridesWithElidedDims:fp},Symbol.toStringTag,{value:"Module"}));/** @license See the LICENSE file. */const rN="4.22.0";/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class Tp{static sgd(e){return new ws(e)}static momentum(e,n,s=!1){return new ha(e,n,s)}static rmsprop(e,n=.9,s=0,r=null,a=!1){return new pa(e,n,s,r,a)}static adam(e=.001,n=.9,s=.999,r=null){return new ca(e,n,s,r)}static adadelta(e=.001,n=.95,s=null){return new ia(e,n,s)}static adamax(e=.002,n=.9,s=.999,r=null,a=0){return new la(e,n,s,r,a)}static adagrad(e,n=.1){return new ua(e,n)}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const aN=Tp;/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const oN=typeof requestAnimationFrame<"u"?requestAnimationFrame:typeof setImmediate<"u"?setImmediate:t=>t();function iN(){return new Promise(t=>oN(()=>t()))}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function uN(t,e){const n=t[0].length;t.forEach((r,a)=>{g(r.length===n,()=>`Error in concat${n}D: rank of tensors[${a}] must be the same as the rank of the rest (${n})`)}),g(e>=0&&e<n,()=>`Error in concat${n}D: axis must be between 0 and ${n-1}.`);const s=t[0];t.forEach((r,a)=>{for(let o=0;o<n;o++)g(o===e||r[o]===s[o],()=>`Error in concat${n}D: Shape of tensors[${a}] (${r}) does not match the shape of the rest (${s}) along the non-concatenated axis ${a}.`)})}function cN(t,e){const n=t[0].slice();for(let s=1;s<t.length;s++)n[e]+=t[s][e];return n}/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */var Le;(function(t){t[t.FIRST_DIM_SIZE=0]="FIRST_DIM_SIZE",t[t.VALUE_ROWIDS=1]="VALUE_ROWIDS",t[t.ROW_LENGTHS=2]="ROW_LENGTHS",t[t.ROW_SPLITS=3]="ROW_SPLITS",t[t.ROW_LIMITS=4]="ROW_LIMITS",t[t.ROW_STARTS=5]="ROW_STARTS"})(Le||(Le={}));function lN(t,e,n){let s=new Array;if(n==null&&e==null)return s;if(e==null)for(;s.length<t+n.length;)s.push(-1);else s=e.slice();if(n==null)return s;if(t+n.length!==s.length)throw new Error(`rt input.shape and shape=${e} are incompatible: rt input.rank = ${t+n.length}, but shape.rank = ${s.length}`);for(let r=1;r<n.length;++r){const a=n[r],o=s[s.length-n.length+r],i=s[o];if(a>=0)if(i>=0){if(i!==a)throw new Error(`rt input.shape and shape=${e} are incompatible: rt input.shape[${r+t}] = ${a} but shape[${r+t}] = ${i}`)}else s[o]=a}return s}function hN(t){const e={FIRST_DIM_SIZE:Le.FIRST_DIM_SIZE,VALUE_ROWIDS:Le.VALUE_ROWIDS,ROW_LENGTHS:Le.ROW_LENGTHS,ROW_SPLITS:Le.ROW_SPLITS,ROW_LIMITS:Le.ROW_LIMITS,ROW_STARTS:Le.ROW_STARTS},n=[];for(const s of t)if(s in e)n.push(e[s]);else break;return n}function pN(t){return t.length===0?0:t[0]===Le.FIRST_DIM_SIZE?t.length-1:t.length}function fN(t,e){if(t==null||e==null)return;const n=t.length,s=e.length;if(n>=s)throw new Error(`defaultValue.shape=${t} and ragged tensor flatValues.shape=${e}, are incompatible: defaultValue.rank = ${n} must be less than ragged tensor input flatValues.rank = ${s})`);for(let r=0;r<Math.min(n,s-1);++r){const a=t[r],o=e[r+1];if(a>=0&&o>=0&&a!==1&&a!==o)throw new Error(`defaultValue.shape=${t}, and ragged tensor input flatValues.shape=${e} are incompatible: defaultValue.shape[${r-t.length}] = ${a} but ragged tensor input.flatValues.shape[${r-t.length}] = ${o}`)}}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const ga=30;function dN(t){return t<=ga?t:jn(t,Math.floor(Math.sqrt(t)))}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function mN(t,e,n){const s=n*(typeof t=="number"?t:t[0]),r=e*(typeof t=="number"?t:t[1]);return[s,r]}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function gN(t,e,n,s=!0){let r=[];if(s)r=r.concat(e.slice(0)),r.push(t[0]/n),r=r.concat(t.slice(1));else{r=r.concat(t[0]);const a=e.length;for(let o=0;o<a;++o)r=r.concat([t[o+1]/e[o],e[o]]);r=r.concat(t.slice(a+1))}return r}function yN(t,e,n=!0){const s=[];if(n){s.push(e);for(let r=e+1;r<t;++r)r<=2*e?(s.push(r),s.push(r-(e+1))):s.push(r)}else{const r=[],a=[];for(let o=1;o<t;++o)o>=e*2+1||o%2===1?a.push(o):r.push(o);s.push(...r),s.push(0),s.push(...a)}return s}function bN(t,e,n,s=!0){const r=[];s?r.push(t[0]/n):r.push(t[0]*n);for(let a=1;a<t.length;++a)a<=e.length?s?r.push(e[a-1]*t[a]):r.push(t[a]/e[a-1]):r.push(t[a]);return r}function wN(t,e){const n=[0];for(let s=0;s<e;++s)n.push(t[s][0]);return n}function NN(t,e,n){const s=t.slice(0,1);for(let r=0;r<n;++r)s.push(t[r+1]-e[r][0]-e[r][1]);return s}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const SN=1.7580993408473768,TN=1.0507009873554805;/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const $N=.3275911,EN=.254829592,kN=-.284496736,vN=1.421413741,_N=-1.453152027,IN=1.061405429;/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function xN(t,e){if(t.length!==e.length)throw new Error(`Cannot merge real and imag arrays of different lengths. real:${t.length}, imag: ${e.length}.`);const n=new Float32Array(t.length*2);for(let s=0;s<n.length;s+=2)n[s]=t[s/2],n[s+1]=e[s/2];return n}function AN(t){const e=new Float32Array(t.length/2),n=new Float32Array(t.length/2);for(let s=0;s<t.length;s+=2)e[s/2]=t[s],n[s/2]=t[s+1];return{real:e,imag:n}}function ON(t){const e=Math.ceil(t.length/4),n=new Float32Array(e),s=new Float32Array(e);for(let r=0;r<t.length;r+=4)n[Math.floor(r/4)]=t[r],s[Math.floor(r/4)]=t[r+1];return{real:n,imag:s}}function DN(t){const e=Math.floor(t.length/4),n=new Float32Array(e),s=new Float32Array(e);for(let r=2;r<t.length;r+=4)n[Math.floor(r/4)]=t[r],s[Math.floor(r/4)]=t[r+1];return{real:n,imag:s}}function FN(t,e){const n=t[e*2],s=t[e*2+1];return{real:n,imag:s}}function CN(t,e,n,s){t[s*2]=e,t[s*2+1]=n}function RN(t,e){const n=new Float32Array(t/2),s=new Float32Array(t/2);for(let r=0;r<Math.ceil(t/2);r++){const a=(e?2:-2)*Math.PI*(r/t);n[r]=Math.cos(a),s[r]=Math.sin(a)}return{real:n,imag:s}}function LN(t,e,n){const s=(n?2:-2)*Math.PI*(t/e),r=Math.cos(s),a=Math.sin(s);return{real:r,imag:a}}/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const _s="->",BN=/->/g,Ma=",",Ua="...";function PN(t,e){t=t.replace(/\s/g,"");const n=(t.length-t.replace(BN,"").length)/_s.length;if(n<1)throw new Error("Equations without an arrow are not supported.");if(n>1)throw new Error(`Equation must contain exactly one arrow ("${_s}").`);const[s,r]=t.split(_s);g(s.indexOf(Ua)===-1,()=>`The ellipsis notation ("${Ua}") is not supported yet.`);const a=s.split(Ma),o=a.length;if(e!==o)throw new Error(`Expected ${o} input tensors, received ${e}`);if(o>2)throw new Error("Support for more than 2 input tensors is not implemented yet.");const i=[];for(let f=0;f<r.length;++f){const m=r[f];if(!a.some(b=>b.indexOf(m)!==-1))throw new Error(`Output subscripts contain the label ${m} not present in the input subscripts.`);i.indexOf(m)===-1&&i.push(m)}for(let f=0;f<s.length;++f){const m=s[f];i.indexOf(m)===-1&&m!==Ma&&i.push(m)}const u=new Array(a.length);for(let f=0;f<o;++f){if(new Set(a[f].split("")).size!==a[f].length)throw new Error(`Found duplicate axes in input component ${a[f]}. Support for duplicate axes in input is not implemented yet.`);u[f]=[];for(let m=0;m<a[f].length;++m)u[f].push(i.indexOf(a[f][m]))}const c=i.length,h=r.length,l=[];for(let f=h;f<c;++f)l.push(f);return{allDims:i,summedDims:l,idDims:u}}function zN(t,e){let n=new Array(t);n.fill(-1);for(let r=0;r<e.length;++r)n[e[r]]=r;const s=[];for(let r=0;r<t;++r)n[r]===-1&&s.push(r);return n=n.filter(r=>r!==-1),{permutationIndices:n,expandDims:s}}function VN(t,e,n){const s=new Array(t);for(let r=0;r<n.length;++r){const a=n[r].shape;for(let o=0;o<e[r].length;++o)s[e[r][o]]===void 0?s[e[r][o]]=a[o]:g(s[e[r][o]]===a[o],()=>`Expected dimension ${s[e[r][o]]} at axis ${o} of input shaped ${JSON.stringify(a)}, but got dimension ${a[o]}`)}}function WN(t,e){const n=t,s=[];let r=0;t.length===0&&n.push(-1),r=t.length+1;for(let o=0;o<r;++o)s.push([]);const a=[];for(let o=0;o<n.length;++o){const i=n[o],u=UN(e,i);for(const c of u)a.indexOf(c)===-1&&(s[o].push(c),a.push(c))}return{path:n,steps:s}}function MN(t){return t.every((e,n)=>e===n)}function UN(t,e){const n=[];for(let s=0;s<t.length;++s)(t[s].length===0||t[s].indexOf(e)!==-1||e===-1)&&n.push(s);return n}function jN(t,e,n=0){let s=[];if(typeof e=="number")g(t.shape[n]%e===0,()=>"Number of splits must evenly divide the axis."),s=new Array(e).fill(t.shape[n]/e);else{const r=e.reduce((o,i)=>(i===-1&&(o+=1),o),0);g(r<=1,()=>"There should be only one negative value in split array.");const a=e.indexOf(-1);if(a!==-1){const o=e.reduce((i,u)=>u>0?i+u:i);e[a]=t.shape[n]-o}g(t.shape[n]===e.reduce((o,i)=>o+i),()=>"The sum of sizes must match the size of the axis dimension."),s=e}return s}/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function qN(t){return`Received SparseTensor with denseShape[0] = 0 but
  indices.shape[0] = ${t}`}function GN(t,e){return`indices(${t}, 0) is invalid: ${e} < 0`}function HN(t,e,n){return`indices(${t}, 0) is invalid: ${e} >= ${n}`}/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function KN(t,e){return`only one output dimension may be -1, not both ${t} and ${e}`}function XN(t,e){return`size ${t} must be non-negative, not ${e}`}function ZN(){return"reshape cannot infer the missing input size for an empty tensor unless all specified input sizes are non-zero"}function JN(t,e){const n=G(t),s=G(e);return`Input to reshape is a SparseTensor with ${n}
  dense values, but the requested shape requires a multiple of ${s}. inputShape=${t} outputShape= ${e}`}function YN(t,e){const n=G(t),s=G(e);return`Input to reshape is a tensor with ${n} dense values, but the requested shape has ${s}. inputShape=${t} outputShape=${e}`}/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function QN(){return"segment ids must be >= 0"}function eS(){return"segment ids are not increasing"}function tS(t,e){return`Segment id ${t} out of range [0, ${e}), possibly because segmentIds input is not sorted.`}function nS(t,e,n){return`Bad: indices[${t}] == ${e} out of range [0, ${n})`}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function sS(t,e){let n=!1,s;for(t<=ga?(s=t,n=!0):s=jn(t,Math.floor(Math.sqrt(t)));!n;)s>e||s===t?n=!0:s=jn(t,s+1);return s}function rS(t,e,n){const s=[],r=t.length;for(let a=0;a<r;a++)a!==e?s.push(t[a]):s.push(n);return s}function aS(t,e,n,s){const r=e.shape.length,a=t.shape.length;if(s!==0&&(s<-r||s>r))throw new Error(`Expect batchDims in the range of [-${r}, ${r}], but got ${s}`);if(s<0&&(s+=r),s>a)throw new Error(`batchDims (${s}) must be less than rank(x) (
    ${a}).`);if(n<s)throw new Error(`batchDims (${s}) must be less than or equal to axis (${n}).`);for(let l=0;l<s;++l)if(t.shape[l]!==e.shape[l])throw new Error(`x.shape[${l}]: ${t.shape[l]} should be equal to indices.shape[${l}]: ${e.shape[l]}.`);const o=t.shape[n],i=[];let u=1,c=1,h=1;for(let l=0;l<s;++l)i.push(t.shape[l]),u*=t.shape[l];for(let l=s;l<n;l++)i.push(t.shape[l]),c*=t.shape[l];for(let l=s;l<r;l++)i.push(e.shape[l]);for(let l=n+1;l<a;l++)i.push(t.shape[l]),h*=t.shape[l];return{batchSize:u,sliceSize:h,outerSize:c,dimSize:o,outputShape:i}}const oS=Object.freeze(Object.defineProperty({__proto__:null,collectGatherOpShapeInfo:aS,computeOutShape:rS,segOpComputeOptimalWindowSize:sS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function iS(t){try{return t.map(e=>Gn(e))}catch(e){throw new Error(`Failed to decode encoded string bytes into utf-8, error: ${e}`)}}function uS(t){return t.map(e=>yn(e))}const cS=Object.freeze(Object.defineProperty({__proto__:null,ERF_A1:EN,ERF_A2:kN,ERF_A3:vN,ERF_A4:_N,ERF_A5:IN,ERF_P:$N,PARALLELIZE_THRESHOLD:ga,get RowPartitionType(){return Le},SELU_SCALE:TN,SELU_SCALEALPHA:SN,applyActivation:ys,assertAndGetBroadcastShape:re,assertAxesAreInnerMostDims:Eg,assertParamsConsistent:uN,assignToTypedArray:CN,axesAreInnerMostDims:Ar,calculateShapes:xh,checkEinsumDimSizes:VN,checkPadOnDimRoundingMode:xe,combineLocations:Tl,combineRaggedTensorToTensorShapes:lN,complexWithEvenIndex:ON,complexWithOddIndex:DN,computeConv2DInfo:wn,computeConv3DInfo:Uc,computeDefaultPad:$r,computeDilation2DInfo:wm,computeOptimalWindowSize:dN,computeOutAndReduceShapes:$g,computeOutShape:cN,computePool2DInfo:Mc,computePool3DInfo:Nm,convertConv2DDataFormat:jc,decodeEinsumEquation:PN,eitherStridesOrDilationsAreOne:Xe,expandShapeToKeepDim:Tn,exponent:LN,exponents:RN,fromStringArrayToUint8:uS,fromUint8ToStringArray:iS,getAxesPermutation:kg,getBroadcastDims:yl,getComplexWithIndex:FN,getEinsumComputePath:WN,getEinsumPermutation:zN,getFusedBiasGradient:gs,getFusedDyActivation:ms,getImageCenter:mN,getInnerMostAxes:_g,getPermuted:yN,getRaggedRank:pN,getReductionAxes:_r,getReshaped:gN,getReshapedPermuted:bN,getRowPartitionTypesHelper:hN,getSliceBeginCoords:wN,getSliceSize:NN,getSparseFillEmptyRowsIndicesDenseShapeMismatch:qN,getSparseFillEmptyRowsNegativeIndexErrorMessage:GN,getSparseFillEmptyRowsOutOfRangeIndexErrorMessage:HN,getSparseReshapeEmptyTensorZeroOutputDimErrorMessage:ZN,getSparseReshapeInputOutputMismatchErrorMessage:YN,getSparseReshapeInputOutputMultipleErrorMessage:JN,getSparseReshapeMultipleNegativeOneOutputDimErrorMessage:KN,getSparseReshapeNegativeOutputDimErrorMessage:XN,getSparseSegmentReductionIndicesOutOfRangeErrorMessage:nS,getSparseSegmentReductionNegativeSegmentIdsErrorMessage:QN,getSparseSegmentReductionNonIncreasingSegmentIdsErrorMessage:eS,getSparseSegmentReductionSegmentIdOutOfRangeErrorMessage:tS,getUndoAxesPermutation:vg,isIdentityPermutation:MN,log:Nf,mergeRealAndImagArrays:xN,prepareAndValidate:pp,prepareSplitSize:jN,segment_util:oS,shouldFuse:bs,slice_util:Sp,splitRealAndImagArrays:AN,stridesOrDilationsArePositive:Et,tupleValuesAreOne:un,upcastType:rs,validateDefaultValueShape:fN,validateInput:fs,validateUpdateShape:sa,warn:Je},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const lS=Object.freeze(Object.defineProperty({__proto__:null,nonMaxSuppressionV3Impl:Kh,nonMaxSuppressionV4Impl:Xh,nonMaxSuppressionV5Impl:Zh,whereImpl:Bh},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */g1();const PT=Object.freeze(Object.defineProperty({__proto__:null,Abs:po,Acos:fo,Acosh:mo,AdadeltaOptimizer:ia,AdagradOptimizer:ua,AdamOptimizer:ca,AdamaxOptimizer:la,Add:lr,AddN:go,All:yo,Any:bo,ArgMax:wo,ArgMin:No,Asin:So,Asinh:To,Atan:$o,Atan2:ko,Atanh:Eo,AvgPool:vo,AvgPool3D:_o,AvgPool3DGrad:tf,AvgPoolGrad:ef,BatchMatMul:Io,BatchToSpaceND:xo,Bincount:Ao,BitwiseAnd:Oo,BroadcastArgs:Do,BroadcastTo:nf,Cast:hr,Ceil:Fo,ClipByValue:Co,Complex:Ro,ComplexAbs:Lo,Concat:Bo,Conv2D:Po,Conv2DBackpropFilter:zo,Conv2DBackpropInput:Vo,Conv3D:Wo,Conv3DBackpropFilterV2:sf,Conv3DBackpropInputV2:Mo,Cos:Uo,Cosh:jo,CropAndResize:Ho,Cumprod:qo,Cumsum:Go,DataStorage:Dp,DenseBincount:Ko,DepthToSpace:Xo,DepthwiseConv2dNative:Zo,DepthwiseConv2dNativeBackpropFilter:Jo,DepthwiseConv2dNativeBackpropInput:Yo,Diag:Qo,Dilation2D:ei,Dilation2DBackpropFilter:af,Dilation2DBackpropInput:rf,Draw:pr,get ENV(){return ur},Einsum:ni,Elu:si,EluGrad:of,Environment:lo,Equal:ai,Erf:ri,Exp:oi,ExpandDims:ii,Expm1:ui,FFT:ci,Fill:li,FlipLeftRight:hi,Floor:pi,FloorDiv:fi,FromPixels:xs,FusedBatchNorm:di,FusedConv2D:Os,FusedDepthwiseConv2D:Ds,GatherNd:gi,GatherV2:mi,Greater:yi,GreaterEqual:bi,IFFT:wi,Identity:fr,Imag:Ni,IsFinite:Si,IsInf:Ti,IsNan:$i,KernelBackend:Qa,LRN:Fi,LRNGrad:hf,LeakyRelu:Ei,Less:ki,LessEqual:vi,LinSpace:_i,Log:Ii,Log1p:xi,LogSoftmax:cf,LogicalAnd:Ai,LogicalNot:Oi,LogicalOr:Di,LogicalXor:uf,LowerBound:lf,MatrixBandPart:pf,Max:Ci,MaxPool:Li,MaxPool3D:Bi,MaxPool3DGrad:df,MaxPoolGrad:ff,MaxPoolWithArgmax:Pi,Maximum:Ri,Mean:zi,Min:Vi,Minimum:Wi,MirrorPad:Mi,Mod:Ui,MomentumOptimizer:ha,Multinomial:ji,Multiply:qi,Neg:Gi,NonMaxSuppressionV3:Ki,NonMaxSuppressionV4:Xi,NonMaxSuppressionV5:Zi,NotEqual:Hi,OP_SCOPE_SUFFIX:yr,OneHot:Yi,OnesLike:Ji,Optimizer:ht,OptimizerConstructors:Tp,Pack:Qi,PadV2:eu,Pool:mf,Pow:tu,Prelu:nu,Prod:su,RMSPropOptimizer:pa,RaggedGather:ru,RaggedRange:au,RaggedTensorToTensor:ou,Range:iu,get Rank(){return Rs},Real:uu,RealDiv:ti,Reciprocal:cu,get Reduction(){return de},Relu:lu,Relu6:du,Reshape:hu,ResizeBilinear:fu,ResizeBilinearGrad:yf,ResizeNearestNeighbor:pu,ResizeNearestNeighborGrad:gf,Reverse:mu,RotateWithOffset:tc,Round:gu,Rsqrt:yu,SGDOptimizer:ws,ScatterNd:bu,SearchSorted:Nu,Select:Su,Selu:Tu,Sigmoid:_u,Sign:vu,Sin:Eu,Sinh:ku,Slice:$u,Softmax:Fu,Softplus:Iu,SpaceToBatchND:Ou,SparseFillEmptyRows:Cu,SparseReshape:Ru,SparseSegmentMean:Lu,SparseSegmentSum:Bu,SparseToDense:Pu,SplitV:Du,Sqrt:xu,Square:bf,SquaredDifference:zu,StaticRegexReplace:Vu,Step:ec,StridedSlice:Wu,StringNGrams:Mu,StringSplit:Uu,StringToHashBucketFast:ju,Sub:qu,Sum:Au,Tan:Gu,Tanh:Hu,Tensor:ne,TensorBuffer:Hn,TensorScatterUpdate:wu,Tile:dr,TopK:Ku,Transform:Xu,Transpose:On,Unique:Zu,Unpack:Ju,UnsortedSegmentSum:Yu,UpperBound:wf,Variable:sn,ZerosLike:Qu,_FusedMatMul:As,abs:Se,acos:Ac,acosh:Oc,add:B,addN:Dc,all:Fc,any:Cc,argMax:Rc,argMin:Lc,asin:Bc,asinh:Pc,atan:zc,atan2:Vc,atanh:Wc,avgPool:Er,avgPool3d:qc,backend:bc,backend_util:cS,basicLSTMCell:Gc,batchNorm:Nn,batchNorm2d:Hc,batchNorm3d:Kc,batchNorm4d:Xc,batchToSpaceND:kr,bincount:vr,bitwiseAnd:Zc,booleanMaskAsync:Ph,broadcastArgs:Jc,broadcastTo:Yt,broadcast_util:fg,browser:G1,buffer:Pe,cast:J,ceil:Yc,clipByValue:Qc,clone:Ge,complex:Ke,concat:he,concat1d:el,concat2d:tl,concat3d:nl,concat4d:sl,conv1d:rl,conv2d:Sn,conv2dTranspose:ol,conv3d:il,conv3dTranspose:ul,copyRegisteredKernels:Ef,cos:cl,cosh:ll,cosineWindow:ds,cumprod:hl,cumsum:pl,customGrad:Ve,denseBincount:fl,deprecationWarn:id,depthToSpace:dl,depthwiseConv2d:as,device_util:td,diag:ml,dilation2d:gl,disableDeprecationWarnings:od,dispose:me,disposeVariables:ud,div:Z,divNoNan:bl,dot:wl,dropout:Uh,einsum:mt,elu:xr,enableDebugMode:ad,enableProdMode:rd,enclosingPowerOfTwo:aa,engine:cd,ensureShape:Nl,env:P,equal:Ir,erf:Sl,euclideanNorm:El,exp:it,expandDims:Me,expm1:kl,eye:Or,fft:ls,fill:jt,findBackend:gd,findBackendFactory:yd,floor:Dr,floorDiv:Tr,fused:qh,gather:Fr,gatherND:Mh,gather_util:H1,getBackend:yc,getGradient:Fs,getKernel:tn,getKernelsForBackend:qn,grad:ty,grads:ny,greater:En,greaterEqual:Cr,ifft:pn,imag:kn,image:Qh,inTopKAsync:jh,io:ma,irfft:Qr,isFinite:vl,isInf:_l,isNaN:Il,keep:Oe,kernel_impls:lS,leakyRelu:Rr,less:Jn,lessEqual:os,linalg:ep,linspace:xl,localResponseNormalization:Al,log:zt,log1p:Lr,logSigmoid:Dl,logSoftmax:Fl,logSumExp:Pr,logicalAnd:cn,logicalNot:zr,logicalOr:Vr,logicalXor:Cl,losses:tp,lowerBound:Rl,matMul:j,math:L1,max:Nt,maxPool:Wr,maxPool3d:Ll,maxPoolWithArgmax:Bl,maximum:Mr,mean:ln,memory:ld,meshgrid:Pl,min:Zn,minimum:hn,mirrorPad:zl,mod:Vl,moments:Wl,movingAverage:zh,mul:D,multiRNNCell:Ml,multinomial:Ul,neg:Fe,nextFrame:iN,norm:$n,notEqual:Ur,oneHot:Yn,ones:tt,onesLike:jl,op:w,outerProduct:ql,pad:qt,pad1d:Gl,pad2d:Hl,pad3d:Kl,pad4d:Xl,pool:Zl,pow:Pt,prelu:qr,print:Sr,prod:Jl,profile:hd,raggedGather:Yl,raggedRange:Ql,raggedTensorToTensor:eh,rand:th,randomGamma:rh,randomNormal:Zr,randomStandardNormal:ah,randomUniform:cs,randomUniformInt:oh,range:Vt,ready:dd,real:Wt,reciprocal:ih,registerBackend:bd,registerGradient:Sf,registerKernel:nc,relu:vn,relu6:Jr,removeBackend:md,reshape:I,reverse:ut,reverse1d:uh,reverse2d:ch,reverse3d:lh,reverse4d:hh,rfft:hs,round:Yr,rsqrt:ph,scalar:M,scatterND:Vh,scatter_util:o0,searchSorted:us,selu:fh,separableConv2d:dh,serialization:d1,setBackend:fd,setPlatform:wd,setdiff1dAsync:mh,sigmoid:wt,sign:gh,signal:Yh,sin:yh,sinh:bh,slice:H,slice1d:wh,slice2d:Nh,slice3d:Sh,slice4d:Th,slice_util:Sp,softmax:$h,softplus:Br,spaceToBatchND:jr,sparse:np,sparseToDense:Wh,spectral:Jh,split:Mt,sqrt:ze,square:Ie,squaredDifference:ea,squeeze:ps,stack:We,step:ta,stridedSlice:Eh,string:sp,sub:W,sum:X,sumOutType:Gf,tan:kh,tanh:Xn,tensor:De,tensor1d:ke,tensor2d:Ct,tensor3d:na,tensor4d:vh,tensor5d:_h,tensor6d:Ih,tensorScatterUpdate:Ah,tensor_util:Xf,test_util:wb,tidy:q,tile:Ft,time:pd,topk:Oh,train:aN,transpose:fn,truncatedNormal:Dh,unique:Fh,unregisterGradient:$f,unregisterKernel:Tf,unsortedSegmentSum:Ch,unstack:lt,upcastType:rs,upperBound:Rh,util:Rf,valueAndGrad:sy,valueAndGrads:ry,variable:Lh,variableGrads:Ol,version_core:rN,where:He,whereAsync:ra,zeros:kt,zerosLike:Te},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const hS=P();hS.registerFlag("KEEP_INTERMEDIATE_TENSORS",()=>!1,t=>{t&&console.warn("Keep intermediate tensors is ON. This will print the values of all intermediate tensors during model inference. Not all models support this mode. For details, check e2e/benchmarks/ model_config.js. This significantly impacts performance.")});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * =============================================================================
 */var we;(function(t){t[t.DT_INVALID=0]="DT_INVALID",t[t.DT_FLOAT=1]="DT_FLOAT",t[t.DT_DOUBLE=2]="DT_DOUBLE",t[t.DT_INT32=3]="DT_INT32",t[t.DT_UINT8=4]="DT_UINT8",t[t.DT_INT16=5]="DT_INT16",t[t.DT_INT8=6]="DT_INT8",t[t.DT_STRING=7]="DT_STRING",t[t.DT_COMPLEX64=8]="DT_COMPLEX64",t[t.DT_INT64=9]="DT_INT64",t[t.DT_BOOL=10]="DT_BOOL",t[t.DT_QINT8=11]="DT_QINT8",t[t.DT_QUINT8=12]="DT_QUINT8",t[t.DT_QINT32=13]="DT_QINT32",t[t.DT_BFLOAT16=14]="DT_BFLOAT16",t[t.DT_QINT16=15]="DT_QINT16",t[t.DT_QUINT16=16]="DT_QUINT16",t[t.DT_UINT16=17]="DT_UINT16",t[t.DT_COMPLEX128=18]="DT_COMPLEX128",t[t.DT_HALF=19]="DT_HALF",t[t.DT_RESOURCE=20]="DT_RESOURCE",t[t.DT_VARIANT=21]="DT_VARIANT",t[t.DT_UINT32=22]="DT_UINT32",t[t.DT_UINT64=23]="DT_UINT64",t[t.DT_FLOAT_REF=101]="DT_FLOAT_REF",t[t.DT_DOUBLE_REF=102]="DT_DOUBLE_REF",t[t.DT_INT32_REF=103]="DT_INT32_REF",t[t.DT_UINT8_REF=104]="DT_UINT8_REF",t[t.DT_INT16_REF=105]="DT_INT16_REF",t[t.DT_INT8_REF=106]="DT_INT8_REF",t[t.DT_STRING_REF=107]="DT_STRING_REF",t[t.DT_COMPLEX64_REF=108]="DT_COMPLEX64_REF",t[t.DT_INT64_REF=109]="DT_INT64_REF",t[t.DT_BOOL_REF=110]="DT_BOOL_REF",t[t.DT_QINT8_REF=111]="DT_QINT8_REF",t[t.DT_QUINT8_REF=112]="DT_QUINT8_REF",t[t.DT_QINT32_REF=113]="DT_QINT32_REF",t[t.DT_BFLOAT16_REF=114]="DT_BFLOAT16_REF",t[t.DT_QINT16_REF=115]="DT_QINT16_REF",t[t.DT_QUINT16_REF=116]="DT_QUINT16_REF",t[t.DT_UINT16_REF=117]="DT_UINT16_REF",t[t.DT_COMPLEX128_REF=118]="DT_COMPLEX128_REF",t[t.DT_HALF_REF=119]="DT_HALF_REF",t[t.DT_RESOURCE_REF=120]="DT_RESOURCE_REF",t[t.DT_VARIANT_REF=121]="DT_VARIANT_REF",t[t.DT_UINT32_REF=122]="DT_UINT32_REF",t[t.DT_UINT64_REF=123]="DT_UINT64_REF"})(we||(we={}));var ja;(function(t){(function(e){e[e.LEGACY=0]="LEGACY",e[e.V1=1]="V1",e[e.V2=2]="V2"})(t.CheckpointFormatVersion||(t.CheckpointFormatVersion={}))})(ja||(ja={}));/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const ya={};function zT(t,e){const n={tfOpName:t,category:"custom",inputs:[],attrs:[],customExecutor:e};ya[t]=n}function $p(t){return ya[t]}function VT(t){delete ya[t]}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function p(t,e,n,s,r){const a=e.inputParams[t];if(a&&a.inputIndexStart!==void 0){const i=a.inputIndexStart,u=a.inputIndexEnd===0?void 0:a.inputIndexEnd===void 0?i+1:a.inputIndexEnd,c=i<0?e.inputNames.length+i:i;if(a.type==="tensor")return ce(e.inputNames[c],n,s,r);if(a.type==="tensors"){const f=e.inputs.slice(i,u);return e.inputNames.slice(i,u).filter((b,T)=>{var S;return((S=f[T])===null||S===void 0?void 0:S.op)!=="NoOp"}).map(b=>ce(b,n,s,r))}const h=ce(e.inputNames[c],n,s,r),l=h.dataSync();return a.type==="number"?l[0]:bt(h.shape,l)}const o=e.attrParams[t];return o&&o.value}function ce(t,e,n,s){const[r,a]=Ne(t,n);if(s!=null){const i=s.getHashTableHandleByName(r);if(i!=null)return i}const o=n.currentContextIds.find(i=>!!e[es(r,i)]);return o!==void 0?e[es(r,o)][a]:void 0}function qa(t,e,n){return e[es(t,n.currentContextId)]}function Ue(t,e){const[n,s,r]=Ne(t,e);return[es(n,e&&e.currentContextId),s,r]}function es(t,e){return e?`${t}-${e}`:t}function Ne(t,e){if(t==="")return["",0,void 0];const n=e!=null&&e.parseNodeNameCache!=null;if(n){const a=e.parseNodeNameCache.get(t);if(a!=null)return a}const s=t.split(":");let r;if(s.length===1)r=[t,0,void 0];else{const a=s[0],o=s.length===3?s[1]:void 0,i=Number(s[s.length-1]);r=[a,i,o]}return n&&e.parseNodeNameCache.set(t,r),r}function Wn(t,e,n){let s=p("pad",t,e,n);if(s==="explicit"){s=p("explicitPaddings",t,e,n);const r=[[0,0],[0,0],[0,0],[0,0]];for(let a=0;a<4;a++)r[a][0]=s[a*2],r[a][1]=s[a*2+1];return r}return s}function je(t){return t.kept?t:Ge(t)}/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const pS=[{tfOpName:"Add",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"AddV2",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"AddN",category:"arithmetic",inputs:[{start:0,end:0,name:"tensors",type:"tensors"}]},{tfOpName:"BiasAdd",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0},{tfName:"data_format",name:"dataFormat",type:"string",notSupported:!0}]},{tfOpName:"Sub",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"RealDiv",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Div",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"DivNoNan",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"FloorDiv",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Mul",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Maximum",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Minimum",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Pow",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"SquaredDifference",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Mod",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"FloorMod",category:"arithmetic",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]}],fS=Object.freeze(Object.defineProperty({__proto__:null,json:pS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const dS=[{tfOpName:"Abs",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Acos",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Asin",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Atan",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Atan2",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"y",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Ceil",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"ClipByValue",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"clipValueMin",type:"number"},{start:2,name:"clipValueMax",type:"number"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Complex",category:"basic_math",inputs:[{start:0,name:"real",type:"tensor"},{start:1,name:"imag",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"ComplexAbs",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Cos",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Cosh",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Elu",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Exp",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Floor",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Log",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Imag",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0},{tfName:"Tout",name:"outputType",type:"dtype",notSupported:!0}]},{tfOpName:"Neg",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Real",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0},{tfName:"Tout",name:"outputType",type:"dtype",notSupported:!0}]},{tfOpName:"Prelu",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"alpha",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Relu",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Relu6",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Selu",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Sigmoid",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Sin",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Sinh",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Sqrt",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Rsqrt",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Square",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Tan",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Tanh",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Sign",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Round",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Expm1",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Log1p",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Reciprocal",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Softplus",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Asinh",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Acosh",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Atanh",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Erf",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"LeakyRelu",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"alpha",name:"alpha",type:"number",defaultValue:.2},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"IsNan",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"IsFinite",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"IsInf",category:"basic_math",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]}],mS=Object.freeze(Object.defineProperty({__proto__:null,json:dS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const gS=[{tfOpName:"EmptyTensorList",category:"control",inputs:[{start:0,name:"elementShape",type:"shape"},{start:1,name:"maxNumElements",type:"number"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"LoopCond",category:"control",inputs:[{start:0,name:"pred",type:"tensor"}]},{tfOpName:"Switch",category:"control",inputs:[{start:0,name:"data",type:"tensor"},{start:1,name:"pred",type:"tensor"}]},{tfOpName:"Merge",category:"control",inputs:[{start:0,end:0,name:"tensors",type:"tensors"}]},{tfOpName:"Enter",category:"control",inputs:[{start:0,name:"tensor",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0},{tfName:"frame_name",name:"frameName",type:"string"},{tfName:"is_constant",name:"isConstant",type:"bool"}]},{tfOpName:"Exit",category:"control",inputs:[{start:0,name:"tensor",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"NextIteration",category:"control",inputs:[{start:0,name:"tensor",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"TensorArrayV3",category:"control",inputs:[{start:0,name:"size",type:"number"}],attrs:[{tfName:"dtype",name:"dtype",type:"dtype"},{tfName:"element_shape",name:"elementShape",type:"shape"},{tfName:"dynamic_size",name:"dynamicSize",type:"bool"},{tfName:"clear_after_read",name:"clearAfterRead",type:"bool"},{tfName:"identical_element_shapes",name:"identicalElementShapes",type:"bool"},{tfName:"tensor_array_name",name:"name",type:"string"}]},{tfOpName:"TensorArrayWriteV3",category:"control",inputs:[{start:0,name:"tensorArrayId",type:"tensor"},{start:1,name:"index",type:"number"},{start:2,name:"tensor",type:"tensor"},{start:3,name:"flowIn",type:"number"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"TensorArrayReadV3",category:"control",inputs:[{start:0,name:"tensorArrayId",type:"tensor"},{start:1,name:"index",type:"number"},{start:2,name:"flowIn",type:"number"}],attrs:[{tfName:"dtype",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"TensorArrayGatherV3",category:"control",inputs:[{start:0,name:"tensorArrayId",type:"tensor"},{start:1,name:"indices",type:"number[]"},{start:2,name:"flowIn",type:"number"}],attrs:[{tfName:"dtype",name:"dtype",type:"dtype"},{tfName:"element_shape",name:"elementShape",type:"shape"}]},{tfOpName:"TensorArrayScatterV3",category:"control",inputs:[{start:0,name:"tensorArrayId",type:"tensor"},{start:1,name:"indices",type:"number[]"},{start:2,name:"tensor",type:"tensor"},{start:3,name:"flowIn",type:"number"}],attrs:[{tfName:"T",name:"dtype",type:"dtype"}]},{tfOpName:"TensorArrayConcatV3",category:"control",inputs:[{start:0,name:"tensorArrayId",type:"tensor"},{start:1,name:"flowIn",type:"number"}],attrs:[{tfName:"dtype",name:"dtype",type:"dtype"},{tfName:"element_shape_except0",name:"elementShapeExcept0",type:"shape",notSupported:!0}]},{tfOpName:"TensorArraySplitV3",category:"control",inputs:[{start:0,name:"tensorArrayId",type:"tensor"},{start:1,name:"tensor",type:"tensor"},{start:2,name:"lengths",type:"number[]"},{start:3,name:"flowIn",type:"number"}],attrs:[{tfName:"T",name:"dtype",type:"dtype"}]},{tfOpName:"TensorArraySizeV3",category:"control",inputs:[{start:0,name:"tensorArrayId",type:"tensor"},{start:1,name:"flowIn",type:"number"}]},{tfOpName:"TensorArrayCloseV3",category:"control",inputs:[{start:0,name:"tensorArrayId",type:"tensor"}]},{tfOpName:"StatelessIf",category:"control",inputs:[{start:0,name:"cond",type:"tensor"},{start:1,end:0,name:"args",type:"tensors"}],attrs:[{tfName:"then_branch",name:"thenBranch",type:"func"},{tfName:"else_branch",name:"elseBranch",type:"func"}]},{tfOpName:"If",category:"control",inputs:[{start:0,name:"cond",type:"tensor"},{start:1,end:0,name:"args",type:"tensors"}],attrs:[{tfName:"then_branch",name:"thenBranch",type:"func"},{tfName:"else_branch",name:"elseBranch",type:"func"}]},{tfOpName:"StatelessWhile",category:"control",inputs:[{start:0,end:0,name:"args",type:"tensors"}],attrs:[{tfName:"cond",name:"cond",type:"func"},{tfName:"body",name:"body",type:"func"}]},{tfOpName:"While",category:"control",inputs:[{start:0,end:0,name:"args",type:"tensors"}],attrs:[{tfName:"cond",name:"cond",type:"func"},{tfName:"body",name:"body",type:"func"}]},{tfOpName:"TensorListScatter",category:"control",inputs:[{start:0,name:"tensor",type:"tensor"},{start:1,name:"indices",type:"number[]"},{start:2,name:"elementShape",type:"shape"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListScatterV2",category:"control",inputs:[{start:0,name:"tensor",type:"tensor"},{start:1,name:"indices",type:"number[]"},{start:2,name:"elementShape",type:"shape"},{start:3,name:"numElements",type:"number"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListGather",category:"control",inputs:[{start:0,name:"tensorListId",type:"tensor"},{start:1,name:"indices",type:"number[]"},{start:2,name:"elementShape",type:"shape"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListGetItem",category:"control",inputs:[{start:0,name:"tensorListId",type:"tensor"},{start:1,name:"index",type:"number"},{start:2,name:"elementShape",type:"shape"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListSetItem",category:"control",inputs:[{start:0,name:"tensorListId",type:"tensor"},{start:1,name:"index",type:"number"},{start:2,name:"tensor",type:"tensor"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListReserve",category:"control",inputs:[{start:0,name:"elementShape",type:"shape"},{start:1,name:"numElements",type:"number"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListFromTensor",category:"control",inputs:[{start:0,name:"tensor",type:"tensor"},{start:1,name:"elementShape",type:"shape"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListStack",category:"control",inputs:[{start:0,name:"tensorListId",type:"tensor"},{start:1,name:"elementShape",type:"shape"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"},{tfName:"num_elements",name:"numElements",type:"dtype"}]},{tfOpName:"TensorListSplit",category:"control",inputs:[{start:0,name:"tensor",type:"tensor"},{start:1,name:"elementShape",type:"shape"},{start:2,name:"lengths",type:"number[]"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListConcat",category:"control",inputs:[{start:0,name:"tensorListId",type:"tensor"}],attrs:[{tfName:"element_shape",name:"elementShape",type:"shape"},{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListConcatV2",category:"control",inputs:[{start:0,name:"tensorListId",type:"tensor"}],attrs:[{tfName:"element_shape",name:"elementShape",type:"shape"},{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListPopBack",category:"control",inputs:[{start:0,name:"tensorListId",type:"tensor"},{start:1,name:"elementShape",type:"shape"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListPushBack",category:"control",inputs:[{start:0,name:"tensorListId",type:"tensor"},{start:1,name:"tensor",type:"tensor"}],attrs:[{tfName:"element_dtype",name:"elementDType",type:"dtype"}]},{tfOpName:"TensorListLength",category:"control",inputs:[{start:0,name:"tensorListId",type:"tensor"}]},{tfOpName:"TensorListResize",category:"control",inputs:[{start:0,name:"tensorListId",type:"tensor"},{start:1,name:"size",type:"number"}]}],yS=Object.freeze(Object.defineProperty({__proto__:null,json:gS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const bS=[{tfOpName:"AvgPool",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"data_format",name:"dataFormat",type:"string",notSupported:!0},{tfName:"ksize",name:"kernelSize",type:"number[]"},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"MaxPool",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"data_format",name:"dataFormat",type:"string",notSupported:!0},{tfName:"ksize",name:"kernelSize",type:"number[]"},{tfName:"explicit_paddings",name:"explicitPaddings",type:"number[]",defaultValue:[],notSupported:!0},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"MaxPoolWithArgmax",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"ksize",name:"kernelSize",type:"number[]"},{tfName:"include_batch_in_index",name:"includeBatchInIndex",type:"bool"},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"AvgPool3D",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"data_format",name:"dataFormat",type:"string",notSupported:!0},{tfName:"ksize",name:"kernelSize",type:"number[]"},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"MaxPool3D",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"data_format",name:"dataFormat",type:"string",notSupported:!0},{tfName:"ksize",name:"kernelSize",type:"number[]"},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Conv1D",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"filter",type:"tensor"}],attrs:[{tfName:"stride",name:"stride",type:"number"},{tfName:"padding",name:"pad",type:"string"},{tfName:"data_format",name:"dataFormat",type:"string",defaultValue:"NWC"},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0},{tfName:"dilation",name:"dilation",type:"number",defaultValue:1}]},{tfOpName:"Conv2D",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"filter",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0},{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"useCudnnOnGpu",name:"useCudnnOnGpu",type:"bool"},{tfName:"data_format",name:"dataFormat",type:"string",defaultValue:"NHWC"},{tfName:"explicit_paddings",name:"explicitPaddings",type:"number[]",defaultValue:[]},{tfName:"dilations",name:"dilations",type:"number[]"}]},{tfOpName:"_FusedConv2D",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"filter",type:"tensor"},{start:2,end:0,name:"args",type:"tensors"}],attrs:[{tfName:"num_args",name:"numArgs",type:"number"},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0},{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"explicit_paddings",name:"explicitPaddings",type:"number[]",defaultValue:[]},{tfName:"use_cudnn_on_gpu",name:"useCudnnOnGpu",type:"bool",defaultValue:!0},{tfName:"data_format",name:"dataFormat",type:"string",defaultValue:"NHWC"},{tfName:"dilations",name:"dilations",type:"number[]",defaultValue:[1,1,1,1]},{tfName:"fused_ops",name:"fusedOps",type:"string[]",defaultValue:[]},{tfName:"epsilon",name:"epsilon",type:"number",defaultValue:1e-4},{tfName:"leakyrelu_alpha",name:"leakyreluAlpha",type:"number",defaultValue:.2}]},{tfOpName:"Conv2DBackpropInput",category:"convolution",inputs:[{start:2,name:"x",type:"tensor"},{start:1,name:"filter",type:"tensor"},{start:0,name:"outputShape",type:"number[]"}],attrs:[{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"data_format",name:"dataFormat",type:"string",notSupported:!0},{tfName:"explicit_paddings",name:"explicitPaddings",type:"number[]",defaultValue:[]},{tfName:"dilations",name:"dilations",type:"number[]",notSupported:!0}]},{tfOpName:"DepthwiseConv2d",category:"convolution",inputs:[{start:0,name:"input",type:"tensor"},{start:1,name:"filter",type:"tensor"}],attrs:[{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"data_format",name:"dataFormat",type:"string",defaultValue:"NHWC"},{tfName:"explicit_paddings",name:"explicitPaddings",type:"number[]",defaultValue:[]},{tfName:"dilations",name:"dilations",type:"number[]"}]},{tfOpName:"DepthwiseConv2dNative",category:"convolution",inputs:[{start:0,name:"input",type:"tensor"},{start:1,name:"filter",type:"tensor"}],attrs:[{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"data_format",name:"dataFormat",type:"string",defaultValue:"NHWC"},{tfName:"explicit_paddings",name:"explicitPaddings",type:"number[]",defaultValue:[]},{tfName:"dilations",name:"dilations",type:"number[]"}]},{tfOpName:"FusedDepthwiseConv2dNative",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"filter",type:"tensor"},{start:2,end:0,name:"args",type:"tensors"}],attrs:[{tfName:"num_args",name:"numArgs",type:"number"},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0},{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"data_format",name:"dataFormat",type:"string",defaultValue:"NHWC"},{tfName:"dilations",name:"dilations",type:"number[]",defaultValue:[1,1,1,1]},{tfName:"fused_ops",name:"fusedOps",type:"string[]",defaultValue:[]},{tfName:"explicit_paddings",name:"explicitPaddings",type:"number[]",defaultValue:[]}]},{tfOpName:"Conv3D",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"filter",type:"tensor"}],attrs:[{tfName:"strides",name:"strides",type:"number[]"},{tfName:"padding",name:"pad",type:"string"},{tfName:"data_format",name:"dataFormat",type:"string",defaultValue:"NHWC"},{tfName:"dilations",name:"dilations",type:"number[]"}]},{tfOpName:"Dilation2D",category:"convolution",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"filter",type:"tensor"}],attrs:[{tfName:"strides",name:"strides",type:"number[]"},{tfName:"rates",name:"dilations",type:"number[]"},{tfName:"padding",name:"pad",type:"string"}]}],wS=Object.freeze(Object.defineProperty({__proto__:null,json:bS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const NS=[{tfOpName:"Fill",category:"creation",inputs:[{start:0,name:"shape",type:"number[]"},{start:1,name:"value",type:"number"}],attrs:[{tfName:"T",name:"dtype",type:"dtype"}]},{tfOpName:"LinSpace",category:"creation",inputs:[{start:0,name:"start",type:"number"},{start:1,name:"stop",type:"number"},{start:2,name:"num",type:"number"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"OneHot",category:"creation",inputs:[{start:0,name:"indices",type:"tensor"},{start:1,name:"depth",type:"number"},{start:2,name:"onValue",type:"number",defaultValue:1},{start:3,name:"offValue",type:"number",defaultValue:0}],attrs:[{tfName:"axis",name:"axis",type:"number",notSupported:!0},{tfName:"T",name:"dtype",type:"dtype"}]},{tfOpName:"Ones",category:"creation",inputs:[{start:0,name:"shape",type:"number[]"}],attrs:[{tfName:"T",name:"dtype",type:"dtype"}]},{tfOpName:"OnesLike",category:"creation",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"dtype",name:"dtype",type:"dtype"}]},{tfOpName:"RandomStandardNormal",category:"creation",inputs:[{start:0,name:"shape",type:"number[]"}],attrs:[{tfName:"seed",name:"seed",type:"number",defaultValue:0},{tfName:"seed2",name:"seed2",type:"number",defaultValue:0,notSupported:!0},{tfName:"dtype",name:"dtype",type:"dtype"},{tfName:"T",name:"T",type:"number",notSupported:!0}]},{tfOpName:"RandomUniform",category:"creation",inputs:[{start:0,name:"shape",type:"number[]"}],attrs:[{tfName:"minval",name:"minval",type:"number",defaultValue:0},{tfName:"maxval",name:"maxval",type:"number",defaultValue:1},{tfName:"dtype",name:"dtype",type:"dtype"},{tfName:"seed",name:"seed",type:"number",defaultValue:0},{tfName:"seed2",name:"seed2",type:"number",defaultValue:0,notSupported:!0},{tfName:"T",name:"T",type:"number",notSupported:!0}]},{tfOpName:"RandomUniformInt",category:"creation",inputs:[{start:0,name:"shape",type:"number[]"}],attrs:[{tfName:"minval",name:"minval",type:"number"},{tfName:"maxval",name:"maxval",type:"number"},{tfName:"seed",name:"seed",type:"number",defaultValue:0},{tfName:"seed2",name:"seed2",type:"number",defaultValue:0,notSupported:!0}]},{tfOpName:"Range",category:"creation",inputs:[{start:0,name:"start",type:"number"},{start:1,name:"stop",type:"number"},{start:2,name:"step",type:"number",defaultValue:0}],attrs:[{tfName:"Tidx",name:"dtype",type:"dtype"}]},{tfOpName:"TruncatedNormal",category:"creation",inputs:[{start:0,name:"shape",type:"number[]"}],attrs:[{tfName:"means",name:"mean",type:"number",defaultValue:0},{tfName:"stddev",name:"stdDev",type:"number",defaultValue:1},{tfName:"seed",name:"seed",type:"number"},{tfName:"seed2",name:"seed2",type:"number",defaultValue:0,notSupported:!0},{tfName:"dtype",name:"dtype",type:"dtype"},{tfName:"T",name:"T",type:"number",notSupported:!0}]},{tfOpName:"Zeros",category:"creation",inputs:[{start:0,name:"shape",type:"number[]"}],attrs:[{tfName:"T",name:"dtype",type:"dtype"}]},{tfOpName:"ZerosLike",category:"creation",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype"}]},{tfOpName:"Multinomial",category:"creation",inputs:[{start:0,name:"logits",type:"tensor"},{start:1,name:"numSamples",type:"number"}],attrs:[{tfName:"seed",name:"seed",type:"number"},{tfName:"seed2",name:"seed2",type:"number"},{tfName:"T",name:"dtype",type:"dtype"},{tfName:"output_dtype",name:"output_dtype",type:"dtype"}]}],SS=Object.freeze(Object.defineProperty({__proto__:null,json:NS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const TS=[{tfOpName:"NonMaxSuppressionV2",category:"dynamic",inputs:[{start:0,name:"boxes",type:"tensor"},{start:1,name:"scores",type:"tensor"},{start:2,name:"maxOutputSize",type:"number"},{start:3,name:"iouThreshold",type:"number"}]},{tfOpName:"NonMaxSuppressionV3",category:"dynamic",inputs:[{start:0,name:"boxes",type:"tensor"},{start:1,name:"scores",type:"tensor"},{start:2,name:"maxOutputSize",type:"number"},{start:3,name:"iouThreshold",type:"number"},{start:4,name:"scoreThreshold",type:"number"}]},{tfOpName:"NonMaxSuppressionV4",category:"dynamic",inputs:[{start:0,name:"boxes",type:"tensor"},{start:1,name:"scores",type:"tensor"},{start:2,name:"maxOutputSize",type:"number"},{start:3,name:"iouThreshold",type:"number"},{start:4,name:"scoreThreshold",type:"number"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0},{tfName:"T_threshold",name:"threshold",type:"dtype",notSupported:!0},{tfName:"pad_to_max_output_size",name:"padToMaxOutputSize",type:"bool"}]},{tfOpName:"NonMaxSuppressionV5",category:"dynamic",inputs:[{start:0,name:"boxes",type:"tensor"},{start:1,name:"scores",type:"tensor"},{start:2,name:"maxOutputSize",type:"number"},{start:3,name:"iouThreshold",type:"number"},{start:4,name:"scoreThreshold",type:"number"},{start:5,name:"softNmsSigma",type:"number"}]},{tfOpName:"Where",category:"dynamic",inputs:[{start:0,name:"condition",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"ListDiff",category:"dynamic",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"y",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]}],$S=Object.freeze(Object.defineProperty({__proto__:null,json:TS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const ES=[{tfOpName:"LowerBound",category:"evaluation",inputs:[{start:0,name:"sortedSequence",type:"tensor"},{start:1,name:"values",type:"tensor"}]},{tfOpName:"TopKV2",category:"evaluation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"k",type:"number"}],attrs:[{tfName:"sorted",name:"sorted",type:"bool"}]},{tfOpName:"UpperBound",category:"evaluation",inputs:[{start:0,name:"sortedSequence",type:"tensor"},{start:1,name:"values",type:"tensor"}]},{tfOpName:"Unique",category:"evaluation",inputs:[{start:0,name:"x",type:"tensor"}]},{tfOpName:"UniqueV2",category:"evaluation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number"}]}],kS=Object.freeze(Object.defineProperty({__proto__:null,json:ES},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const vS=[{tfOpName:"PlaceholderWithDefault",category:"graph",inputs:[{start:0,name:"default",type:"tensor"}],attrs:[{tfName:"shape",name:"shape",type:"shape"},{tfName:"dtype",name:"dtype",type:"dtype"}]},{tfOpName:"Placeholder",category:"graph",attrs:[{tfName:"shape",name:"shape",type:"shape"},{tfName:"dtype",name:"dtype",type:"dtype"}]},{tfOpName:"Const",category:"graph"},{tfOpName:"Identity",category:"graph",inputs:[{start:0,name:"x",type:"tensor"}]},{tfOpName:"IdentityN",category:"graph",inputs:[{start:0,end:0,name:"x",type:"tensors"}]},{tfOpName:"Snapshot",category:"graph",inputs:[{start:0,name:"x",type:"tensor"}]},{tfOpName:"Rank",category:"graph",inputs:[{start:0,name:"x",type:"tensor"}]},{tfOpName:"Size",category:"graph",inputs:[{start:0,name:"x",type:"tensor"}]},{tfOpName:"Shape",category:"graph",inputs:[{start:0,name:"x",type:"tensor"}]},{tfOpName:"ShapeN",category:"graph",inputs:[{start:0,end:0,name:"x",type:"tensors"}]},{tfOpName:"Print",category:"graph",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"data",type:"tensors"}],attrs:[{tfName:"message",name:"message",type:"string"},{tfName:"first_n",name:"firstN",type:"number",notSupported:!0},{tfName:"summarize",name:"summarize",type:"number",defaultValue:3}]},{tfOpName:"NoOp",category:"graph",inputs:[]},{tfOpName:"StopGradient",category:"graph",inputs:[{start:0,name:"x",type:"tensor"}]},{tfOpName:"FakeQuantWithMinMaxVars",category:"graph",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"min",name:"min",type:"number"},{tfName:"max",name:"max",type:"number"}]}],_S=Object.freeze(Object.defineProperty({__proto__:null,json:vS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const IS=[{tfOpName:"HashTable",category:"hash_table",inputs:[],attrs:[{tfName:"shared_name",name:"sharedName",type:"string"},{tfName:"use_node_name_sharing",name:"useNodeNameSharing",type:"bool"},{tfName:"key_dtype",name:"keyDType",type:"dtype"},{tfName:"value_dtype",name:"valueDType",type:"dtype"}]},{tfOpName:"HashTableV2",category:"hash_table",inputs:[],attrs:[{tfName:"shared_name",name:"sharedName",type:"string"},{tfName:"use_node_name_sharing",name:"useNodeNameSharing",type:"bool"},{tfName:"key_dtype",name:"keyDType",type:"dtype"},{tfName:"value_dtype",name:"valueDType",type:"dtype"}]},{tfOpName:"LookupTableImport",category:"hash_table",inputs:[{start:0,name:"tableHandle",type:"tensor"},{start:1,name:"keys",type:"tensor"},{start:2,name:"values",type:"tensor"}],attrs:[{tfName:"Tin",name:"tIn",type:"dtype",notSupported:!0},{tfName:"Tout",name:"tOut",type:"dtype",notSupported:!0}]},{tfOpName:"LookupTableImportV2",category:"hash_table",inputs:[{start:0,name:"tableHandle",type:"tensor"},{start:1,name:"keys",type:"tensor"},{start:2,name:"values",type:"tensor"}],attrs:[{tfName:"Tin",name:"tIn",type:"dtype",notSupported:!0},{tfName:"Tout",name:"tOut",type:"dtype",notSupported:!0}]},{tfOpName:"LookupTableFind",category:"hash_table",inputs:[{start:0,name:"tableHandle",type:"tensor"},{start:1,name:"keys",type:"tensor"},{start:2,name:"defaultValue",type:"tensor"}],attrs:[{tfName:"Tin",name:"tIn",type:"dtype",notSupported:!0},{tfName:"Tout",name:"tOut",type:"dtype",notSupported:!0}]},{tfOpName:"LookupTableFindV2",category:"hash_table",inputs:[{start:0,name:"tableHandle",type:"tensor"},{start:1,name:"keys",type:"tensor"},{start:2,name:"defaultValue",type:"tensor"}],attrs:[{tfName:"Tin",name:"tIn",type:"dtype",notSupported:!0},{tfName:"Tout",name:"tOut",type:"dtype",notSupported:!0}]},{tfOpName:"LookupTableSize",category:"hash_table",inputs:[{start:0,name:"tableHandle",type:"tensor"}]},{tfOpName:"LookupTableSizeV2",category:"hash_table",inputs:[{start:0,name:"tableHandle",type:"tensor"}]},{tfOpName:"InitializeTable",category:"hash_table",inputs:[{start:0,name:"tableHandle",type:"tensor"},{start:1,name:"keys",type:"tensor"},{start:2,name:"values",type:"tensor"}]},{tfOpName:"InitializeTableV2",category:"hash_table",inputs:[{start:0,name:"tableHandle",type:"tensor"},{start:1,name:"keys",type:"tensor"},{start:2,name:"values",type:"tensor"}]}],xS=Object.freeze(Object.defineProperty({__proto__:null,json:IS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const AS=[{tfOpName:"ResizeBilinear",category:"image",inputs:[{start:0,name:"images",type:"tensor"},{start:1,name:"size",type:"number[]"}],attrs:[{tfName:"align_corners",name:"alignCorners",type:"bool"},{tfName:"half_pixel_centers",name:"halfPixelCenters",type:"bool"},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"ResizeNearestNeighbor",category:"image",inputs:[{start:0,name:"images",type:"tensor"},{start:1,name:"size",type:"number[]"}],attrs:[{tfName:"align_corners",name:"alignCorners",type:"bool"},{tfName:"half_pixel_centers",name:"halfPixelCenters",type:"bool"},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"CropAndResize",category:"image",inputs:[{start:0,name:"image",type:"tensor"},{start:1,name:"boxes",type:"tensor"},{start:2,name:"boxInd",type:"tensor"},{start:3,name:"cropSize",type:"number[]"}],attrs:[{tfName:"method",name:"method",type:"string"},{tfName:"extrapolation_value",name:"extrapolationValue",type:"number"}]},{tfOpName:"ImageProjectiveTransformV3",category:"image",inputs:[{start:0,name:"images",type:"tensor"},{start:1,name:"transforms",type:"tensor"},{start:2,name:"outputShape",type:"number[]"},{start:3,name:"fillValue",type:"number"}],attrs:[{tfName:"interpolation",name:"interpolation",type:"string"},{tfName:"fill_mode",name:"fillMode",type:"string"}]}],OS=Object.freeze(Object.defineProperty({__proto__:null,json:AS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const DS=[{tfOpName:"Equal",category:"logical",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"NotEqual",category:"logical",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Greater",category:"logical",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"GreaterEqual",category:"logical",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Less",category:"logical",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"LessEqual",category:"logical",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"LogicalAnd",category:"logical",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"LogicalNot",category:"logical",inputs:[{start:0,name:"a",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"LogicalOr",category:"logical",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Select",category:"logical",inputs:[{start:0,name:"condition",type:"tensor"},{start:1,name:"a",type:"tensor"},{start:2,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"SelectV2",category:"logical",inputs:[{start:0,name:"condition",type:"tensor"},{start:1,name:"a",type:"tensor"},{start:2,name:"b",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"BitwiseAnd",category:"logical",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"y",type:"tensor"}]}],FS=Object.freeze(Object.defineProperty({__proto__:null,json:DS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const CS=[{tfOpName:"_FusedMatMul",category:"matrices",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"},{start:2,end:0,name:"args",type:"tensors"}],attrs:[{tfName:"num_args",name:"numArgs",type:"number"},{tfName:"fused_ops",name:"fusedOps",type:"string[]",defaultValue:[]},{tfName:"epsilon",name:"epsilon",type:"number",defaultValue:1e-4},{tfName:"transpose_a",name:"transposeA",type:"bool",defaultValue:!1},{tfName:"transpose_b",name:"transposeB",type:"bool",defaultValue:!1},{tfName:"leakyrelu_alpha",name:"leakyreluAlpha",type:"number",defaultValue:.2},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"MatMul",category:"matrices",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"transpose_a",name:"transposeA",type:"bool",defaultValue:!1},{tfName:"transpose_b",name:"transposeB",type:"bool",defaultValue:!1},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"BatchMatMul",category:"matrices",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"adj_x",name:"transposeA",type:"bool",defaultValue:!1},{tfName:"adj_y",name:"transposeB",type:"bool",defaultValue:!1},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"BatchMatMulV2",category:"matrices",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"b",type:"tensor"}],attrs:[{tfName:"adj_x",name:"transposeA",type:"bool",defaultValue:!1},{tfName:"adj_y",name:"transposeB",type:"bool",defaultValue:!1},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Transpose",category:"matrices",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"perm",type:"number[]"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Einsum",category:"matrices",inputs:[{start:0,end:0,name:"tensors",type:"tensors"}],attrs:[{tfName:"equation",name:"equation",type:"string"},{tfName:"N",name:"n",type:"number",defaultValue:2},{tfName:"T",name:"dtype",type:"dtype"}]},{tfOpName:"MatrixBandPart",category:"matrices",inputs:[{start:0,name:"a",type:"tensor"},{start:1,name:"numLower",type:"tensor"},{start:1,name:"numUpper",type:"tensor"}]}],RS=Object.freeze(Object.defineProperty({__proto__:null,json:CS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const LS=[{tfOpName:"EuclideanNorm",category:"normalization",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number[]"}],attrs:[{tfName:"keep_dims",name:"keepDims",type:"bool",defaultValue:!1}]},{tfOpName:"FusedBatchNorm",category:"normalization",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"scale",type:"tensor"},{start:2,name:"offset",type:"tensor"},{start:3,name:"mean",type:"tensor"},{start:4,name:"variance",type:"tensor"}],attrs:[{tfName:"epsilon",name:"epsilon",type:"number",defaultValue:.001},{tfName:"data_format",name:"dataFormat",type:"string",notSupported:!0}]},{tfOpName:"FusedBatchNormV2",category:"normalization",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"scale",type:"tensor"},{start:2,name:"offset",type:"tensor"},{start:3,name:"mean",type:"tensor"},{start:4,name:"variance",type:"tensor"}],attrs:[{tfName:"epsilon",name:"epsilon",type:"number",defaultValue:.001},{tfName:"data_format",name:"dataFormat",type:"string",notSupported:!0}]},{tfOpName:"FusedBatchNormV3",category:"normalization",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"scale",type:"tensor"},{start:2,name:"offset",type:"tensor"},{start:3,name:"mean",type:"tensor"},{start:4,name:"variance",type:"tensor"}],attrs:[{tfName:"epsilon",name:"epsilon",type:"number",defaultValue:.001},{tfName:"data_format",name:"dataFormat",type:"string",notSupported:!0}]},{tfOpName:"LRN",category:"normalization",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"depth_radius",name:"radius",type:"number",defaultValue:5},{tfName:"bias",name:"bias",type:"number",defaultValue:1},{tfName:"alpha",name:"alpha",type:"number",defaultValue:1},{tfName:"beta",name:"beta",type:"number",defaultValue:.5}]},{tfOpName:"Softmax",category:"normalization",inputs:[{start:0,name:"x",type:"tensor"}]},{tfOpName:"LogSoftmax",category:"normalization",inputs:[{start:0,name:"x",type:"tensor"}]}],BS=Object.freeze(Object.defineProperty({__proto__:null,json:LS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const PS=[{tfOpName:"Bincount",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"size",type:"number"},{start:2,name:"weights",type:"tensor"}]},{tfOpName:"DenseBincount",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"size",type:"number"},{start:2,name:"weights",type:"tensor"}],attrs:[{tfName:"binary_output",name:"binaryOutput",type:"bool"}]},{tfOpName:"Max",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number[]"}],attrs:[{tfName:"keep_dims",name:"keepDims",type:"bool"}]},{tfOpName:"Mean",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number[]"}],attrs:[{tfName:"keep_dims",name:"keepDims",type:"bool"}]},{tfOpName:"Min",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number[]"}],attrs:[{tfName:"keep_dims",name:"keepDims",type:"bool"}]},{tfOpName:"Sum",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number[]"}],attrs:[{tfName:"keep_dims",name:"keepDims",type:"bool"}]},{tfOpName:"All",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number[]"}],attrs:[{tfName:"keep_dims",name:"keepDims",type:"bool"}]},{tfOpName:"Any",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number[]"}],attrs:[{tfName:"keep_dims",name:"keepDims",type:"bool"}]},{tfOpName:"ArgMax",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number"}]},{tfOpName:"ArgMin",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number"}]},{tfOpName:"Prod",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number[]"}],attrs:[{tfName:"keep_dims",name:"keepDims",type:"bool"},{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"Cumprod",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number"}],attrs:[{tfName:"exclusive",name:"exclusive",type:"bool"},{tfName:"reverse",name:"reverse",type:"bool"}]},{tfOpName:"Cumsum",category:"reduction",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number"}],attrs:[{tfName:"exclusive",name:"exclusive",type:"bool"},{tfName:"reverse",name:"reverse",type:"bool"}]}],zS=Object.freeze(Object.defineProperty({__proto__:null,json:PS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const VS=[{tfOpName:"ConcatV2",category:"slice_join",inputs:[{start:0,end:-1,name:"tensors",type:"tensors"},{start:-1,name:"axis",type:"number"}],attrs:[{tfName:"N",name:"n",type:"number",defaultValue:2}]},{tfOpName:"Concat",category:"slice_join",inputs:[{start:1,end:0,name:"tensors",type:"tensors"},{start:0,name:"axis",type:"number"}],attrs:[{tfName:"N",name:"n",type:"number",defaultValue:2}]},{tfOpName:"GatherV2",category:"slice_join",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"indices",type:"tensor"},{start:2,name:"axis",type:"number",defaultValue:0}],attrs:[{tfName:"batch_dims",name:"batchDims",type:"number",defaultValue:0}]},{tfOpName:"Gather",category:"slice_join",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"indices",type:"tensor"}],attrs:[{tfName:"validate_indices",name:"validateIndices",type:"bool",notSupported:!0}]},{tfOpName:"Reverse",category:"slice_join",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"dims",type:"bool[]"}]},{tfOpName:"ReverseV2",category:"slice_join",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number[]"}]},{tfOpName:"Slice",category:"slice_join",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"begin",type:"number[]"},{start:2,name:"size",type:"number[]"}]},{tfOpName:"StridedSlice",category:"slice_join",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"begin",type:"number[]"},{start:2,name:"end",type:"number[]"},{start:3,name:"strides",type:"number[]"}],attrs:[{tfName:"begin_mask",name:"beginMask",type:"number",defaultValue:0},{tfName:"end_mask",name:"endMask",type:"number",defaultValue:0},{tfName:"new_axis_mask",name:"newAxisMask",type:"number",defaultValue:0},{tfName:"ellipsis_mask",name:"ellipsisMask",type:"number",defaultValue:0},{tfName:"shrink_axis_mask",name:"shrinkAxisMask",type:"number",defaultValue:0}]},{tfOpName:"Pack",category:"slice_join",inputs:[{start:0,end:0,name:"tensors",type:"tensors"}],attrs:[{tfName:"axis",name:"axis",type:"number",defaultValue:0}]},{tfOpName:"Unpack",category:"slice_join",inputs:[{start:0,name:"tensor",type:"tensor"}],attrs:[{tfName:"axis",name:"axis",type:"number",defaultValue:0},{tfName:"num",name:"num",type:"number",defaultValue:0,notSupported:!0}]},{tfOpName:"Tile",category:"slice_join",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"reps",type:"number[]"}]},{tfOpName:"Split",category:"slice_join",inputs:[{start:0,name:"axis",type:"number",defaultValue:0},{start:1,name:"x",type:"tensor"}],attrs:[{tfName:"num_split",name:"numOrSizeSplits",type:"number",defaultValue:1}]},{tfOpName:"SplitV",category:"slice_join",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"numOrSizeSplits",type:"number[]"},{start:2,name:"axis",type:"number",defaultValue:0}]},{tfOpName:"ScatterNd",category:"slice_join",inputs:[{start:0,name:"indices",type:"tensor"},{start:1,name:"values",type:"tensor"},{start:2,name:"shape",type:"number[]"}]},{tfOpName:"GatherNd",category:"slice_join",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"indices",type:"tensor"}]},{tfOpName:"SparseToDense",category:"slice_join",inputs:[{start:0,name:"sparseIndices",type:"tensor"},{start:1,name:"outputShape",type:"number[]"},{start:2,name:"sparseValues",type:"tensor"},{start:3,name:"defaultValue",type:"tensor"}],attrs:[{tfName:"validate_indices",name:"validateIndices",type:"bool",defaultValue:!1,notSupported:!0}]},{tfOpName:"TensorScatterUpdate",category:"slice_join",inputs:[{start:0,name:"tensor",type:"tensor"},{start:1,name:"indices",type:"tensor"},{start:2,name:"values",type:"tensor"}]}],WS=Object.freeze(Object.defineProperty({__proto__:null,json:VS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const MS=[{tfOpName:"SparseFillEmptyRows",category:"sparse",inputs:[{start:0,name:"indices",type:"tensor"},{start:1,name:"values",type:"tensor"},{start:2,name:"denseShape",type:"tensor"},{start:3,name:"defaultValue",type:"tensor"}]},{tfOpName:"SparseReshape",category:"sparse",inputs:[{start:0,name:"inputIndices",type:"tensor"},{start:1,name:"inputShape",type:"tensor"},{start:2,name:"newShape",type:"tensor"}],attrs:[{tfName:"T",name:"dtype",type:"dtype",notSupported:!0}]},{tfOpName:"SparseSegmentMean",category:"sparse",inputs:[{start:0,name:"data",type:"tensor"},{start:1,name:"indices",type:"tensor"},{start:2,name:"segmentIds",type:"tensor"}]},{tfOpName:"SparseSegmentSum",category:"sparse",inputs:[{start:0,name:"data",type:"tensor"},{start:1,name:"indices",type:"tensor"},{start:2,name:"segmentIds",type:"tensor"}]}],US=Object.freeze(Object.defineProperty({__proto__:null,json:MS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const jS=[{tfOpName:"FFT",category:"spectral",inputs:[{start:0,name:"x",type:"tensor"}]},{tfOpName:"IFFT",category:"spectral",inputs:[{start:0,name:"x",type:"tensor"}]},{tfOpName:"RFFT",category:"spectral",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"fft_length",type:"number",notSupported:!0}]},{tfOpName:"IRFFT",category:"spectral",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"fft_length",type:"number",notSupported:!0}]}],qS=Object.freeze(Object.defineProperty({__proto__:null,json:jS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const GS=[{tfOpName:"StaticRegexReplace",category:"string",inputs:[{start:0,name:"input",type:"tensor"}],attrs:[{tfName:"pattern",name:"pattern",type:"string"},{tfName:"rewrite",name:"rewrite",type:"string"},{tfName:"replace_global",name:"replaceGlobal",type:"bool"}]},{tfOpName:"StringNGrams",category:"string",inputs:[{start:0,name:"data",type:"tensor"},{start:1,name:"dataSplits",type:"tensor"}],attrs:[{tfName:"separator",name:"separator",type:"string"},{tfName:"ngram_widths",name:"nGramWidths",type:"number[]"},{tfName:"left_pad",name:"leftPad",type:"string"},{tfName:"right_pad",name:"rightPad",type:"string"},{tfName:"pad_width",name:"padWidth",type:"number"},{tfName:"preserve_short_sequences",name:"preserveShortSequences",type:"bool"}],outputs:["ngrams","ngrams_splits"]},{tfOpName:"StringSplit",category:"string",inputs:[{start:0,name:"input",type:"tensor"},{start:1,name:"delimiter",type:"tensor"}],attrs:[{tfName:"skip_empty",name:"skipEmpty",type:"bool"}],outputs:["indices","values","shape"]},{tfOpName:"StringToHashBucketFast",category:"string",inputs:[{start:0,name:"input",type:"tensor"}],attrs:[{tfName:"num_buckets",name:"numBuckets",type:"number"}]}],HS=Object.freeze(Object.defineProperty({__proto__:null,json:GS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2023 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const KS=[{tfOpName:"Cast",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"SrcT",name:"sdtype",type:"dtype",notSupported:!0},{tfName:"DstT",name:"dtype",type:"dtype"}]},{tfOpName:"ExpandDims",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"axis",type:"number"}]},{tfOpName:"MirrorPad",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"padding",type:"number[]"}],attrs:[{tfName:"mode",name:"mode",type:"string"}]},{tfOpName:"Pad",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"padding",type:"number[]"}],attrs:[{tfName:"constant_value",name:"constantValue",type:"number",defaultValue:0}]},{tfOpName:"PadV2",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"padding",type:"number[]"},{start:2,name:"constantValue",type:"number",defaultValue:0}]},{tfOpName:"Reshape",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"shape",type:"number[]"}]},{tfOpName:"EnsureShape",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"shape",type:"number[]"}]},{tfOpName:"Squeeze",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"axis",tfDeprecatedName:"squeeze_dims",name:"axis",type:"number[]"}]},{tfOpName:"SpaceToBatchND",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"blockShape",type:"number[]"},{start:2,name:"paddings",type:"number[]"}]},{tfOpName:"BatchToSpaceND",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"blockShape",type:"number[]"},{start:2,name:"crops",type:"number[]"}]},{tfOpName:"DepthToSpace",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"}],attrs:[{tfName:"block_size",name:"blockSize",type:"number"},{tfName:"data_format",name:"dataFormat",type:"string"}]},{tfOpName:"BroadcastTo",category:"transformation",inputs:[{start:0,name:"x",type:"tensor"},{start:1,name:"shape",type:"number[]"}],attrs:[]},{tfOpName:"BroadcastArgs",category:"transformation",inputs:[{start:0,name:"s0",type:"tensor"},{start:1,name:"s1",type:"tensor"}],attrs:[]}],XS=Object.freeze(Object.defineProperty({__proto__:null,json:KS},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class Ga{static get Instance(){return this._instance||(this._instance=new this)}constructor(){const e=[fS,mS,yS,wS,SS,$S,kS,_S,xS,OS,FS,RS,BS,zS,WS,US,qS,HS,XS],n=[].concat(...e.map(s=>s.json));this.opMappers=n.reduce((s,r)=>(s[r.tfOpName]=r,s),{})}transformGraph(e,n={}){const s=e.node,r=[],a=[],o=[],i=s.reduce((T,S)=>(T[S.name]=this.mapNode(S),S.op.startsWith("Placeholder")?r.push(T[S.name]):S.op==="Const"?a.push(T[S.name]):(S.input==null||S.input.length===0)&&o.push(T[S.name]),T),{});let u=[];const c=[];let h={},l={};n!=null&&(h=this.mapSignatureEntries(n.inputs),l=this.mapSignatureEntries(n.outputs));const f=Object.keys(i);f.forEach(T=>{const S=i[T];S.inputNames.forEach(($,O)=>{const[v,,_]=Ue($),A=i[v];if(A.outputs!=null){const F=A.outputs.indexOf(_);if(F!==-1){const L=`${v}:${F}`;S.inputNames[O]=L}}S.inputs.push(A),A.children.push(S)})}),Object.keys(l).length===0?f.forEach(T=>{const S=i[T];S.children.length===0&&c.push(S)}):Object.keys(l).forEach(T=>{const[S]=Ue(T),$=i[S];$!=null&&($.signatureKey=l[T],c.push($))}),Object.keys(h).length>0?Object.keys(h).forEach(T=>{const[S]=Ue(T),$=i[S];$&&($.signatureKey=h[T],u.push($))}):u=r;let m={};e.library!=null&&e.library.function!=null&&(m=e.library.function.reduce((T,S)=>(T[S.signature.name]=this.mapFunction(S),T),{}));const b={nodes:i,inputs:u,outputs:c,weights:a,placeholders:r,signature:n,functions:m};return o.length>0&&(b.initNodes=o),b}mapSignatureEntries(e){return Object.keys(e||{}).reduce((n,s)=>(n[e[s].name]=s,n),{})}mapNode(e){const n=$p(e.op)||this.opMappers[e.op]||{};e.attr==null&&(e.attr={});const s={name:e.name,op:e.op,category:n.category,inputNames:(e.input||[]).map(r=>r.startsWith("^")?r.slice(1):r),inputs:[],children:[],inputParams:{},attrParams:{},rawAttrs:e.attr,outputs:n.outputs};return n.inputs!=null&&(s.inputParams=n.inputs.reduce((r,a)=>(r[a.name]={type:a.type,inputIndexStart:a.start,inputIndexEnd:a.end},r),{})),n.attrs!=null&&(s.attrParams=n.attrs.reduce((r,a)=>{const o=a.type;let i;switch(a.type){case"string":i=Xs(e.attr,a.tfName,a.defaultValue),i===void 0&&a.tfDeprecatedName&&(i=Xs(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"string[]":i=nr(e.attr,a.tfName,a.defaultValue),i===void 0&&a.tfDeprecatedName&&(i=nr(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"number":i=Js(e.attr,a.tfName,a.defaultValue||0),i===void 0&&a.tfDeprecatedName&&(i=Js(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"number[]":i=tr(e.attr,a.tfName,a.defaultValue),i===void 0&&a.tfDeprecatedName&&(i=tr(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"bool":i=Zs(e.attr,a.tfName,a.defaultValue),i===void 0&&a.tfDeprecatedName&&(i=Zs(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"bool[]":i=rr(e.attr,a.tfName,a.defaultValue),i===void 0&&a.tfDeprecatedName&&(i=rr(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"shape":i=er(e.attr,a.tfName,a.defaultValue),i===void 0&&a.tfDeprecatedName&&(i=er(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"shape[]":i=sr(e.attr,a.tfName,a.defaultValue),i===void 0&&a.tfDeprecatedName&&(i=sr(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"dtype":i=Ys(e.attr,a.tfName,a.defaultValue),i===void 0&&a.tfDeprecatedName&&(i=Ys(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"dtype[]":i=Qs(e.attr,a.tfName,a.defaultValue),i===void 0&&a.tfDeprecatedName&&(i=Qs(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"func":i=Ha(e.attr,a.tfName,a.defaultValue),i===void 0&&a.tfDeprecatedName&&(i=Ha(e.attr,a.tfDeprecatedName,a.defaultValue));break;case"tensor":case"tensors":break;default:throw new Error(`Unsupported param type: ${a.type} for op: ${e.op}`)}return r[a.name]={value:i,type:o},r},{})),s}mapFunction(e){const n=e.nodeDef,s=[],r=[];let a={};n!=null&&(a=n.reduce((l,f)=>(l[f.name]=this.mapNode(f),f.op==="Const"&&r.push(l[f.name]),l),{}));const o=[],i=[];e.signature.inputArg.forEach(l=>{const[f]=Ue(l.name),m={name:f,op:"Placeholder",inputs:[],inputNames:[],category:"graph",inputParams:{},attrParams:{dtype:{value:ba(l.type),type:"dtype"}},children:[]};m.signatureKey=l.name,o.push(m),a[f]=m}),Object.keys(a).forEach(l=>{const f=a[l];f.inputNames.forEach((m,b)=>{const[T,,S]=Ue(m),$=a[T];if($.outputs!=null){const O=$.outputs.indexOf(S);if(O!==-1){const v=`${T}:${O}`;f.inputNames[b]=v}}f.inputs.push($),$.children.push(f)})});const c=e.ret;e.signature.outputArg.forEach(l=>{const[f,m]=Ue(c[l.name]),b=a[f];b!=null&&(b.defaultOutput=m,i.push(b))});const h=this.mapArgsToSignature(e);return{nodes:a,inputs:o,outputs:i,weights:r,placeholders:s,signature:h}}mapArgsToSignature(e){return{methodName:e.signature.name,inputs:e.signature.inputArg.reduce((n,s)=>(n[s.name]=this.mapArgToTensorInfo(s),n),{}),outputs:e.signature.outputArg.reduce((n,s)=>(n[s.name]=this.mapArgToTensorInfo(s,e.ret),n),{})}}mapArgToTensorInfo(e,n){let s=e.name;return n!=null&&(s=n[s]),{name:s,dtype:e.type}}}function ZS(t){const e=P().global;if(typeof e.atob<"u")return e.atob(t);if(typeof Buffer<"u")return new Buffer(t,"base64").toString();throw new Error("Unable to decode base64 in this environment. Missing built-in atob() or Buffer()")}function Ep(t,e){const n=Array.isArray(t)?String.fromCharCode.apply(null,t):ZS(t);return e?n:n.toLowerCase()}function Xs(t,e,n,s=!1){const r=t[e];return r!=null?Ep(r.s,s):n}function Zs(t,e,n){const s=t[e];return s?s.b:n}function Js(t,e,n){const s=t[e]||{},r=s.i!=null?s.i:s.f!=null?s.f:n;return typeof r=="number"?r:parseInt(r,10)}function ba(t){switch(typeof t=="string"&&(t=we[t]),t){case we.DT_FLOAT:case we.DT_HALF:return"float32";case we.DT_INT32:case we.DT_INT64:case we.DT_INT8:case we.DT_UINT8:return"int32";case we.DT_BOOL:return"bool";case we.DT_DOUBLE:return"float32";case we.DT_STRING:return"string";case we.DT_COMPLEX64:case we.DT_COMPLEX128:return"complex64";default:return null}}function Ha(t,e,n){const s=t[e];return s&&s.func?s.func.name:n}function Ys(t,e,n){const s=t[e];return s&&s.type?ba(s.type):n}function Qs(t,e,n){const s=t[e];return s&&s.list&&s.list.type?s.list.type.map(r=>ba(r)):n}function kp(t){if(!t.unknownRank)return t.dim!=null?t.dim.map(e=>typeof e.size=="number"?e.size:parseInt(e.size,10)):[]}function er(t,e,n){const s=t[e];return s&&s.shape?kp(s.shape):n}function tr(t,e,n){const s=t[e];return s?((s.list.f&&s.list.f.length?s.list.f:s.list.i)||[]).map(r=>typeof r=="number"?r:parseInt(r,10)):n}function nr(t,e,n,s=!1){const r=t[e];return r&&r.list&&r.list.s?r.list.s.map(a=>Ep(a,s)):n}function sr(t,e,n){const s=t[e];return s&&s.list&&s.list.shape?s.list.shape.map(r=>kp(r)):n}function rr(t,e,n){const s=t[e];return s&&s.list&&s.list.b?s.list.b:n}/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class JS{constructor(e,n,s){this.node=e,this.tensorMap=n,this.context=s,this.inputs=[],this.attrs={},this.inputs=e.inputNames.map(r=>this.getInput(r)),e.rawAttrs!=null&&(this.attrs=Object.keys(e.rawAttrs).reduce((r,a)=>(r[a]=this.getAttr(a),r),{}))}getInput(e){return ce(e,this.tensorMap,this.context)}getAttr(e,n){const s=this.node.rawAttrs[e];if(s.tensor!=null)return ce(e,this.tensorMap,this.context);if(s.i!=null||s.f!=null)return Js(this.node.rawAttrs,e,n);if(s.s!=null)return Xs(this.node.rawAttrs,e,n);if(s.b!=null)return Zs(this.node.rawAttrs,e,n);if(s.shape!=null)return er(this.node.rawAttrs,e,n);if(s.type!=null)return Ys(this.node.rawAttrs,e,n);if(s.list!=null){if(s.list.i!=null||s.list.f!=null)return tr(this.node.rawAttrs,e,n);if(s.list.s!=null)return nr(this.node.rawAttrs,e,n);if(s.list.shape!=null)return sr(this.node.rawAttrs,e,n);if(s.list.b!=null)return rr(this.node.rawAttrs,e,n);if(s.list.type!=null)return Qs(this.node.rawAttrs,e,n)}return n}}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const le=Object.freeze(Object.defineProperty({__proto__:null,OP_SCOPE_SUFFIX:yr,abs:Se,acos:Ac,acosh:Oc,add:B,addN:Dc,all:Fc,any:Cc,argMax:Rc,argMin:Lc,asin:Bc,asinh:Pc,atan:zc,atan2:Vc,atanh:Wc,avgPool:Er,avgPool3d:qc,basicLSTMCell:Gc,batchNorm:Nn,batchNorm2d:Hc,batchNorm3d:Kc,batchNorm4d:Xc,batchToSpaceND:kr,bincount:vr,bitwiseAnd:Zc,booleanMaskAsync:Ph,broadcastArgs:Jc,broadcastTo:Yt,buffer:Pe,cast:J,ceil:Yc,clipByValue:Qc,clone:Ge,complex:Ke,concat:he,concat1d:el,concat2d:tl,concat3d:nl,concat4d:sl,conv1d:rl,conv2d:Sn,conv2dTranspose:ol,conv3d:il,conv3dTranspose:ul,cos:cl,cosh:ll,cosineWindow:ds,cumprod:hl,cumsum:pl,denseBincount:fl,depthToSpace:dl,depthwiseConv2d:as,diag:ml,dilation2d:gl,div:Z,divNoNan:bl,dot:wl,dropout:Uh,einsum:mt,elu:xr,enclosingPowerOfTwo:aa,ensureShape:Nl,equal:Ir,erf:Sl,euclideanNorm:El,exp:it,expandDims:Me,expm1:kl,eye:Or,fft:ls,fill:jt,floor:Dr,floorDiv:Tr,fused:qh,gather:Fr,gatherND:Mh,greater:En,greaterEqual:Cr,ifft:pn,imag:kn,image:Qh,inTopKAsync:jh,irfft:Qr,isFinite:vl,isInf:_l,isNaN:Il,leakyRelu:Rr,less:Jn,lessEqual:os,linalg:ep,linspace:xl,localResponseNormalization:Al,log:zt,log1p:Lr,logSigmoid:Dl,logSoftmax:Fl,logSumExp:Pr,logicalAnd:cn,logicalNot:zr,logicalOr:Vr,logicalXor:Cl,losses:tp,lowerBound:Rl,matMul:j,max:Nt,maxPool:Wr,maxPool3d:Ll,maxPoolWithArgmax:Bl,maximum:Mr,mean:ln,meshgrid:Pl,min:Zn,minimum:hn,mirrorPad:zl,mod:Vl,moments:Wl,movingAverage:zh,mul:D,multiRNNCell:Ml,multinomial:Ul,neg:Fe,norm:$n,notEqual:Ur,oneHot:Yn,ones:tt,onesLike:jl,op:w,outerProduct:ql,pad:qt,pad1d:Gl,pad2d:Hl,pad3d:Kl,pad4d:Xl,pool:Zl,pow:Pt,prelu:qr,print:Sr,prod:Jl,raggedGather:Yl,raggedRange:Ql,raggedTensorToTensor:eh,rand:th,randomGamma:rh,randomNormal:Zr,randomStandardNormal:ah,randomUniform:cs,randomUniformInt:oh,range:Vt,real:Wt,reciprocal:ih,relu:vn,relu6:Jr,reshape:I,reverse:ut,reverse1d:uh,reverse2d:ch,reverse3d:lh,reverse4d:hh,rfft:hs,round:Yr,rsqrt:ph,scalar:M,scatterND:Vh,searchSorted:us,selu:fh,separableConv2d:dh,setdiff1dAsync:mh,sigmoid:wt,sign:gh,signal:Yh,sin:yh,sinh:bh,slice:H,slice1d:wh,slice2d:Nh,slice3d:Sh,slice4d:Th,softmax:$h,softplus:Br,spaceToBatchND:jr,sparse:np,sparseToDense:Wh,spectral:Jh,split:Mt,sqrt:ze,square:Ie,squaredDifference:ea,squeeze:ps,stack:We,step:ta,stridedSlice:Eh,string:sp,sub:W,sum:X,tan:kh,tanh:Xn,tensor:De,tensor1d:ke,tensor2d:Ct,tensor3d:na,tensor4d:vh,tensor5d:_h,tensor6d:Ih,tensorScatterUpdate:Ah,tile:Ft,topk:Oh,transpose:fn,truncatedNormal:Dh,unique:Fh,unsortedSegmentSum:Ch,unstack:lt,upperBound:Rh,variable:Lh,where:He,whereAsync:ra,zeros:kt,zerosLike:Te},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const YS=(t,e,n,s=le)=>{switch(t.op){case"BiasAdd":case"AddV2":case"Add":return[s.add(p("a",t,e,n),p("b",t,e,n))];case"AddN":return[s.addN(p("tensors",t,e,n))];case"FloorMod":case"Mod":return[s.mod(p("a",t,e,n),p("b",t,e,n))];case"Mul":return[s.mul(p("a",t,e,n),p("b",t,e,n))];case"RealDiv":case"Div":return[s.div(p("a",t,e,n),p("b",t,e,n))];case"DivNoNan":return[s.divNoNan(p("a",t,e,n),p("b",t,e,n))];case"FloorDiv":return[s.floorDiv(p("a",t,e,n),p("b",t,e,n))];case"Sub":return[s.sub(p("a",t,e,n),p("b",t,e,n))];case"Minimum":return[s.minimum(p("a",t,e,n),p("b",t,e,n))];case"Maximum":return[s.maximum(p("a",t,e,n),p("b",t,e,n))];case"Pow":return[s.pow(p("a",t,e,n),p("b",t,e,n))];case"SquaredDifference":return[s.squaredDifference(p("a",t,e,n),p("b",t,e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const QS=(t,e,n,s=le)=>{switch(t.op){case"Abs":case"ComplexAbs":return[s.abs(p("x",t,e,n))];case"Acos":return[s.acos(p("x",t,e,n))];case"Acosh":return[s.acosh(p("x",t,e,n))];case"Asin":return[s.asin(p("x",t,e,n))];case"Asinh":return[s.asinh(p("x",t,e,n))];case"Atan":return[s.atan(p("x",t,e,n))];case"Atan2":return[s.atan2(p("x",t,e,n),p("y",t,e,n))];case"Atanh":return[s.atanh(p("x",t,e,n))];case"Ceil":return[s.ceil(p("x",t,e,n))];case"Complex":return[s.complex(p("real",t,e,n),p("imag",t,e,n))];case"Cos":return[s.cos(p("x",t,e,n))];case"Cosh":return[s.cosh(p("x",t,e,n))];case"Elu":return[s.elu(p("x",t,e,n))];case"Erf":return[s.erf(p("x",t,e,n))];case"Exp":return[s.exp(p("x",t,e,n))];case"Expm1":return[s.expm1(p("x",t,e,n))];case"Floor":return[s.floor(p("x",t,e,n))];case"Log":return[s.log(p("x",t,e,n))];case"Log1p":return[s.log1p(p("x",t,e,n))];case"Imag":return[s.imag(p("x",t,e,n))];case"Neg":return[s.neg(p("x",t,e,n))];case"Reciprocal":return[s.reciprocal(p("x",t,e,n))];case"Real":return[s.real(p("x",t,e,n))];case"Relu":return[s.relu(p("x",t,e,n))];case"Round":return[s.round(p("x",t,e,n))];case"Selu":return[s.selu(p("x",t,e,n))];case"Sigmoid":return[s.sigmoid(p("x",t,e,n))];case"Sin":return[s.sin(p("x",t,e,n))];case"Sign":return[s.sign(p("x",t,e,n))];case"Sinh":return[s.sinh(p("x",t,e,n))];case"Softplus":return[s.softplus(p("x",t,e,n))];case"Sqrt":return[s.sqrt(p("x",t,e,n))];case"Square":return[s.square(p("x",t,e,n))];case"Tanh":return[s.tanh(p("x",t,e,n))];case"Tan":return[s.tan(p("x",t,e,n))];case"ClipByValue":return[s.clipByValue(p("x",t,e,n),p("clipValueMin",t,e,n),p("clipValueMax",t,e,n))];case"Relu6":return[s.relu6(p("x",t,e,n))];case"Rsqrt":return[s.rsqrt(ce(t.inputNames[0],e,n))];case"LeakyRelu":return[s.leakyRelu(p("x",t,e,n),p("alpha",t,e,n))];case"Prelu":return[s.prelu(p("x",t,e,n),p("alpha",t,e,n))];case"IsNan":return[s.isNaN(ce(t.inputNames[0],e,n))];case"IsInf":return[s.isInf(ce(t.inputNames[0],e,n))];case"IsFinite":return[s.isFinite(ce(t.inputNames[0],e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function _e(t,e,n=""){if(!(typeof t=="number"||typeof e=="number")){g(t.length===e.length,()=>n+` Shapes ${t} and ${e} must match`);for(let s=0;s<t.length;s++){const r=t[s],a=e[s];g(r<0||a<0||r===a,()=>n+` Shapes ${t} and ${e} must match`)}}}function Ka(t){return!(typeof t=="number"||t.some(e=>e<0))}function Kt(t,e,n){let s=ar(t,n);const r=!Ka(s);if(r&&e.length===0)throw new Error(`Tried to calculate elements of an empty list with non-fully-defined elementShape: ${s}`);if(r&&e.forEach(a=>{s=ar(a.shape,s)}),!Ka(s))throw new Error(`Non-fully-defined elementShape: ${s}`);return s}function ar(t,e){if(typeof t=="number")return e;if(typeof e=="number")return t;if(t.length!==e.length)throw new Error(`Incompatible ranks during merge: ${t} vs. ${e}`);const n=[];for(let s=0;s<t.length;++s){const r=t[s],a=e[s];if(r>=0&&a>=0&&r!==a)throw new Error(`Incompatible shape during merge: ${t} vs. ${e}`);n[s]=r>=0?r:a}return n}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class eT{constructor(e,n,s,r,a,o,i){this.name=e,this.dtype=n,this.maxSize=s,this.elementShape=r,this.identicalElementShapes=a,this.dynamicSize=o,this.clearAfterRead=i,this.tensors=[],this.closed_=!1,this.idTensor=M(0),Oe(this.idTensor)}get id(){return this.idTensor.id}get closed(){return this.closed_}clearAndClose(e){this.tensors.forEach(n=>{(e==null||!e.has(n.tensor.id))&&n.tensor.dispose()}),this.tensors=[],this.closed_=!0,this.idTensor.dispose()}size(){return this.tensors.length}read(e){if(this.closed_)throw new Error(`TensorArray ${this.name} has already been closed.`);if(e<0||e>=this.size())throw new Error(`Tried to read from index ${e}, but array size is: ${this.size()}`);const n=this.tensors[e];if(n.cleared)throw new Error(`TensorArray ${this.name}: Could not read index ${e} twice because it was cleared after a previous read (perhaps try setting clear_after_read = false?).`);return this.clearAfterRead&&(n.cleared=!0),n.read=!0,n.tensor}readMany(e){return e.map(n=>this.read(n))}write(e,n){if(this.closed_)throw new Error(`TensorArray ${this.name} has already been closed.`);if(e<0||!this.dynamicSize&&e>=this.maxSize)throw new Error(`Tried to write to index ${e}, but array is not resizeable and size is: ${this.maxSize}`);const s=this.tensors[e]||{};if(n.dtype!==this.dtype)throw new Error(`TensorArray ${this.name}: Could not write to TensorArray index ${e},
          because the value dtype is ${n.dtype}, but TensorArray dtype is ${this.dtype}.`);if(this.size()===0&&(this.elementShape==null||this.elementShape.length===0)&&(this.elementShape=n.shape),_e(this.elementShape,n.shape,`TensorArray ${this.name}: Could not write to TensorArray index ${e}.`),s.read)throw new Error(`TensorArray ${this.name}: Could not write to TensorArray index ${e}, because it has already been read.`);if(s.written)throw new Error(`TensorArray ${this.name}: Could not write to TensorArray index ${e}, because it has already been written.`);s.tensor=n,Oe(n),s.written=!0,this.tensors[e]=s}writeMany(e,n){if(e.length!==n.length)throw new Error(`TensorArray ${this.name}: could not write multiple tensors,because the index size: ${e.length} is not the same as tensors size: ${n.length}.`);e.forEach((s,r)=>this.write(s,n[r]))}gather(e,n){if(n&&n!==this.dtype)throw new Error(`TensorArray dtype is ${this.dtype} but gather requested dtype ${n}`);if(e)e=e.slice(0,this.size());else{e=[];for(let r=0;r<this.size();r++)e.push(r)}if(e.length===0)return De([],[0].concat(this.elementShape));const s=this.readMany(e);return _e(this.elementShape,s[0].shape,"TensorArray shape mismatch: "),We(s,0)}concat(e){if(e&&e!==this.dtype)throw new Error(`TensorArray dtype is ${this.dtype} but concat requested dtype ${e}`);if(this.size()===0)return De([],[0].concat(this.elementShape));const n=[];for(let r=0;r<this.size();r++)n.push(r);const s=this.readMany(n);return _e(this.elementShape,s[0].shape,`TensorArray shape mismatch: tensor array shape (${this.elementShape}) vs first tensor shape (${s[0].shape})`),he(s,0)}scatter(e,n){if(n.dtype!==this.dtype)throw new Error(`TensorArray dtype is ${this.dtype} but tensor has dtype ${n.dtype}`);if(e.length!==n.shape[0])throw new Error(`Expected len(indices) == tensor.shape[0], but saw: ${e.length} vs. ${n.shape[0]}`);const s=Math.max(...e);if(!this.dynamicSize&&s>=this.maxSize)throw new Error(`Max index must be < array size (${s}  vs. ${this.maxSize})`);this.writeMany(e,lt(n,0))}split(e,n){if(n.dtype!==this.dtype)throw new Error(`TensorArray dtype is ${this.dtype} but tensor has dtype ${n.dtype}`);let s=0;const r=e.map(u=>(s+=u,s));if(s!==n.shape[0])throw new Error(`Expected sum of lengths to be equal to
          tensor.shape[0], but sum of lengths is
        ${s}, and tensor's shape is: ${n.shape}`);if(!this.dynamicSize&&e.length!==this.maxSize)throw new Error(`TensorArray's size is not equal to the size of lengths (${this.maxSize} vs. ${e.length}), and the TensorArray is not marked as dynamically resizeable`);const a=s===0?0:n.size/s,o=[];q(()=>{n=I(n,[1,s,a]);for(let u=0;u<e.length;++u){const h=[0,u===0?0:r[u-1],0],l=[1,e[u],a];o[u]=I(H(n,h,l),this.elementShape)}return o});const i=[];for(let u=0;u<e.length;u++)i[u]=u;this.writeMany(i,o)}}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class _t{get id(){return this.idTensor.id}constructor(e,n,s,r=-1){this.tensors=e,this.elementShape=n,this.elementDtype=s,e!=null&&e.forEach(a=>{if(s!==a.dtype)throw new Error(`Invalid data types; op elements ${s}, but list elements ${a.dtype}`);_e(n,a.shape,"TensorList shape mismatch: "),Oe(a)}),this.idTensor=M(0),this.maxNumElements=r,Oe(this.idTensor)}copy(){return new _t([...this.tensors],this.elementShape,this.elementDtype)}clearAndClose(e){this.tensors.forEach(n=>{(e==null||!e.has(n.id))&&n.dispose()}),this.tensors.length=0,this.idTensor.dispose()}size(){return this.tensors.length}stack(e,n,s=-1){if(n!==this.elementDtype)throw new Error(`Invalid data types; op elements ${n}, but list elements ${this.elementDtype}`);if(s!==-1&&this.tensors.length!==s)throw new Error(`Operation expected a list with ${s} elements but got a list with ${this.tensors.length} elements.`);_e(e,this.elementShape,"TensorList shape mismatch: ");const r=Kt(this.elementShape,this.tensors,e);return q(()=>{const a=this.tensors.map(o=>I(o,r));return We(a,0)})}popBack(e,n){if(n!==this.elementDtype)throw new Error(`Invalid data types; op elements ${n}, but list elements ${this.elementDtype}`);if(this.size()===0)throw new Error("Trying to pop from an empty list.");const s=Kt(this.elementShape,this.tensors,e),r=this.tensors.pop();return r.kept=!1,_e(r.shape,e,"TensorList shape mismatch: "),I(r,s)}pushBack(e){if(e.dtype!==this.elementDtype)throw new Error(`Invalid data types; op elements ${e.dtype}, but list elements ${this.elementDtype}`);if(_e(e.shape,this.elementShape,"TensorList shape mismatch: "),this.maxNumElements===this.size())throw new Error("Trying to push element into a full list.");Oe(e),this.tensors.push(e)}resize(e){if(e<0)throw new Error(`TensorListResize expects size to be non-negative. Got: ${e}`);if(this.maxNumElements!==-1&&e>this.maxNumElements)throw new Error(`TensorListResize input size ${e} is greater maxNumElement ${this.maxNumElements}.`);const n=new _t([],this.elementShape,this.elementDtype,this.maxNumElements);n.tensors.length=e;for(let s=0;s<Math.min(this.tensors.length,e);++s)n.tensors[s]=this.tensors[s];return n}getItem(e,n,s){if(s!==this.elementDtype)throw new Error(`Invalid data types; op elements ${s}, but list elements ${this.elementDtype}`);if(e<0||e>this.tensors.length)throw new Error(`Trying to access element ${e} in a list with ${this.tensors.length} elements.`);if(this.tensors[e]==null)throw new Error(`element at index ${e} is null.`);_e(this.tensors[e].shape,n,"TensorList shape mismatch: ");const r=Kt(this.elementShape,this.tensors,n);return I(this.tensors[e],r)}setItem(e,n){if(n.dtype!==this.elementDtype)throw new Error(`Invalid data types; op elements ${n.dtype}, but list elements ${this.elementDtype}`);if(e<0||this.maxNumElements!==-1&&e>=this.maxNumElements)throw new Error(`Trying to set element ${e} in a list with max ${this.maxNumElements} elements.`);_e(this.elementShape,n.shape,"TensorList shape mismatch: "),Oe(n),this.tensors[e]!=null&&(this.tensors[e].kept=!1),this.tensors[e]=n}gather(e,n,s){if(n!==this.elementDtype)throw new Error(`Invalid data types; op elements ${n}, but list elements ${this.elementDtype}`);_e(this.elementShape,s,"TensorList shape mismatch: "),e=e.slice(0,this.size());const r=Kt(this.elementShape,this.tensors,s);return e.length===0?De([],[0].concat(r)):q(()=>{const a=e.map(o=>I(this.tensors[o],r));return We(a,0)})}concat(e,n){if(e&&e!==this.elementDtype)throw new Error(`TensorList dtype is ${this.elementDtype} but concat requested dtype ${e}`);_e(this.elementShape,n,"TensorList shape mismatch: ");const s=Kt(this.elementShape,this.tensors,n);return this.size()===0?De([],[0].concat(s)):q(()=>{const r=this.tensors.map(a=>I(a,s));return he(r,0)})}}function tT(t,e,n){const s=t.dtype;if(t.shape.length<1)throw new Error(`Tensor must be at least a vector, but saw shape: ${t.shape}`);if(t.dtype!==n)throw new Error(`Invalid data types; op elements ${t.dtype}, but list elements ${n}`);const r=t.shape.slice(1);_e(r,e,"TensorList shape mismatch: ");const a=lt(t);return new _t(a,e,s)}function nT(t,e,n,s){return new _t([],t,e,s)}function sT(t,e,n,s){if(e.length!==t.shape[0])throw new Error(`Expected len(indices) == tensor.shape[0], but saw: ${e.length} vs. ${t.shape[0]}`);const r=Math.max(...e);if(s!=null&&s!==-1&&r>=s)throw new Error(`Max index must be < array size (${r}  vs. ${s})`);const a=new _t([],n,t.dtype,s),o=lt(t,0);return e.forEach((i,u)=>{a.setItem(i,o[u])}),a}function rT(t,e,n){let s=0;const r=e.map(h=>(s+=h,s));if(s!==t.shape[0])throw new Error(`Expected sum of lengths to be equal to
          tensor.shape[0], but sum of lengths is
        ${s}, and tensor's shape is: ${t.shape}`);const a=t.shape.slice(1),o=ar(a,n),i=s===0?0:t.size/s,u=q(()=>{const h=[];t=I(t,[1,s,i]);for(let l=0;l<e.length;++l){const m=[0,l===0?0:r[l-1],0],b=[1,e[l],i];h[l]=I(H(t,m,b),o)}return t.dispose(),h}),c=new _t([],n,t.dtype,e.length);for(let h=0;h<u.length;h++)c.setItem(h,u[h]);return c}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const aT=async(t,e,n)=>{switch(t.op){case"If":case"StatelessIf":{const s=p("thenBranch",t,e,n),r=p("elseBranch",t,e,n),a=p("cond",t,e,n),o=p("args",t,e,n);return(await a.data())[0]?n.functionMap[s].executeFunctionAsync(o,n.tensorArrayMap,n.tensorListMap):n.functionMap[r].executeFunctionAsync(o,n.tensorArrayMap,n.tensorListMap)}case"While":case"StatelessWhile":{const s=p("body",t,e,n),r=p("cond",t,e,n),a=p("args",t,e,n),o=await n.functionMap[r].executeFunctionAsync(a,n.tensorArrayMap,n.tensorListMap),i=a.map(h=>h.id);let u=await o[0].data();o.forEach(h=>{!h.kept&&i.indexOf(h.id)===-1&&h.dispose()});let c=a;for(;u[0];){const h=c;c=await n.functionMap[s].executeFunctionAsync(c,n.tensorArrayMap,n.tensorListMap);const l=c.map(m=>m.id);h.forEach(m=>{!m.kept&&i.indexOf(m.id)===-1&&l.indexOf(m.id)===-1&&m.dispose()});const f=await n.functionMap[r].executeFunctionAsync(c,n.tensorArrayMap,n.tensorListMap);u=await f[0].data(),f.forEach(m=>{!m.kept&&i.indexOf(m.id)===-1&&l.indexOf(m.id)===-1&&m.dispose()})}return c}case"LoopCond":{const s=p("pred",t,e,n);return[je(s)]}case"Switch":{const s=p("pred",t,e,n);let r=p("data",t,e,n);return r.kept||(r=je(r)),(await s.data())[0]?[void 0,r]:[r,void 0]}case"Merge":{const s=t.inputNames.find(r=>ce(r,e,n)!==void 0);if(s){const r=ce(s,e,n);return[je(r)]}return}case"Enter":{const s=p("frameName",t,e,n),r=p("tensor",t,e,n);return n.enterFrame(s),[je(r)]}case"Exit":{const s=p("tensor",t,e,n);return n.exitFrame(),[je(s)]}case"NextIteration":{const s=p("tensor",t,e,n);return n.nextIteration(),[je(s)]}case"TensorArrayV3":{const s=p("size",t,e,n),r=p("dtype",t,e,n),a=p("elementShape",t,e,n),o=p("dynamicSize",t,e,n),i=p("clearAfterRead",t,e,n),u=p("identicalElementShapes",t,e,n),c=p("name",t,e,n),h=new eT(c,r,s,a,u,o,i);return n.addTensorArray(h),[h.idTensor,M(1)]}case"TensorArrayWriteV3":{const s=p("tensorArrayId",t,e,n),r=p("index",t,e,n),a=p("tensor",t,e,n),o=n.getTensorArray(s.id);return o.write(r,a),[o.idTensor]}case"TensorArrayReadV3":{const s=p("tensorArrayId",t,e,n),r=p("index",t,e,n);return[n.getTensorArray(s.id).read(r)]}case"TensorArrayGatherV3":{const s=p("tensorArrayId",t,e,n),r=p("indices",t,e,n),a=p("dtype",t,e,n);return[n.getTensorArray(s.id).gather(r,a)]}case"TensorArrayScatterV3":{const s=p("tensorArrayId",t,e,n),r=p("indices",t,e,n),a=p("tensor",t,e,n),o=n.getTensorArray(s.id);return o.scatter(r,a),[o.idTensor]}case"TensorArrayConcatV3":{const s=p("tensorArrayId",t,e,n),r=n.getTensorArray(s.id),a=p("dtype",t,e,n);return[r.concat(a)]}case"TensorArraySplitV3":{const s=p("tensorArrayId",t,e,n),r=p("tensor",t,e,n),a=p("lengths",t,e,n),o=n.getTensorArray(s.id);return o.split(a,r),[o.idTensor]}case"TensorArraySizeV3":{const s=p("tensorArrayId",t,e,n),r=n.getTensorArray(s.id);return[M(r.size(),"int32")]}case"TensorArrayCloseV3":{const s=p("tensorArrayId",t,e,n),r=n.getTensorArray(s.id);return r.clearAndClose(),[r.idTensor]}case"TensorListSetItem":{const s=p("tensorListId",t,e,n),r=p("index",t,e,n),a=p("tensor",t,e,n),o=n.getTensorList(s.id);return o.setItem(r,a),[o.idTensor]}case"TensorListGetItem":{const s=p("tensorListId",t,e,n),r=p("index",t,e,n),a=p("elementShape",t,e,n),o=p("elementDType",t,e,n);return[n.getTensorList(s.id).getItem(r,a,o)]}case"TensorListScatterV2":case"TensorListScatter":{const s=p("indices",t,e,n),r=p("tensor",t,e,n),a=p("elementShape",t,e,n),o=p("numElements",t,e,n),i=sT(r,s,a,o);return n.addTensorList(i),[i.idTensor]}case"TensorListReserve":case"EmptyTensorList":{const s=p("elementShape",t,e,n),r=p("elementDType",t,e,n);let a;t.op==="TensorListReserve"?a="numElements":a="maxNumElements";const o=p(a,t,e,n),i=t.op==="TensorListReserve"?-1:o,u=nT(s,r,o,i);return n.addTensorList(u),[u.idTensor]}case"TensorListGather":{const s=p("tensorListId",t,e,n),r=p("indices",t,e,n),a=p("elementShape",t,e,n),o=p("elementDType",t,e,n);return[n.getTensorList(s.id).gather(r,o,a)]}case"TensorListStack":{const s=p("tensorListId",t,e,n),r=p("elementShape",t,e,n),a=p("elementDType",t,e,n),o=p("numElements",t,e,n);return[n.getTensorList(s.id).stack(r,a,o)]}case"TensorListFromTensor":{const s=p("tensor",t,e,n),r=p("elementShape",t,e,n),a=p("elementDType",t,e,n),o=tT(s,r,a);return n.addTensorList(o),[o.idTensor]}case"TensorListConcat":case"TensorListConcatV2":{const s=p("tensorListId",t,e,n),r=n.getTensorList(s.id),a=p("dtype",t,e,n),o=p("elementShape",t,e,n);return[r.concat(a,o)]}case"TensorListPushBack":{const s=p("tensorListId",t,e,n),r=p("tensor",t,e,n),a=n.getTensorList(s.id);return a.pushBack(r),[a.idTensor]}case"TensorListPopBack":{const s=p("tensorListId",t,e,n),r=p("elementShape",t,e,n),a=p("elementDType",t,e,n);return[n.getTensorList(s.id).popBack(r,a)]}case"TensorListSplit":{const s=p("tensor",t,e,n),r=p("elementShape",t,e,n),a=p("lengths",t,e,n),o=rT(s,a,r);return n.addTensorList(o),[o.idTensor]}case"TensorListLength":{const s=p("tensorListId",t,e,n),r=n.getTensorList(s.id);return[M(r.size(),"int32")]}case"TensorListResize":{const s=p("tensorListId",t,e,n),r=p("size",t,e,n),o=n.getTensorList(s.id).resize(r);return n.addTensorList(o),[o.idTensor]}default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Xa(t,e,n){const[s,r]=p("fusedOps",t,e,n),a=s==="biasadd",o=!a,i=r==="prelu",u=s==="fusedbatchnorm",c=p("numArgs",t,e,n);if(a){if(i&&c!==2)throw new Error("FusedConv2d and DepthwiseConv2d with BiasAdd and Prelu must have two extra arguments: bias and alpha.");if(!i&&a&&c!==1)throw new Error("FusedConv2d and DepthwiseConv2d with BiasAdd must have one extra argument: bias.")}if(u)throw new Error("FusedConv2d and DepthwiseConv2d with FusedBatchNorm is not supported");const h=p("strides",t,e,n),l=Wn(t,e,n),f=p("dataFormat",t,e,n).toUpperCase(),m=p("dilations",t,e,n);let[b,T]=p("args",t,e,n);o&&(T=b,b=void 0);const S=p("leakyreluAlpha",t,e,n);return{stride:h,pad:l,dataFormat:f,dilations:m,biasArg:b,preluArg:T,activationFunc:r,leakyreluAlpha:S}}const oT=(t,e,n,s=le)=>{switch(t.op){case"Conv1D":{const r=p("stride",t,e,n),a=p("pad",t,e,n),o=p("dataFormat",t,e,n).toUpperCase(),i=p("dilation",t,e,n);return[s.conv1d(p("x",t,e,n),p("filter",t,e,n),r,a,o,i)]}case"Conv2D":{const r=p("strides",t,e,n),a=Wn(t,e,n),o=p("dataFormat",t,e,n).toUpperCase(),i=p("dilations",t,e,n);return[s.conv2d(p("x",t,e,n),p("filter",t,e,n),[r[1],r[2]],a,o,[i[1],i[2]])]}case"_FusedConv2D":{const{stride:r,pad:a,dataFormat:o,dilations:i,biasArg:u,preluArg:c,activationFunc:h,leakyreluAlpha:l}=Xa(t,e,n);return[s.fused.conv2d({x:p("x",t,e,n),filter:p("filter",t,e,n),strides:[r[1],r[2]],pad:a,dataFormat:o,dilations:[i[1],i[2]],bias:u,activation:h,preluActivationWeights:c,leakyreluAlpha:l})]}case"FusedDepthwiseConv2dNative":{const{stride:r,pad:a,dataFormat:o,dilations:i,biasArg:u,preluArg:c,activationFunc:h,leakyreluAlpha:l}=Xa(t,e,n);return[s.fused.depthwiseConv2d({x:p("x",t,e,n),filter:p("filter",t,e,n),strides:[r[1],r[2]],pad:a,dataFormat:o,dilations:[i[1],i[2]],bias:u,activation:h,preluActivationWeights:c,leakyreluAlpha:l})]}case"Conv2DBackpropInput":case"Conv2dTranspose":{const r=p("outputShape",t,e,n),a=p("strides",t,e,n),o=Wn(t,e,n);return[s.conv2dTranspose(p("x",t,e,n),p("filter",t,e,n),r,[a[1],a[2]],o)]}case"DepthwiseConv2dNative":case"DepthwiseConv2d":{const r=p("strides",t,e,n),a=Wn(t,e,n),o=p("dilations",t,e,n),i=p("dataFormat",t,e,n).toUpperCase();return[s.depthwiseConv2d(p("input",t,e,n),p("filter",t,e,n),[r[1],r[2]],a,i,[o[1],o[2]])]}case"Conv3D":{const r=p("strides",t,e,n),a=p("pad",t,e,n),o=p("dataFormat",t,e,n).toUpperCase(),i=p("dilations",t,e,n);return[s.conv3d(p("x",t,e,n),p("filter",t,e,n),[r[1],r[2],r[3]],a,o,[i[1],i[2],i[3]])]}case"AvgPool":{const r=p("strides",t,e,n),a=p("pad",t,e,n),o=p("kernelSize",t,e,n);return[s.avgPool(p("x",t,e,n),[o[1],o[2]],[r[1],r[2]],a)]}case"MaxPool":{const r=p("strides",t,e,n),a=p("pad",t,e,n),o=p("kernelSize",t,e,n);return[s.maxPool(p("x",t,e,n),[o[1],o[2]],[r[1],r[2]],a)]}case"MaxPoolWithArgmax":{const r=p("strides",t,e,n),a=p("pad",t,e,n),o=p("kernelSize",t,e,n),i=p("includeBatchInIndex",t,e,n),{result:u,indexes:c}=s.maxPoolWithArgmax(p("x",t,e,n),[o[1],o[2]],[r[1],r[2]],a,i);return[u,c]}case"AvgPool3D":{const r=p("strides",t,e,n),a=p("pad",t,e,n),o=p("kernelSize",t,e,n);return[s.avgPool3d(p("x",t,e,n),[o[1],o[2],o[3]],[r[1],r[2],r[3]],a)]}case"MaxPool3D":{const r=p("strides",t,e,n),a=p("pad",t,e,n),o=p("kernelSize",t,e,n);return[s.maxPool3d(p("x",t,e,n),[o[1],o[2],o[3]],[r[1],r[2],r[3]],a)]}case"Dilation2D":{const r=p("strides",t,e,n),a=p("pad",t,e,n),o=p("dilations",t,e,n),i=r[1],u=r[2],c=o[1],h=o[2];return[s.dilation2d(p("x",t,e,n),p("filter",t,e,n),[i,u],a,[c,h],"NHWC")]}default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const iT=(t,e,n,s=le)=>{switch(t.op){case"Fill":{const r=p("shape",t,e,n),a=p("dtype",t,e,n),o=p("value",t,e,n);return[s.fill(r,o,a)]}case"LinSpace":{const r=p("start",t,e,n),a=p("stop",t,e,n),o=p("num",t,e,n);return[s.linspace(r,a,o)]}case"Multinomial":{const r=p("logits",t,e,n),a=p("numSamples",t,e,n),o=p("seed",t,e,n);return[s.multinomial(r,a,o)]}case"OneHot":{const r=p("indices",t,e,n),a=p("depth",t,e,n),o=p("onValue",t,e,n),i=p("offValue",t,e,n),u=p("dtype",t,e,n);return[s.oneHot(r,a,o,i,u)]}case"Ones":return[s.ones(p("shape",t,e,n),p("dtype",t,e,n))];case"OnesLike":return[s.onesLike(p("x",t,e,n))];case"RandomStandardNormal":return[s.randomStandardNormal(p("shape",t,e,n),p("dtype",t,e,n),p("seed",t,e,n))];case"RandomUniform":return[s.randomUniform(p("shape",t,e,n),p("minval",t,e,n),p("maxval",t,e,n),p("dtype",t,e,n))];case"RandomUniformInt":return[s.randomUniformInt(p("shape",t,e,n),p("minval",t,e,n),p("maxval",t,e,n),p("seed",t,e,n))];case"Range":{const r=p("start",t,e,n),a=p("stop",t,e,n),o=p("step",t,e,n);return[s.range(r,a,o,p("dtype",t,e,n))]}case"TruncatedNormal":{const r=p("shape",t,e,n),a=p("mean",t,e,n),o=p("stdDev",t,e,n),i=p("seed",t,e,n);return[s.truncatedNormal(r,a,o,p("dtype",t,e,n),i)]}case"Zeros":return[s.zeros(p("shape",t,e,n),p("dtype",t,e,n))];case"ZerosLike":return[s.zerosLike(p("x",t,e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Is(t,e,n){const s=p("boxes",t,e,n),r=p("scores",t,e,n),a=p("maxOutputSize",t,e,n),o=p("iouThreshold",t,e,n),i=p("scoreThreshold",t,e,n),u=p("softNmsSigma",t,e,n);return{boxes:s,scores:r,maxOutputSize:a,iouThreshold:o,scoreThreshold:i,softNmsSigma:u}}const uT=async(t,e,n,s,r=le)=>{switch(t.op){case"NonMaxSuppressionV5":{const{boxes:a,scores:o,maxOutputSize:i,iouThreshold:u,scoreThreshold:c,softNmsSigma:h}=Is(t,e,n),l=await r.image.nonMaxSuppressionWithScoreAsync(a,o,i,u,c,h);return[l.selectedIndices,l.selectedScores]}case"NonMaxSuppressionV4":{const{boxes:a,scores:o,maxOutputSize:i,iouThreshold:u,scoreThreshold:c}=Is(t,e,n),h=p("padToMaxOutputSize",t,e,n),l=await r.image.nonMaxSuppressionPaddedAsync(a,o,i,u,c,h);return[l.selectedIndices,l.validOutputs]}case"NonMaxSuppressionV3":case"NonMaxSuppressionV2":{const{boxes:a,scores:o,maxOutputSize:i,iouThreshold:u,scoreThreshold:c}=Is(t,e,n);return[await r.image.nonMaxSuppressionAsync(a,o,i,u,c)]}case"Where":{const a=r.cast(p("condition",t,e,n),"bool"),o=[await r.whereAsync(a)];return a.dispose(),o}case"ListDiff":return r.setdiff1dAsync(p("x",t,e,n),p("y",t,e,n));default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const cT=(t,e,n,s=le)=>{switch(t.op){case"LowerBound":{const r=p("sortedSequence",t,e,n),a=p("values",t,e,n);return[s.lowerBound(r,a)]}case"TopKV2":{const r=p("x",t,e,n),a=p("k",t,e,n),o=p("sorted",t,e,n),i=s.topk(r,a,o);return[i.values,i.indices]}case"UpperBound":{const r=p("sortedSequence",t,e,n),a=p("values",t,e,n);return[s.upperBound(r,a)]}case"Unique":{const r=p("x",t,e,n),a=s.unique(r);return[a.values,a.indices]}case"UniqueV2":{const r=p("x",t,e,n),a=p("axis",t,e,n),o=s.unique(r,a);return[o.values,o.indices]}default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const lT=(t,e,n,s=le)=>{switch(t.op){case"Const":return e[t.name];case"PlaceholderWithDefault":const r=p("default",t,e,n);return[ce(t.name,e,n)||r];case"Placeholder":return[ce(t.name,e,n)];case"Identity":case"StopGradient":case"FakeQuantWithMinMaxVars":{const h=p("x",t,e,n);return[je(h)]}case"IdentityN":return p("x",t,e,n).map(h=>je(h));case"Snapshot":const a=p("x",t,e,n);return[je(a)];case"Shape":return[s.tensor1d(p("x",t,e,n).shape,"int32")];case"ShapeN":return p("x",t,e,n).map(h=>s.tensor1d(h.shape));case"Size":return[s.scalar(p("x",t,e,n).size,"int32")];case"Rank":return[s.scalar(p("x",t,e,n).rank,"int32")];case"NoOp":return[s.scalar(1)];case"Print":const o=p("x",t,e,n),i=p("data",t,e,n),u=p("message",t,e,n),c=p("summarize",t,e,n);console.warn("The graph has a tf.print() operation,usually used for debugging, which slows down performance."),console.log(u);for(let h=0;h<i.length;h++)console.log(Array.prototype.slice.call(i[h].dataSync()).slice(0,c));return[o];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class hT{get id(){return this.handle.id}constructor(e,n){this.keyDType=e,this.valueDType=n,this.handle=M(0),this.tensorMap=new Map,Oe(this.handle)}clearAndClose(){this.tensorMap.forEach(e=>e.dispose()),this.tensorMap.clear(),this.handle.dispose()}size(){return this.tensorMap.size}tensorSize(){return M(this.size(),"int32")}async import(e,n){this.checkKeyAndValueTensor(e,n);const s=await e.data();return this.tensorMap.forEach(r=>r.dispose()),this.tensorMap.clear(),q(()=>{const r=lt(n),a=s.length,o=r.length;g(a===o,()=>`The number of elements doesn't match, keys has ${a} elements, the values has ${o} elements.`);for(let i=0;i<a;i++){const u=s[i],c=r[i];Oe(c),this.tensorMap.set(u,c)}return this.handle})}async find(e,n){this.checkKeyAndValueTensor(e,n);const s=await e.data();return q(()=>{const r=[];for(let a=0;a<s.length;a++){const o=s[a],i=this.findWithDefault(o,n);r.push(i)}return We(r)})}findWithDefault(e,n){const s=this.tensorMap.get(e);return s??n}checkKeyAndValueTensor(e,n){if(e.dtype!==this.keyDType)throw new Error(`Expect key dtype ${this.keyDType}, but got ${e.dtype}`);if(n.dtype!==this.valueDType)throw new Error(`Expect value dtype ${this.valueDType}, but got ${n.dtype}`)}}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const pT=async(t,e,n,s)=>{switch(t.op){case"HashTable":case"HashTableV2":{const r=s.getHashTableHandleByName(t.name);if(r!=null)return[r];{const a=p("keyDType",t,e,n),o=p("valueDType",t,e,n),i=new hT(a,o);return s.addHashTable(t.name,i),[i.handle]}}case"InitializeTable":case"InitializeTableV2":case"LookupTableImport":case"LookupTableImportV2":{const r=p("tableHandle",t,e,n,s),a=p("keys",t,e,n),o=p("values",t,e,n);return[await s.getHashTableById(r.id).import(a,o)]}case"LookupTableFind":case"LookupTableFindV2":{const r=p("tableHandle",t,e,n,s),a=p("keys",t,e,n),o=p("defaultValue",t,e,n);return[await s.getHashTableById(r.id).find(a,o)]}case"LookupTableSize":case"LookupTableSizeV2":{const r=p("tableHandle",t,e,n,s);return[s.getHashTableById(r.id).tensorSize()]}default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const fT=(t,e,n,s=le)=>{switch(t.op){case"ResizeBilinear":{const r=p("images",t,e,n),a=p("size",t,e,n),o=p("alignCorners",t,e,n),i=p("halfPixelCenters",t,e,n);return[s.image.resizeBilinear(r,[a[0],a[1]],o,i)]}case"ResizeNearestNeighbor":{const r=p("images",t,e,n),a=p("size",t,e,n),o=p("alignCorners",t,e,n),i=p("halfPixelCenters",t,e,n);return[s.image.resizeNearestNeighbor(r,[a[0],a[1]],o,i)]}case"CropAndResize":{const r=p("image",t,e,n),a=p("boxes",t,e,n),o=p("boxInd",t,e,n),i=p("cropSize",t,e,n),u=p("method",t,e,n),c=p("extrapolationValue",t,e,n);return[s.image.cropAndResize(r,a,o,i,u,c)]}case"ImageProjectiveTransformV3":{const r=p("images",t,e,n),a=p("transforms",t,e,n),o=p("outputShape",t,e,n),i=p("fillValue",t,e,n),u=p("interpolation",t,e,n),c=p("fillMode",t,e,n);return[s.image.transform(r,a,u.toLowerCase(),c.toLowerCase(),i,o)]}default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const dT=(t,e,n,s=le)=>{switch(t.op){case"Equal":return[s.equal(p("a",t,e,n),p("b",t,e,n))];case"NotEqual":return[s.notEqual(p("a",t,e,n),p("b",t,e,n))];case"Greater":return[s.greater(p("a",t,e,n),p("b",t,e,n))];case"GreaterEqual":return[s.greaterEqual(p("a",t,e,n),p("b",t,e,n))];case"Less":return[s.less(p("a",t,e,n),p("b",t,e,n))];case"LessEqual":return[s.lessEqual(p("a",t,e,n),p("b",t,e,n))];case"LogicalAnd":return[s.logicalAnd(p("a",t,e,n),p("b",t,e,n))];case"LogicalNot":return[s.logicalNot(p("a",t,e,n))];case"LogicalOr":return[s.logicalOr(p("a",t,e,n),p("b",t,e,n))];case"Select":case"SelectV2":return[s.where(p("condition",t,e,n),p("a",t,e,n),p("b",t,e,n))];case"BitwiseAnd":return[s.bitwiseAnd(p("a",t,e,n),p("b",t,e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const mT=(t,e,n,s=le)=>{switch(t.op){case"BatchMatMul":case"BatchMatMulV2":case"MatMul":return[s.matMul(p("a",t,e,n),p("b",t,e,n),p("transposeA",t,e,n),p("transposeB",t,e,n))];case"Einsum":return[s.einsum(p("equation",t,e,n),...p("tensors",t,e,n))];case"Transpose":return[s.transpose(p("x",t,e,n),p("perm",t,e,n))];case"_FusedMatMul":const[r,a]=p("fusedOps",t,e,n),o=r==="biasadd",i=a==="prelu",u=p("numArgs",t,e,n),c=p("leakyreluAlpha",t,e,n);if(o){if(i&&u!==2)throw new Error("Fused MatMul with BiasAdd and Prelu must have two extra arguments: bias and alpha.");if(!i&&u!==1)throw new Error("Fused MatMul with BiasAdd must have one extra argument: bias.")}const[h,l]=p("args",t,e,n);return[s.fused.matMul({a:p("a",t,e,n),b:p("b",t,e,n),transposeA:p("transposeA",t,e,n),transposeB:p("transposeB",t,e,n),bias:h,activation:a,preluActivationWeights:l,leakyreluAlpha:c})];case"MatrixBandPart":return[s.linalg.bandPart(p("a",t,e,n),p("numLower",t,e,n),p("numUpper",t,e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const gT=(t,e,n,s=le)=>{switch(t.op){case"EuclideanNorm":return[s.euclideanNorm(p("x",t,e,n),p("axis",t,e,n),p("keepDims",t,e,n))];case"FusedBatchNorm":case"FusedBatchNormV2":return[s.batchNorm(p("x",t,e,n),p("mean",t,e,n),p("variance",t,e,n),p("offset",t,e,n),p("scale",t,e,n),p("epsilon",t,e,n))];case"FusedBatchNormV3":return[s.batchNorm(p("x",t,e,n),p("mean",t,e,n),p("variance",t,e,n),p("offset",t,e,n),p("scale",t,e,n),p("epsilon",t,e,n))];case"LRN":return[s.localResponseNormalization(p("x",t,e,n),p("radius",t,e,n),p("bias",t,e,n),p("alpha",t,e,n),p("beta",t,e,n))];case"Softmax":return[s.softmax(p("x",t,e,n))];case"LogSoftmax":return[s.logSoftmax(p("x",t,e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const yT=(t,e,n,s=le)=>{switch(t.op){case"RaggedGather":{const{outputNestedSplits:r,outputDenseValues:a}=s.raggedGather(p("paramsNestedSplits",t,e,n),p("paramsDenseValues",t,e,n),p("indices",t,e,n),p("outputRaggedRank",t,e,n));return r.concat(a)}case"RaggedRange":{const{rtNestedSplits:r,rtDenseValues:a}=s.raggedRange(p("starts",t,e,n),p("limits",t,e,n),p("splits",t,e,n));return[r,a]}case"RaggedTensorToTensor":return[s.raggedTensorToTensor(p("shape",t,e,n),p("values",t,e,n),p("defaultValue",t,e,n),p("rowPartitionTensors",t,e,n),p("rowPartitionTypes",t,e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const bT=(t,e,n,s=le)=>{switch(t.op){case"Max":{const i=p("axis",t,e,n),u=p("keepDims",t,e,n);return[s.max(p("x",t,e,n),i,u)]}case"Mean":{const i=p("axis",t,e,n),u=p("keepDims",t,e,n);return[s.mean(p("x",t,e,n),i,u)]}case"Min":{const i=p("axis",t,e,n),u=p("keepDims",t,e,n);return[s.min(p("x",t,e,n),i,u)]}case"Sum":{const i=p("axis",t,e,n),u=p("keepDims",t,e,n);return[s.sum(p("x",t,e,n),i,u)]}case"All":{const i=p("axis",t,e,n),u=p("keepDims",t,e,n);return[s.all(p("x",t,e,n),i,u)]}case"Any":{const i=p("axis",t,e,n),u=p("keepDims",t,e,n);return[s.any(p("x",t,e,n),i,u)]}case"ArgMax":{const i=p("axis",t,e,n);return[s.argMax(p("x",t,e,n),i)]}case"ArgMin":{const i=p("axis",t,e,n);return[s.argMin(p("x",t,e,n),i)]}case"Prod":{const i=p("axis",t,e,n),u=p("keepDims",t,e,n);return[s.prod(p("x",t,e,n),i,u)]}case"Cumprod":{const i=p("axis",t,e,n),u=p("exclusive",t,e,n),c=p("reverse",t,e,n);return[s.cumprod(p("x",t,e,n),i,u,c)]}case"Cumsum":{const i=p("axis",t,e,n),u=p("exclusive",t,e,n),c=p("reverse",t,e,n);return[s.cumsum(p("x",t,e,n),i,u,c)]}case"Bincount":const r=p("x",t,e,n),a=p("weights",t,e,n),o=p("size",t,e,n);return[s.bincount(r,a,o)];case"DenseBincount":{const i=p("x",t,e,n),u=p("weights",t,e,n),c=p("size",t,e,n),h=p("binaryOutput",t,e,n);return[s.denseBincount(i,u,c,h)]}default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const wT=(t,e,n,s=le)=>{switch(t.op){case"ConcatV2":case"Concat":{const r=p("n",t,e,n),a=p("axis",t,e,n);let o=p("tensors",t,e,n);return o=o.slice(0,r),[s.concat(o,a)]}case"Gather":{const r=p("x",t,e,n),a=p("indices",t,e,n);return[s.gather(r,s.cast(a,"int32"),0)]}case"GatherV2":{const r=p("axis",t,e,n),a=p("batchDims",t,e,n),o=p("x",t,e,n),i=p("indices",t,e,n);return[s.gather(o,s.cast(i,"int32"),r,a)]}case"Reverse":{const r=p("dims",t,e,n),a=[];for(let i=0;i<r.length;i++)r[i]&&a.push(i);const o=p("x",t,e,n);return[s.reverse(o,a)]}case"ReverseV2":{const r=p("axis",t,e,n),a=p("x",t,e,n);return[s.reverse(a,r)]}case"Slice":{const r=p("begin",t,e,n),a=p("size",t,e,n);return[s.slice(p("x",t,e,n),r,a)]}case"StridedSlice":{const r=p("begin",t,e,n),a=p("end",t,e,n),o=p("strides",t,e,n),i=p("beginMask",t,e,n),u=p("endMask",t,e,n),c=p("ellipsisMask",t,e,n),h=p("newAxisMask",t,e,n),l=p("shrinkAxisMask",t,e,n),f=p("x",t,e,n);return[s.stridedSlice(f,r,a,o,i,u,c,h,l)]}case"Pack":return q(()=>{const r=p("axis",t,e,n),a=p("tensors",t,e,n),o=a[0].shape,i=s.squeeze(a[0]).shape,u=a.map(c=>{const h=Ce(c.shape,o);if(!h&&!Ce(s.squeeze(c).shape,i))throw new Error("the input tensors shape does not match");return h?c:s.reshape(c,o)});return[s.stack(u,r)]});case"Unpack":{const r=p("axis",t,e,n),a=p("tensor",t,e,n);return s.unstack(a,r)}case"Tile":{const r=p("reps",t,e,n);return[s.tile(p("x",t,e,n),r)]}case"Split":case"SplitV":{const r=p("axis",t,e,n),a=p("numOrSizeSplits",t,e,n),o=p("x",t,e,n);return s.split(o,a,r)}case"ScatterNd":{const r=p("indices",t,e,n),a=p("values",t,e,n),o=p("shape",t,e,n);return[s.scatterND(r,a,o)]}case"GatherNd":{const r=p("x",t,e,n),a=p("indices",t,e,n);return[s.gatherND(r,a)]}case"SparseToDense":{const r=p("sparseIndices",t,e,n),a=p("outputShape",t,e,n),o=p("sparseValues",t,e,n),i=p("defaultValue",t,e,n);return[s.sparseToDense(r,o,a,o.dtype===i.dtype?i:s.cast(i,o.dtype))]}case"TensorScatterUpdate":{const r=p("indices",t,e,n),a=p("values",t,e,n),o=p("tensor",t,e,n);return[s.tensorScatterUpdate(o,r,a)]}default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const NT=(t,e,n,s=le)=>{switch(t.op){case"SparseFillEmptyRows":{const{outputIndices:r,outputValues:a,emptyRowIndicator:o,reverseIndexMap:i}=s.sparse.sparseFillEmptyRows(p("indices",t,e,n),p("values",t,e,n),p("denseShape",t,e,n),p("defaultValue",t,e,n));return[r,a,o,i]}case"SparseReshape":{const{outputIndices:r,outputShape:a}=s.sparse.sparseReshape(p("inputIndices",t,e,n),p("inputShape",t,e,n),p("newShape",t,e,n));return[r,a]}case"SparseSegmentMean":return[s.sparse.sparseSegmentMean(p("data",t,e,n),p("indices",t,e,n),p("segmentIds",t,e,n))];case"SparseSegmentSum":return[s.sparse.sparseSegmentSum(p("data",t,e,n),p("indices",t,e,n),p("segmentIds",t,e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const ST=(t,e,n,s=le)=>{switch(t.op){case"FFT":return[s.fft(p("x",t,e,n))];case"IFFT":return[s.ifft(p("x",t,e,n))];case"RFFT":return[s.rfft(p("x",t,e,n))];case"IRFFT":return[s.irfft(p("x",t,e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const TT=(t,e,n,s=le)=>{switch(t.op){case"StaticRegexReplace":return[s.string.staticRegexReplace(p("input",t,e,n),p("pattern",t,e,n),p("rewrite",t,e,n),p("replaceGlobal",t,e,n))];case"StringNGrams":{const{nGrams:r,nGramsSplits:a}=s.string.stringNGrams(p("data",t,e,n),p("dataSplits",t,e,n),p("separator",t,e,n),p("nGramWidths",t,e,n),p("leftPad",t,e,n),p("rightPad",t,e,n),p("padWidth",t,e,n),p("preserveShortSequences",t,e,n));return[r,a]}case"StringSplit":{const{indices:r,values:a,shape:o}=s.string.stringSplit(p("input",t,e,n),p("delimiter",t,e,n),p("skipEmpty",t,e,n));return[r,a,o]}case"StringToHashBucketFast":return[s.string.stringToHashBucketFast(p("input",t,e,n),p("numBuckets",t,e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const $T=(t,e,n,s=le)=>{switch(t.op){case"Cast":return[s.cast(p("x",t,e,n),p("dtype",t,e,n))];case"ExpandDims":{const r=p("axis",t,e,n);return[s.expandDims(p("x",t,e,n),r)]}case"Squeeze":{const r=p("axis",t,e,n);return[s.squeeze(p("x",t,e,n),r)]}case"Reshape":return[s.reshape(p("x",t,e,n),p("shape",t,e,n))];case"EnsureShape":return[s.ensureShape(p("x",t,e,n),p("shape",t,e,n))];case"MirrorPad":return[s.mirrorPad(p("x",t,e,n),p("padding",t,e,n),p("mode",t,e,n))];case"PadV2":case"Pad":return[s.pad(p("x",t,e,n),p("padding",t,e,n),p("constantValue",t,e,n))];case"SpaceToBatchND":{const r=p("blockShape",t,e,n),a=p("paddings",t,e,n);return[s.spaceToBatchND(p("x",t,e,n),r,a)]}case"BatchToSpaceND":{const r=p("blockShape",t,e,n),a=p("crops",t,e,n);return[s.batchToSpaceND(p("x",t,e,n),r,a)]}case"DepthToSpace":{const r=p("blockSize",t,e,n),a=p("dataFormat",t,e,n).toUpperCase();return[s.depthToSpace(p("x",t,e,n),r,a)]}case"BroadcastTo":return[s.broadcastTo(p("x",t,e,n),p("shape",t,e,n))];case"BroadcastArgs":return[s.broadcastArgs(p("s0",t,e,n),p("s1",t,e,n))];default:throw TypeError(`Node type ${t.op} is not implemented`)}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Za(t,e,n,s,r=q){const a=((o,i,u)=>{switch(o.category){case"arithmetic":return r(()=>YS(o,i,u));case"basic_math":return r(()=>QS(o,i,u));case"control":return aT(o,i,u);case"convolution":return r(()=>oT(o,i,u));case"creation":return r(()=>iT(o,i,u));case"dynamic":return uT(o,i,u);case"evaluation":return r(()=>cT(o,i,u));case"image":return r(()=>fT(o,i,u));case"graph":return r(()=>lT(o,i,u));case"logical":return r(()=>dT(o,i,u));case"matrices":return r(()=>mT(o,i,u));case"normalization":return r(()=>gT(o,i,u));case"ragged":return r(()=>yT(o,i,u));case"reduction":return r(()=>bT(o,i,u));case"slice_join":return r(()=>wT(o,i,u));case"sparse":return r(()=>NT(o,i,u));case"spectral":return r(()=>ST(o,i,u));case"string":return r(()=>TT(o,i,u));case"transformation":return r(()=>$T(o,i,u));case"hash_table":return pT(o,i,u,s);case"custom":const c=$p(o.op);if(c&&c.customExecutor)return c.customExecutor(new JS(o,i,u));throw TypeError(`Custom op ${o.op} is not registered.`);default:throw TypeError(`Unknown op '${o.op}'. File an issue at https://github.com/tensorflow/tfjs/issues so we can add it, or register a custom execution with tf.registerOp()`)}})(t,e,n);return rt(a)?a.then(o=>[].concat(o)):[].concat(a)}class Ja{constructor(e={},n={},s={},r={},a){this.weightMap=e,this.tensorArrayMap=n,this.tensorListMap=s,this.functionMap=r,this.parseNodeNameCache=a,this.rootContext={id:0,frameName:"",iterationId:0},this.contexts=[this.rootContext],this.lastId=0,this.generateCurrentContextIds()}newFrame(e,n){return{id:e,frameName:n,iterationId:0}}set currentContext(e){this.contexts!==e&&(this.contexts=e,this.generateCurrentContextIds())}get currentContext(){return this.contexts}get currentContextId(){return this._currentContextIds[0]}get currentContextIds(){return this._currentContextIds}generateCurrentContextIds(){const e=[];for(let n=0;n<this.contexts.length-1;n++){const s=this.contexts.slice(0,this.contexts.length-n);e.push(this.contextIdforContexts(s))}e.push(""),this._currentContextIds=e}contextIdforContexts(e){return e?e.map(n=>n.id===0&&n.iterationId===0?"":`${n.frameName}-${n.iterationId}`).join("/"):""}enterFrame(e){this.contexts&&(this.lastId++,this.contexts=this.contexts.slice(),this.contexts.push(this.newFrame(this.lastId,e)),this._currentContextIds.unshift(this.contextIdforContexts(this.contexts)))}exitFrame(){if(this.contexts&&this.contexts.length>1)this.contexts=this.contexts.slice(),this.contexts.splice(-1),this.currentContextIds.shift();else throw new Error("Cannot exit frame, the context is empty")}nextIteration(){if(this.contexts&&this.contexts.length>0){this.contexts=this.contexts.slice(),this.lastId++;const e=Object.assign({},this.contexts[this.contexts.length-1]);e.iterationId+=1,e.id=this.lastId,this.contexts.splice(-1,1,e),this._currentContextIds.splice(0,1,this.contextIdforContexts(this.contexts))}else throw new Error("Cannot increase frame iteration, the context is empty")}getWeight(e){return this.weightMap[e]}addTensorArray(e){this.tensorArrayMap[e.id]=e}getTensorArray(e){return this.tensorArrayMap[e]}addTensorList(e){this.tensorListMap[e.id]=e}getTensorList(e){return this.tensorListMap[e]}dispose(e){for(const n in this.tensorArrayMap)this.tensorArrayMap[n].clearAndClose(e);for(const n in this.tensorListMap)this.tensorListMap[n].clearAndClose(e)}}/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function Ya(t,e,n,s){const r=new Set,a=[];let o=null,i=null;const u=new Set,c=new Set(Object.keys(t).map(f=>Ne(f)[0]));s=s||[];const h=new Set(s.map(f=>Ne(f.name)[0])),l=[...e];for(;l.length>0;){const f=l.pop();if((gt(f)||OT(f)||DT(f))&&o==null&&(o=f,i=o.children.map(m=>m.name).filter(m=>r.has(m))),r.add(f.name),n[f.name]==null&&!c.has(f.name)&&!h.has(f.name)){if(f.inputs.length===0){a.push(f.name);continue}f.inputs.forEach(m=>{u.has(m.name)||(u.add(m.name),l.push(m))})}}return{inputs:t,outputs:e,usedNodes:r,missingInputs:a,dynamicNode:o,syncInputs:i}}function ET(t,e){const{usedNodes:n,inputs:s}=e,r=Object.keys(s).map(S=>Ne(S)[0]).map(S=>t.nodes[S]),a=t.initNodes||[],o=S=>n.has(typeof S=="string"?S:S.name);function i(S){return[...new Map(S.map($=>[$.name,$])).values()]}const u=i([...r,...t.weights,...a]).filter(o),c=i([...u,...Object.values(t.nodes)]).filter(o),h=new Map(c.map(S=>[S.name,S])),l={};for(const S of c){l[S.name]=l[S.name]||0;for(const $ of S.children)o($)||(l[$.name]=Number.POSITIVE_INFINITY),l[$.name]=(l[$.name]||0)+1}const f=Object.entries(l).filter(([,S])=>S===0).map(([S])=>S),m=[...f];for(;f.length>0;){const S=f.pop(),$=h.get(S);for(const O of $.children.filter(o))--l[O.name]===0&&(m.push(O.name),f.push(O.name))}const b=m.map(S=>h.get(S)),T=kT(b,u);return vT(T,u),T}function kT(t,e){const n=new Map(t.map(o=>[o.name,o])),s=e.map(o=>o.name),r=new Set(s);for(;s.length>0;){const o=s.pop(),i=n.get(o);for(const u of i.children)!n.has(u.name)||r.has(u.name)||(r.add(u.name),s.push(u.name))}return t.filter(o=>r.has(o.name))}class An extends Error{constructor(e){super(`NodesExecutionOrderError: ${e}`)}}function vT(t,e){const n=new Map(t.map((i,u)=>[i.name,u])),s=new Set(e.map(i=>i.name)),r=i=>s.has(typeof i=="string"?i:i.name),a=new Set(t.map(i=>i.name)),o=i=>a.has(typeof i=="string"?i:i.name);for(const i of t){for(const u of i.children.filter(o)){if(!n.has(u.name))throw new An(`Child ${u.name} of node ${i.name} is unreachable.`);if(n.get(i.name)>n.get(u.name))throw new An(`Node ${i.name} is scheduled to run after its child ${u.name}.`)}if(!r(i))for(const u of i.inputs){if(!n.has(u.name))throw new An(`Input ${u.name} of node ${i.name} is unreachable.`);if(n.get(u.name)>n.get(i.name))throw new An(`Node ${i.name} is scheduled to run before its input ${u.name}.`)}}}function _T(t){const e=new Map(t.map((i,u)=>[i.name,u])),n=Number.MAX_SAFE_INTEGER,s=t.map((i,u)=>gt(i)?n:u),r=i=>{const u=s[e.get(i.name)];return u??-1},a=t.map((i,u)=>i.children.map(r).reduce((c,h)=>Math.max(c,h),s[u])),o=new Map;for(let i=0;i<t.length;++i){const u=a[i];if(u===n)continue;const c=t[i],h=t[u];o.has(h.name)||o.set(h.name,[]),o.get(h.name).push(c)}return o}const IT=new Set(["Switch","Merge","Enter","Exit","NextIteration","StatelessIf","StatelessWhile","if","While"]),xT=new Set(["NonMaxSuppressionV2","NonMaxSuppressionV3","NonMaxSuppressionV5","Where"]),AT=new Set(["HashTable","HashTableV2","LookupTableImport","LookupTableImportV2","LookupTableFind","LookupTableFindV2","LookupTableSize","LookupTableSizeV2"]);function gt(t){return IT.has(t.op)}function OT(t){return xT.has(t.op)}function DT(t){return AT.has(t.op)}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class ts{get weightIds(){return this.parent?this.parent.weightIds:this._weightIds}get functionExecutorMap(){return this.parent?this.parent.functionExecutorMap:this._functionExecutorMap}get weightMap(){return this.parent?this.parent.weightMap:this._weightMap}set weightMap(e){const n=Object.keys(e).map(s=>e[s].map(r=>r.id));this._weightIds=[].concat(...n),this._weightMap=e}set resourceManager(e){this._resourceManager=e}get inputs(){return this._inputs.map(e=>({name:e.name,shape:e.attrParams.shape?e.attrParams.shape.value:void 0,dtype:e.attrParams.dtype?e.attrParams.dtype.value:void 0}))}get outputs(){return this._outputs.map(e=>({name:e.name,shape:e.attrParams.shape?e.attrParams.shape.value:void 0,dtype:e.attrParams.dtype?e.attrParams.dtype.value:void 0}))}get inputNodes(){return this._inputs.map(e=>e.signatureKey||e.name)}get outputNodes(){return this._outputs.map(e=>{const n=e.signatureKey||e.name;return e.defaultOutput?`${n}:${e.defaultOutput}`:n})}get functions(){return Object.keys(this._functions).reduce((e,n)=>(e[n]=this._functions[n].signature,e),{})}constructor(e,n){this.graph=e,this.parent=n,this.compiledMap=new Map,this.parseNodeNameCache=new Map,this._weightMap={},this.SEPARATOR=",",this._functions={},this._functionExecutorMap={},this.keepIntermediateTensors=!1,this._outputs=e.outputs,this._inputs=e.inputs,this._initNodes=e.initNodes,this._signature=e.signature,this._functions=e.functions,e.functions!=null&&Object.keys(e.functions).forEach(s=>{this._functionExecutorMap[s]=new ts(e.functions[s],this)})}getCompilationKey(e,n){const s=e.map(a=>a.name).sort(),r=n.map(a=>a.name).sort();return s.join(this.SEPARATOR)+"--"+r.join(this.SEPARATOR)}compile(e,n){const s=Ya(e,n,this.weightMap,this._initNodes),{missingInputs:r,dynamicNode:a,syncInputs:o}=s;if(a!=null)throw new Error(`This execution contains the node '${a.name}', which has the dynamic op '${a.op}'. Please use model.executeAsync() instead. Alternatively, to avoid the dynamic ops, specify the inputs [${o}]`);if(r.length>0){const c=n.map(l=>l.name),h=Object.keys(e);throw new Error(`Cannot compute the outputs [${c}] from the provided inputs [${h}]. Missing the following inputs: [${r}]`)}const i=ET(this.graph,s),u=_T(i);return{orderedNodes:i,nodeLiveUntilMap:u}}cloneAndKeepTensor(e){if(e==null)return null;const n=e.clone();return Oe(n),n}cloneTensorList(e){return e?e.map(s=>this.cloneAndKeepTensor(s)):null}cloneTensorMap(e){return Object.fromEntries(Object.entries(e).map(([n,s])=>[n,this.cloneTensorList(s)]))}execute(e,n){this.disposeIntermediateTensors(),e=this.mapInputs(e);const s=Object.keys(e).sort();this.checkInputs(e),this.checkInputShapeAndType(e),n=this.mapOutputs(n),this.checkOutputs(n);const r=s.map(f=>this.graph.nodes[Ne(f)[0]]),a=n.map(f=>Ne(f)[0]),o=new Set(a);let i=a.map(f=>this.graph.nodes[f]);i.length===0&&(i=this._outputs);const u=this.getCompilationKey(r,i);let c=this.compiledMap.get(u);c==null&&(c=this.compile(e,i),this.compiledMap.set(u,c));try{this.keepIntermediateTensors=P().getBool("KEEP_INTERMEDIATE_TENSORS")}catch(f){this.keepIntermediateTensors=!1,console.warn(f.message)}const h={},l={};return q(()=>{const f=new Ja(this.weightMap,h,l,this.functionExecutorMap,this.parseNodeNameCache),m=Object.assign({},this.weightMap);this.keepIntermediateTensors&&(this.clonedTensorsMap=this.cloneTensorMap(this.weightMap)),Object.keys(e).forEach($=>{const[O,v]=Ne($,f),_=[];_[v]=e[$],m[O]=_,this.keepIntermediateTensors&&(this.clonedTensorsMap[O]=this.cloneTensorList(_))});const b=this.getFrozenTensorIds(m),{orderedNodes:T,nodeLiveUntilMap:S}=c;for(const $ of T){if(m[$.name])continue;const O=Za($,m,f,this._resourceManager);if(rt(O))throw new Error(`The execution of the op '${$.op}' returned a promise. Please use model.executeAsync() instead.`);m[$.name]=O,this.keepIntermediateTensors&&(this.clonedTensorsMap[$.name]=this.cloneTensorList(O)),this.checkTensorForDisposalWithNodeLiveUntilInfo($,m,f,b,o,S.get($.name))}return this.parent==null&&f.dispose(b),n.map($=>ce($,m,f))})}getFrozenTensorIds(e){const n=[].concat.apply([],Object.keys(e).map(s=>e[s]).map(s=>s.map(r=>r.id)));return new Set(n)}checkTensorForDisposal(e,n,s,r,a,o,i){if(!(gt(n)||o.has(e))){for(const u of s[e])u!=null&&(i[u.id]=(i[u.id]||0)+n.children.length);for(const u of n.inputs){if(gt(u))continue;const c=qa(u.name,s,r);if(c!=null)for(const h of c){if(!h||h.kept||a.has(h.id))continue;const l=i[h.id];l===1?(h.dispose(),delete i[h.id]):l!=null&&i[h.id]--}}}}checkTensorForDisposalWithNodeLiveUntilInfo(e,n,s,r,a,o){function i(u){return gt(u)||a.has(u.name)}if(!(gt(e)||o==null))for(const u of o){if(i(u))continue;const c=qa(u.name,n,s);for(const h of c)!h||h.kept||r.has(h.id)||h.dispose()}}async executeAsync(e,n){return this._executeAsync(e,n)}disposeIntermediateTensors(){this.clonedTensorsMap&&(Object.values(this.clonedTensorsMap).forEach(e=>{for(const n of e)n&&!n.isDisposed&&n.dispose()}),this.clonedTensorsMap=null)}getIntermediateTensors(){return this.clonedTensorsMap}async _executeAsync(e,n,s=!1,r={},a={}){this.disposeIntermediateTensors(),s||(e=this.mapInputs(e),this.checkInputs(e),this.checkInputShapeAndType(e),n=this.mapOutputs(n),this.checkOutputs(n));try{this.keepIntermediateTensors=P().getBool("KEEP_INTERMEDIATE_TENSORS")}catch(f){this.keepIntermediateTensors=!1,console.warn(f.message)}const o=new Ja(this.weightMap,r,a,this.functionExecutorMap,this.parseNodeNameCache);this.keepIntermediateTensors&&(this.clonedTensorsMap=this.cloneTensorMap(this.weightMap));const i=await this.executeWithControlFlow(e,o,n,s),u=n.map(f=>ce(f,i,o)),c=u.map(f=>f.id),h=Object.keys(e).map(f=>e[f].id),l=new Set([...c,...h,...this.weightIds]);return Object.values(i).forEach(f=>{f.forEach(m=>{m&&!m.isDisposed&&!l.has(m.id)&&m.dispose()})}),this.parent==null&&o.dispose(l),u}async executeFunctionAsync(e,n,s){const r=e.reduce((a,o,i)=>(a[this.inputs[i].name]=o,a),{});return this._executeAsync(r,this.outputNodes,!0,n,s)}async executeWithControlFlow(e,n,s,r){const a=Object.keys(e),o=a.map(_=>this.graph.nodes[Ne(_)[0]]),i=s.map(_=>Ne(_)[0]),u=new Set(i);let c=i.map(_=>this.graph.nodes[_]);c.length===0&&(c=this._outputs);const{usedNodes:h,missingInputs:l,dynamicNode:f,syncInputs:m}=Ya(e,c,this.weightMap,this._initNodes),b=[...o,...this.graph.weights,...this._initNodes||[]].map(_=>({node:_,contexts:n.currentContext})),T=Object.assign({},this.weightMap);Object.keys(e).forEach(_=>{const[A,F]=Ne(_),L=[];L[F]=e[_],T[A]=L});const S={},$=this.getFrozenTensorIds(T),O={};for(;b.length>0;){const _=this.processStack(o,b,n,T,O,$,u,S,h);await Promise.all(_)}f==null&&!r&&console.warn("This model execution did not contain any nodes with control flow or dynamic output shapes. You can use model.execute() instead.");const v=c.filter(_=>!gt(_)&&!ce(_.name,T,n)).map(_=>_.name);if(v.length>0){let _="";throw f!=null&&(_=`Alternatively, to avoid the dynamic ops, use model.execute() and specify the inputs [${m}]`),new Error(`Cannot compute the outputs [${v}] from the provided inputs [${a}]. Consider providing the following inputs: [${l}]. ${_}`)}return T}processStack(e,n,s,r,a,o,i,u,c){const h=[];for(;n.length>0;){const l=n.pop();s.currentContext=l.contexts;let f="";if(l.node.op==="Enter"&&p("isConstant",l.node,r,s)&&([f]=Ue(l.node.name,s)),r[l.node.name]==null){const m=Za(l.node,r,s,this._resourceManager);f||([f]=Ue(l.node.name,s));const b=s.currentContext;rt(m)?h.push(m.then(T=>(r[f]=T,this.keepIntermediateTensors&&(this.clonedTensorsMap[f]=this.cloneTensorList(T)),s.currentContext=b,this.checkTensorForDisposal(f,l.node,r,s,o,i,u),this.processChildNodes(l.node,n,s,r,a,c),T))):(r[f]=m,this.keepIntermediateTensors&&(this.clonedTensorsMap[f]=this.cloneTensorList(m)),this.checkTensorForDisposal(f,l.node,r,s,o,i,u),this.processChildNodes(l.node,n,s,r,a,c))}else this.processChildNodes(l.node,n,s,r,a,c)}return h}processChildNodes(e,n,s,r,a,o){e.children.forEach(i=>{const[u]=Ue(i.name,s);a[u]||!o.has(i.name)||(i.op==="Merge"?i.inputNames.some(c=>!!ce(c,r,s))&&(a[u]=!0,n.push({contexts:s.currentContext,node:i})):i.inputNames.every(c=>!!ce(c,r,s))&&(a[u]=!0,n.push({contexts:s.currentContext,node:i})))})}dispose(){Object.keys(this.weightMap).forEach(e=>this.weightMap[e].forEach(n=>n.dispose()))}checkInputShapeAndType(e){Object.keys(e).forEach(n=>{const s=e[n],[r]=Ne(n),a=this.graph.nodes[r];if(a.attrParams.shape&&a.attrParams.shape.value){const o=a.attrParams.shape.value,i=o.length===s.shape.length&&s.shape.every((u,c)=>o[c]===-1||o[c]===u);g(i,()=>`The shape of dict['${a.name}'] provided in model.execute(dict) must be [${o}], but was [${s.shape}]`)}a.attrParams.dtype&&a.attrParams.dtype.value&&g(s.dtype===a.attrParams.dtype.value,()=>`The dtype of dict['${a.name}'] provided in model.execute(dict) must be ${a.attrParams.dtype.value}, but was ${s.dtype}`)})}mapInputs(e){var n,s;const r={};for(const a in e){const o=(s=(n=this._signature)===null||n===void 0?void 0:n.inputs)===null||s===void 0?void 0:s[a];o!=null?r[o.name]=e[a]:r[a]=e[a]}return r}checkInputs(e){const n=Object.keys(e).filter(s=>{const[r]=Ne(s);return this.graph.nodes[r]==null});if(n.length>0)throw new Error(`The dict provided in model.execute(dict) has keys: [${n}] that are not part of graph`)}mapOutputs(e){return e.map(n=>{var s,r;const a=(r=(s=this._signature)===null||s===void 0?void 0:s.outputs)===null||r===void 0?void 0:r[n];return a!=null?a.name:n},{})}checkOutputs(e){e.forEach(n=>{const[s]=Ne(n);if(!this.graph.nodes[s])throw new Error(`The output '${n}' is not found in the graph`)})}}class FT{constructor(e={},n={}){this.hashTableNameToHandle=e,this.hashTableMap=n}addHashTable(e,n){this.hashTableNameToHandle[e]=n.handle,this.hashTableMap[n.id]=n}getHashTableHandleByName(e){return this.hashTableNameToHandle[e]}getHashTableById(e){return this.hashTableMap[e]}dispose(){for(const e in this.hashTableMap)this.hashTableMap[e].clearAndClose(),delete this.hashTableMap[e];for(const e in this.hashTableNameToHandle)this.hashTableNameToHandle[e].dispose(),delete this.hashTableNameToHandle[e]}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const CT="?tfjs-format=file",RT="model.json";class vp{get modelVersion(){return this.version}get inputNodes(){return this.executor.inputNodes}get outputNodes(){return this.executor.outputNodes}get inputs(){return this.executor.inputs}get outputs(){return this.executor.outputs}get weights(){return this.executor.weightMap}get metadata(){return this.artifacts.userDefinedMetadata}get modelSignature(){return this.signature}get modelStructuredOutputKeys(){return this.structuredOutputKeys}constructor(e,n={},s=ma){this.modelUrl=e,this.loadOptions=n,this.version="n/a",this.io=s,n==null&&(this.loadOptions={}),this.resourceManager=new FT}findIOHandler(){const e=this.modelUrl;if(e.load!=null)this.handler=e;else if(this.loadOptions.requestInit!=null)this.handler=this.io.browserHTTPRequest(e,this.loadOptions);else{const n=this.io.getLoadHandlers(e,this.loadOptions);if(n.length===0)n.push(this.io.browserHTTPRequest(e,this.loadOptions));else if(n.length>1)throw new Error(`Found more than one (${n.length}) load handlers for URL '${[e]}'`);this.handler=n[0]}}load(){if(this.findIOHandler(),this.handler.load==null)throw new Error("Cannot proceed with model loading because the IOHandler provided does not have the `load` method implemented.");const e=this.handler.load();return rt(e)?e.then(n=>n.getWeightStream==null?this.loadSync(n):this.loadStreaming(n)):this.loadSync(e)}loadSync(e){const n=this.io.decodeWeights(e.weightData,e.weightSpecs);return this.loadWithWeightMap(e,n)}async loadStreaming(e){if(e.getWeightStream==null)throw new Error("Model artifacts missing streamWeights function");const n=await Sc(e.getWeightStream(),e.weightSpecs);return this.loadWithWeightMap(e,n)}loadWithWeightMap(e,n){this.artifacts=e;const s=this.artifacts.modelTopology;let r=this.artifacts.signature;if(this.artifacts.userDefinedMetadata!=null){const a=this.artifacts.userDefinedMetadata;a.signature!=null&&(r=a.signature),a.structuredOutputKeys!=null&&(this.structuredOutputKeys=a.structuredOutputKeys)}if(this.signature=r,this.version=`${s.versions.producer}.${s.versions.minConsumer}`,this.executor=new ts(Ga.Instance.transformGraph(s,this.signature)),this.executor.weightMap=this.convertTensorMapToTensorsMap(n),this.executor.resourceManager=this.resourceManager,e.modelInitializer!=null&&e.modelInitializer.node!=null){const a=Ga.Instance.transformGraph(e.modelInitializer);this.initializer=new ts(a),this.initializer.weightMap=this.executor.weightMap,this.initializer.resourceManager=this.resourceManager,this.initializerSignature=e.initializerSignature}return!0}async save(e,n){if(typeof e=="string"){const s=this.io.getSaveHandlers(e);if(s.length===0)throw new Error(`Cannot find any save handlers for URL '${e}'`);if(s.length>1)throw new Error(`Found more than one (${s.length}) save handlers for URL '${e}'`);e=s[0]}if(e.save==null)throw new Error("GraphModel.save() cannot proceed because the IOHandler provided does not have the `save` attribute defined.");return e.save(this.artifacts)}addStructuredOutputNames(e){if(this.structuredOutputKeys){const n=e instanceof ne?[e]:e,s={};return n.forEach((r,a)=>s[this.structuredOutputKeys[a]]=r),s}return e}predict(e,n){const s=this.execute(e,this.outputNodes);return this.addStructuredOutputNames(s)}async predictAsync(e,n){const s=await this.executeAsync(e,this.outputNodes);return this.addStructuredOutputNames(s)}normalizeInputs(e){var n;if(!(e instanceof ne)&&!Array.isArray(e)){const a=(n=this.signature)===null||n===void 0?void 0:n.inputs;if(a!=null)for(const o in a){const i=a[o];i.resourceId!=null&&(e[o]=this.resourceIdToCapturedInput[i.resourceId])}return e}e=Array.isArray(e)?e:[e];const s=Object.keys(this.resourceIdToCapturedInput).length;if(e.length+s!==this.inputNodes.length)throw new Error(`Input tensor count mismatch, the graph model has ${this.inputNodes.length-s} non-resource placeholders, while there are ${e.length} input tensors provided.`);let r=0;return this.inputNodes.reduce((a,o)=>{var i,u,c;const h=(c=(u=(i=this.signature)===null||i===void 0?void 0:i.inputs)===null||u===void 0?void 0:u[o])===null||c===void 0?void 0:c.resourceId;return h!=null?a[o]=this.resourceIdToCapturedInput[h]:a[o]=e[r++],a},{})}normalizeOutputs(e){return e=e||this.outputNodes,Array.isArray(e)?e:[e]}executeInitializerGraph(){return this.initializer==null?[]:this.initializerSignature==null?this.initializer.execute({},[]):this.initializer.execute({},Object.keys(this.initializerSignature.outputs))}async executeInitializerGraphAsync(){return this.initializer==null?[]:this.initializerSignature==null?this.initializer.executeAsync({},[]):this.initializer.executeAsync({},Object.keys(this.initializerSignature.outputs))}setResourceIdToCapturedInput(e){if(this.resourceIdToCapturedInput={},this.initializerSignature){const n=this.initializerSignature.outputs,s=Object.keys(n);for(let r=0;r<s.length;r++){const a=s[r],o=n[a];this.resourceIdToCapturedInput[o.resourceId]=e[r]}}}execute(e,n){this.resourceIdToCapturedInput==null&&this.setResourceIdToCapturedInput(this.executeInitializerGraph()),e=this.normalizeInputs(e),n=this.normalizeOutputs(n);const s=this.executor.execute(e,n);return s.length>1?s:s[0]}async executeAsync(e,n){this.resourceIdToCapturedInput==null&&this.setResourceIdToCapturedInput(await this.executeInitializerGraphAsync()),e=this.normalizeInputs(e),n=this.normalizeOutputs(n);const s=await this.executor.executeAsync(e,n);return s.length>1?s:s[0]}getIntermediateTensors(){return this.executor.getIntermediateTensors()}disposeIntermediateTensors(){this.executor.disposeIntermediateTensors()}convertTensorMapToTensorsMap(e){return Object.keys(e).reduce((n,s)=>(n[s]=[e[s]],n),{})}dispose(){this.executor.dispose(),this.initializer&&(this.initializer.dispose(),this.resourceIdToCapturedInput&&me(this.resourceIdToCapturedInput)),this.resourceManager.dispose()}}async function WT(t,e={},n=ma){if(t==null)throw new Error("modelUrl in loadGraphModel() cannot be null. Please provide a url or an IOHandler that loads the model");e==null&&(e={}),e.fromTFHub&&typeof t=="string"&&(t=LT(t));const s=new vp(t,e,n);return await s.load(),s}function MT(t){if(t==null)throw new Error("modelUrl in loadGraphModelSync() cannot be null. Please provide model artifacts or an IOHandler that loads the model");let e;if(t instanceof Array){const[s,r]=t;if(!s)throw new Error("modelJSON must be the first element of the array");if(!r||!(r instanceof ArrayBuffer))throw new Error("An ArrayBuffer of weights must be the second element of the array");if(!("modelTopology"in s))throw new Error("Model JSON is missing 'modelTopology'");if(!("weightsManifest"in s))throw new Error("Model JSON is missing 'weightsManifest'");const a=Kn(s.weightsManifest),o=wr(s,a,r);e=Qn(o)}else if("load"in t)e=t;else if("modelTopology"in t&&"weightSpecs"in t&&"weightData"in t)e=Qn(t);else throw new Error("Unknown model format");const n=new vp(e);return n.load(),n}function LT(t){return t.endsWith("/")||(t=t+"/"),`${t}${RT}${CT}`}/** @license See the LICENSE file. */const UT="4.22.0";export{un as $,po as A,w as B,d as C,g as D,xe as E,N as F,tf as G,_o as H,ef as I,vo as J,Io as K,j as L,xo as M,jr as N,nf as O,hr as P,Fo as Q,Co as R,He as S,cn as T,Cr as U,os as V,Lo as W,Bo as X,dn as Y,Mt as Z,Po as _,fo as a,Vi as a$,k0 as a0,al as a1,Vo as a2,Sn as a3,sf as a4,Wo as a5,ng as a6,Uo as a7,yh as a8,jo as a9,Ch as aA,vg as aB,bi as aC,fr as aD,Si as aE,Ti as aF,$i as aG,Ei as aH,En as aI,xi as aJ,Ii as aK,cf as aL,hf as aM,Fi as aN,Tn as aO,Ir as aP,Ci as aQ,Ri as aR,Jn as aS,df as aT,Bi as aU,ff as aV,Li as aW,zi as aX,$g as aY,G as aZ,tt as a_,bh as aa,Go as ab,kg as ac,pl as ad,fn as ae,Zo as af,Xe as ag,x0 as ah,O0 as ai,ei as aj,af as ak,rf as al,si as am,of as an,ri as ao,it as ap,oi as aq,ii as ar,ui as as,pi as at,fi as au,di as av,ph as aw,Ft as ax,mi as ay,We as az,Ie as b,Ju as b$,Wi as b0,Mi as b1,H as b2,Ui as b3,Dr as b4,qi as b5,Gi as b6,Yi as b7,kt as b8,Ji as b9,TN as bA,_u as bB,vu as bC,Eu as bD,cl as bE,ku as bF,ll as bG,$u as bH,tN as bI,qt as bJ,Fu as bK,Iu as bL,wt as bM,Ou as bN,kr as bO,Du as bP,he as bQ,xu as bR,bf as bS,zu as bT,ec as bU,qu as bV,Au as bW,Gu as bX,Hu as bY,dr as bZ,On as b_,Qi as ba,lt as bb,eu as bc,tu as bd,zt as be,Pt as bf,nu as bg,su as bh,hl as bi,ti as bj,cu as bk,du as bl,lu as bm,hu as bn,fu as bo,yf as bp,pu as bq,gf as br,mu as bs,ut as bt,gu as bu,yu as bv,Su as bw,zr as bx,Tu as by,SN as bz,J as c,qr as c$,Yu as c0,Mr as c1,Fr as c2,Me as c3,Qu as c4,Sf as c5,cc as c6,Se as c7,Ac as c8,Oc as c9,ls as cA,Tr as cB,pn as cC,Qr as cD,vl as cE,_l as cF,Il as cG,Rr as cH,Al as cI,Dl as cJ,Fl as cK,Pr as cL,Lr as cM,Vr as cN,Cl as cO,Wr as cP,Nt as cQ,ln as cR,Zn as cS,hn as cT,zl as cU,Vl as cV,$n as cW,Ur as cX,Yn as cY,jl as cZ,Zl as c_,Fc as ca,Cc as cb,Rc as cc,Lc as cd,Bc as ce,Pc as cf,zc as cg,Vc as ch,Wc as ci,Er as cj,Nn as ck,Yt as cl,Yc as cm,Qc as cn,ne as co,rl as cp,ol as cq,dl as cr,as as cs,gl as ct,bl as cu,wl as cv,xr as cw,Sl as cx,El as cy,kl as cz,ze as d,ul as d$,Jl as d0,ih as d1,vn as d2,Jr as d3,yw as d4,ww as d5,hs as d6,Yr as d7,fh as d8,dh as d9,cs as dA,Dh as dB,Or as dC,ep as dD,rp as dE,Ye as dF,ap as dG,Lh as dH,Ce as dI,me as dJ,P as dK,iN as dL,uo as dM,Oe as dN,jt as dO,aN as dP,Ge as dQ,ht as dR,eo as dS,ld as dT,Fd as dU,Nd as dV,vd as dW,Cd as dX,x1 as dY,k1 as dZ,wc as d_,gh as da,$h as db,Br as dc,ea as dd,ps as de,Eh as df,kh as dg,Xn as dh,Oh as di,Fh as dj,nn as dk,bc as dl,q as dm,Th as dn,Sh as dp,Nh as dq,wh as dr,ke as ds,Zr as dt,R0 as du,sl as dv,nl as dw,tl as dx,el as dy,Uh as dz,W as e,GN as e$,Qh as e0,_0 as e1,il as e2,Wl as e3,Hc as e4,Kc as e5,Xc as e6,Ll as e7,qc as e8,De as e9,Ro as eA,ns as eB,uu as eC,ss as eD,jp as eE,iS as eF,Oo as eG,or as eH,ai as eI,yi as eJ,ki as eK,vi as eL,Df as eM,Hi as eN,rs as eO,_g as eP,hN as eQ,pN as eR,Le as eS,fN as eT,lN as eU,Hn as eV,Q1 as eW,eN as eX,uS as eY,X1 as eZ,qN as e_,Vt as ea,fl as eb,ie as ec,rt as ed,gr as ee,Hf as ef,Gr as eg,Ct as eh,q1 as ei,Cf as ej,Qa as ek,Dp as el,cd as em,Je as en,Qe as eo,yn as ep,xN as eq,qp as er,Gn as es,Pe as et,Bh as eu,Ut as ev,so as ew,yl as ex,Kp as ey,Hp as ez,M as f,DN as f$,HN as f0,KN as f1,XN as f2,ZN as f3,JN as f4,YN as f5,QN as f6,eS as f7,tS as f8,nS as f9,Ho as fA,qo as fB,ir as fC,Ko as fD,Xo as fE,Jo as fF,Yo as fG,Qo as fH,wm as fI,bt as fJ,Gp as fK,pr as fL,ni as fM,PN as fN,VN as fO,WN as fP,zN as fQ,MN as fR,IN as fS,_N as fT,vN as fU,kN as fV,EN as fW,$N as fX,FN as fY,AN as fZ,ON as f_,Vu as fa,Of as fb,Mn as fc,bd as fd,Up as fe,As as ff,yo as fg,Eg as fh,bo as fi,Mc as fj,Nm as fk,gN as fl,yN as fm,bN as fn,wN as fo,NN as fp,Ao as fq,Do as fr,Ni as fs,uN as ft,cN as fu,jc as fv,wn as fw,zo as fx,Uc as fy,Mo as fz,Z as g,mc as g$,RN as g0,LN as g1,CN as g2,ci as g3,li as g4,mn as g5,hi as g6,Os as g7,Ds as g8,gi as g9,Ru as gA,Lu as gB,Bu as gC,Pu as gD,jN as gE,Wu as gF,nN as gG,J1 as gH,Mu as gI,Uu as gJ,ju as gK,wu as gL,Ku as gM,Xu as gN,Qt as gO,Zu as gP,nc as gQ,Vp as gR,Jt as gS,Cp as gT,no as gU,ed as gV,cS as gW,Mp as gX,at as gY,Rp as gZ,Un as g_,pp as ga,aS as gb,wi as gc,_i as gd,Ai as ge,Oi as gf,Di as gg,Pi as gh,ji as gi,Ki as gj,Kh as gk,Xi as gl,Xh as gm,Zi as gn,Zh as go,ge as gp,ru as gq,au as gr,ou as gs,iu as gt,tc as gu,mN as gv,bu as gw,xh as gx,Nu as gy,Cu as gz,mo as h,Gl as h$,Rt as h0,dN as h1,Gf as h2,xs as h3,rS as h4,sS as h5,UT as h6,rN as h7,G1 as h8,ma as h9,ry as hA,Ol as hB,lo as hC,ur as hD,tp as hE,Jh as hF,qh as hG,Yh as hH,np as hI,sp as hJ,Dc as hK,Gc as hL,vr as hM,Zc as hN,Jc as hO,Ke as hP,ml as hQ,mt as hR,Nl as hS,kn as hT,xl as hU,Rl as hV,Bl as hW,Pl as hX,Ml as hY,Ul as hZ,ql as h_,L1 as ha,d1 as hb,wb as hc,Rf as hd,fg as he,Xf as hf,Sp as hg,H1 as hh,o0 as hi,td as hj,lS as hk,ia as hl,ua as hm,ca as hn,la as ho,ha as hp,Tp as hq,pa as hr,ws as hs,sn as ht,Rs as hu,de as hv,Ve as hw,ty as hx,ny as hy,sy as hz,lr as i,MT as i$,Hl as i0,Kl as i1,Xl as i2,Sr as i3,Yl as i4,Ql as i5,eh as i6,th as i7,rh as i8,ah as i9,rd as iA,ad as iB,od as iC,id as iD,ud as iE,hd as iF,pd as iG,fd as iH,dd as iI,yc as iJ,md as iK,gd as iL,yd as iM,wd as iN,tn as iO,Fs as iP,qn as iQ,Tf as iR,$f as iS,Ef as iT,uf as iU,lf as iV,pf as iW,mf as iX,wf as iY,vp as iZ,WT as i_,oh as ia,Wt as ib,uh as ic,ch as id,lh as ie,hh as ig,mh as ih,na as ii,vh as ij,_h as ik,Ih as il,Ah as im,Rh as io,ra as ip,yr as iq,Ph as ir,zh as is,Vh as it,us as iu,Wh as iv,Mh as iw,aa as ix,ds as iy,jh as iz,re as j,VT as j0,zT as j1,PT as j2,_r as k,X as l,D as m,Fe as n,go as o,wo as p,No as q,I as r,ta as s,So as t,To as u,B as v,ko as w,$o as x,Eo as y,Te as z};
